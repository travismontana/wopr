# Quick Start - Directus on WOPR

Get Directus running in 5 minutes.

## Prerequisites

✓ CNPG PostgreSQL cluster running (`wopr-api-db-cluster`)
✓ kubectl configured
✓ Helm 3 installed

## Step 1: Generate Secrets (2 minutes)

```bash
# Generate KEY and SECRET
KEY=$(openssl rand -base64 24)
SECRET=$(openssl rand -base64 48)

echo "KEY: $KEY"
echo "SECRET: $SECRET"
```

## Step 2: Edit values.yaml (2 minutes)

```bash
cd helm/wopr-directus
vim values.yaml
```

**Find and replace these 4 things:**

1. **Line 20:** `host: directus.studio.tailandtraillabs.org`
   - Change to your domain

2. **Line 28:** `- directus.studio.tailandtraillabs.org`
   - Change to your domain

3. **Line 43:** `password: changeme-on-first-login`
   - Set your admin password

4. **Line 47-49:** Paste the KEY and SECRET you generated:
   ```yaml
   key: "paste-KEY-here"
   secret: "paste-SECRET-here"
   ```

5. **Line 53:** `publicUrl: https://directus.studio.tailandtraillabs.org`
   - Change to your domain

## Step 3: Deploy (1 minute)

```bash
helm install wopr-directus . -n wopr
```

Watch it start:
```bash
kubectl get pods -n wopr -w
```

Wait for `Running` status.

## Step 4: Access

Browse to: `https://your-domain.com`

Login:
- Email: (from values.yaml)
- Password: (from values.yaml)

## First Steps in Directus

### Create Your First Table

1. Click **Settings** (gear icon)
2. Click **Data Model**
3. Click **+ Create Collection**
4. Name it `games`
5. Add fields:
   - `id` (integer, auto-increment, primary key)
   - `name` (string, required)
   - `min_players` (integer)
   - `max_players` (integer)
6. Click **Save**

### Add Some Data

1. Click **Content** in sidebar
2. Click **games** collection
3. Click **+ Create Item**
4. Fill in:
   - Name: Dune Imperium
   - Min Players: 1
   - Max Players: 4
5. Click **Save**

### Test the API

```bash
# Get auth token
TOKEN=$(curl -s -X POST https://your-domain.com/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@example.com","password":"your-password"}' \
  | jq -r '.data.access_token')

# Get games
curl https://your-domain.com/items/games \
  -H "Authorization: Bearer $TOKEN"
```

## Done!

You now have:
- ✓ Admin UI for database management
- ✓ Auto-generated REST API
- ✓ Auto-generated GraphQL API
- ✓ File upload support

## Next Steps

- Add more tables (pieces, players, etc)
- Set up relationships between tables
- Configure permissions/roles
- Integrate APIs with your wopr-web frontend

## Troubleshooting

**Pod won't start?**
```bash
kubectl logs -n wopr -l app.kubernetes.io/name=wopr-directus
```

**Can't access UI?**
```bash
kubectl get ingress -n wopr wopr-directus
```

**Forgot password?**
```bash
# Delete pod to trigger re-init
kubectl delete pod -n wopr -l app.kubernetes.io/name=wopr-directus
```

See `DEPLOYMENT.md` for detailed troubleshooting.
