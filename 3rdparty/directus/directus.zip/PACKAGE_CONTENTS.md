# Directus Helm Chart - Package Contents

## What You Got

Complete Helm chart for deploying Directus on your k3s cluster with CNPG PostgreSQL.

## Package Contents

### 1. Helm Chart (directus-helm-chart.tar.gz)
**Extract with:** `tar -xzf directus-helm-chart.tar.gz`

**Contains:**
```
helm-directus/
├── Chart.yaml              # Helm chart metadata
├── values.yaml             # Configuration (EDIT THIS)
├── values-example.yaml     # Commented example config
├── .helmignore             # Files to ignore
├── templates/
│   ├── _helpers.tpl        # Template helpers
│   ├── deployment.yaml     # Directus pod definition
│   ├── service.yaml        # ClusterIP service
│   ├── ingress.yaml        # Traefik ingress + TLS
│   ├── secret.yaml         # Credentials
│   └── pvc.yaml            # Uploads storage
├── README.md               # Full documentation
├── QUICKSTART.md           # 5-minute setup guide
├── DEPLOYMENT.md           # Step-by-step deployment
└── ARCHITECTURE.md         # Dependency diagrams
```

### 2. Documentation Files

**QUICKSTART.md** - Get running in 5 minutes
- Generate secrets
- Edit 5 lines in values.yaml
- Deploy
- Access UI

**README.md** - Comprehensive reference
- Installation instructions
- Configuration options
- API usage examples
- Troubleshooting guide

**DEPLOYMENT.md** - Detailed deployment guide
- Pre-deployment checklist
- Step-by-step instructions
- Post-deployment configuration
- ArgoCD integration
- Troubleshooting procedures

**ARCHITECTURE.md** - Visual diagrams
- Dependency chain
- Component architecture
- Data flow diagrams
- Network topology
- HA setup (future)

## Dependencies

**What Directus needs (you already have):**
- ✓ PostgreSQL (CNPG) - `wopr-api-db-cluster`
- ✓ Traefik ingress controller
- ✓ cert-manager with Let's Encrypt
- ✓ Storage class for PVCs

**What gets created:**
- Directus deployment (1 pod)
- Service (ClusterIP)
- Ingress (HTTPS with TLS)
- Secret (admin password, session keys)
- PVC (10Gi for file uploads)

## Quick Start

1. **Extract:**
   ```bash
   tar -xzf directus-helm-chart.tar.gz
   cd helm-directus
   ```

2. **Generate secrets:**
   ```bash
   KEY=$(openssl rand -base64 24)
   SECRET=$(openssl rand -base64 48)
   echo "KEY: $KEY"
   echo "SECRET: $SECRET"
   ```

3. **Edit values.yaml:**
   - Set your domain (3 places)
   - Paste KEY and SECRET
   - Set admin password

4. **Deploy:**
   ```bash
   helm install wopr-directus . -n wopr
   ```

5. **Access:**
   - Browse to `https://your-domain.com`
   - Login with admin credentials
   - Create your schema (games, pieces, players)

## What Directus Gives You

**Web UI:**
- Database schema editor (create/modify tables)
- Data editor (CRUD on all tables)
- File upload manager
- User/permission management
- API explorer

**Auto-generated APIs:**
- REST API: `/items/games`, `/items/pieces`
- GraphQL API: `/graphql`
- File API: `/files`
- Authentication: `/auth/login`

**Features:**
- Foreign key relationships (dropdown selects)
- File uploads with thumbnails
- Search/filter/sort on any column
- Bulk operations (import/export)
- Webhooks for automation
- Role-based access control

## Integration Options

**Option 1: Use Directus for Everything**
- Schema management via UI
- Data management via UI
- APIs consumed by wopr-web
- File uploads handled by Directus

**Option 2: Hybrid Approach (Recommended)**
- Schema management via Directus UI
- Your wopr-api reads from same database
- Custom business logic in your API
- Directus for admin/backoffice only

**Option 3: Schema Management Only**
- Use Directus UI to create tables
- Build custom CRUD UIs in wopr-web
- Directus APIs not used by frontend
- Clean separation of concerns

## Next Steps After Deployment

1. **Create Schema**
   - Settings → Data Model
   - Create collections: games, pieces, players
   - Define relationships (pieces.game_id → games)

2. **Add Sample Data**
   - Content → games
   - Create items via UI forms

3. **Test APIs**
   - Get auth token via `/auth/login`
   - Query data via `/items/games`

4. **Customize UI (optional)**
   - Configure field layouts
   - Set up display templates
   - Add custom interfaces

5. **Integrate with WOPR**
   - Update wopr-web to call Directus APIs
   - Or use Directus for admin only
   - Your choice based on requirements

## Configuration Highlights

**values.yaml key settings:**

```yaml
# Your domain
ingress:
  hosts:
    - host: directus.yourdomain.com

# Admin credentials
admin:
  email: admin@example.com
  password: strong-password

# Session encryption (GENERATE THESE)
directus:
  key: "random-32-chars"
  secret: "random-64-chars"

# Database (uses existing WOPR DB)
database:
  host: wopr-api-db-cluster-rw.wopr
  name: wopr
  existingSecret: wopr-api-db-cluster-app

# File storage
persistence:
  size: 10Gi
```

## Troubleshooting Quick Reference

**Pod won't start:**
```bash
kubectl logs -n wopr -l app.kubernetes.io/name=wopr-directus
```

**Can't access UI:**
```bash
kubectl get ingress -n wopr wopr-directus
kubectl describe certificate -n wopr directus-tls
```

**Database connection failed:**
```bash
kubectl get cluster -n wopr wopr-api-db-cluster
kubectl get secret -n wopr wopr-api-db-cluster-app
```

**Forgot admin password:**
```bash
kubectl delete pod -n wopr -l app.kubernetes.io/name=wopr-directus
# Triggers re-init with password from values.yaml
```

## Security Notes

**CRITICAL - Before Production:**
- [ ] Change default admin password
- [ ] Generate unique KEY and SECRET
- [ ] Enable HTTPS only (included)
- [ ] Review CORS settings
- [ ] Set up rate limiting (included)
- [ ] Configure user permissions
- [ ] Enable audit logging

## Support Resources

**Directus Documentation:**
- https://docs.directus.io/
- https://docs.directus.io/reference/introduction.html (API)
- https://docs.directus.io/guides/api/graphql.html (GraphQL)

**WOPR Integration:**
- See included README.md
- See DEPLOYMENT.md for detailed setup
- See ARCHITECTURE.md for diagrams

## Files Included

1. ✓ directus-helm-chart.tar.gz - Full Helm chart
2. ✓ QUICKSTART.md - 5-minute setup
3. ✓ README.md - Full reference
4. ✓ DEPLOYMENT.md - Detailed guide
5. ✓ ARCHITECTURE.md - Visual diagrams

Extract the tarball and follow QUICKSTART.md to get running.
