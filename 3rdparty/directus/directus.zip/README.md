# WOPR Directus Helm Chart

Directus headless CMS deployment for WOPR database management.

## Overview

This chart deploys Directus connected to your existing WOPR PostgreSQL database (CNPG). Directus will:
- Auto-generate admin UI from your database schema
- Provide REST and GraphQL APIs
- Handle file uploads to persistent storage
- Manage authentication and permissions

## Prerequisites

- Kubernetes cluster with Helm 3
- CNPG PostgreSQL cluster running (wopr-api-db-cluster)
- Traefik ingress controller
- cert-manager for TLS certificates
- Storage class for PersistentVolumeClaims

## Dependencies

Directus requires:
- PostgreSQL database (provided by CNPG)
- Persistent storage for uploads
- TLS certificate (from cert-manager)

## Installation

### 1. Generate Secrets

**CRITICAL:** Replace the default key and secret in `values.yaml`:

```bash
# Generate random key (32 characters)
openssl rand -base64 24

# Generate random secret (64 characters)  
openssl rand -base64 48
```

Update `values.yaml`:
```yaml
directus:
  key: "your-32-char-random-string-here"
  secret: "your-64-char-random-string-here"
```

### 2. Update Admin Credentials

Change the default admin password in `values.yaml`:
```yaml
admin:
  email: admin@yourdomain.com
  password: your-secure-password-here
```

### 3. Configure Hostname

Update the ingress hostname in `values.yaml`:
```yaml
ingress:
  hosts:
    - host: directus.yourdomain.com
      ...
  tls:
    - secretName: directus-tls
      hosts:
        - directus.yourdomain.com

directus:
  publicUrl: https://directus.yourdomain.com
```

### 4. Install Chart

```bash
# Install to wopr namespace
helm install wopr-directus . -n wopr

# Or upgrade if already installed
helm upgrade wopr-directus . -n wopr
```

### 5. Verify Deployment

```bash
# Check pods
kubectl get pods -n wopr -l app.kubernetes.io/name=wopr-directus

# Check logs
kubectl logs -n wopr -l app.kubernetes.io/name=wopr-directus -f

# Check ingress
kubectl get ingress -n wopr wopr-directus
```

### 6. Access Directus

Browse to: `https://directus.yourdomain.com`

Login with:
- Email: (from values.yaml admin.email)
- Password: (from values.yaml admin.password)

## Configuration

### Database Connection

Directus connects to your existing WOPR database:

```yaml
database:
  host: wopr-api-db-cluster-rw.wopr.svc.cluster.local
  port: 5432
  name: wopr
  user: app
  existingSecret: wopr-api-db-cluster-app
  existingSecretPasswordKey: password
```

This uses the CNPG-generated secret for database credentials.

### Storage

File uploads are stored in a PersistentVolume:

```yaml
persistence:
  enabled: true
  size: 10Gi
  mountPath: /directus/uploads
```

Increase size if you'll be uploading lots of images/files.

### Resources

Adjust based on your usage:

```yaml
resources:
  requests:
    cpu: 100m
    memory: 256Mi
  limits:
    cpu: 1000m
    memory: 1Gi
```

### Environment Variables

Add custom env vars in `values.yaml`:

```yaml
env:
  - name: LOG_LEVEL
    value: debug
  - name: CUSTOM_VAR
    value: custom_value
```

## Usage

### Creating Tables

1. Navigate to Settings → Data Model
2. Click "+ Create Collection"
3. Define table name and columns
4. Save

Directus writes actual DDL to your PostgreSQL database.

### Adding Data

1. Navigate to Content
2. Select your collection (table)
3. Click "+ Create Item"
4. Fill in form
5. Save

### APIs

Directus auto-generates APIs:

**REST:**
```bash
# Get all items
GET https://directus.yourdomain.com/items/games

# Get specific item
GET https://directus.yourdomain.com/items/games/1

# Create item
POST https://directus.yourdomain.com/items/games
{
  "name": "Dune Imperium",
  "min_players": 1,
  "max_players": 4
}
```

**GraphQL:**
```bash
# GraphQL endpoint
POST https://directus.yourdomain.com/graphql
```

### File Uploads

1. Add a "File" field to your collection
2. Upload files via UI or API
3. Files stored in PVC at `/directus/uploads`

## Troubleshooting

### Pod Won't Start

Check logs:
```bash
kubectl logs -n wopr -l app.kubernetes.io/name=wopr-directus
```

Common issues:
- Database connection failed (check CNPG secret)
- Invalid KEY or SECRET (must be set)
- PVC provisioning failed (check storage class)

### Can't Access UI

Check ingress:
```bash
kubectl describe ingress -n wopr wopr-directus
```

Verify:
- DNS points to your cluster
- cert-manager issued certificate
- Traefik is routing traffic

### Database Migrations Failed

Directus runs migrations on startup. If they fail:
```bash
# Check migrations table
kubectl exec -it wopr-api-db-cluster-1 -n wopr -- \
  psql -U app -d wopr -c "SELECT * FROM directus_migrations;"
```

You may need to manually fix schema conflicts.

### Forgot Admin Password

Reset via database:
```bash
# Connect to database
kubectl exec -it wopr-api-db-cluster-1 -n wopr -- \
  psql -U app -d wopr

# Reset password (hashed with bcrypt)
UPDATE directus_users 
SET password = '$2a$10$...' 
WHERE email = 'admin@example.com';
```

Or delete the pod to trigger re-initialization.

## Upgrading

```bash
# Pull latest values
helm get values wopr-directus -n wopr > my-values.yaml

# Edit my-values.yaml with changes

# Upgrade
helm upgrade wopr-directus . -n wopr -f my-values.yaml
```

## Uninstalling

```bash
# Uninstall chart
helm uninstall wopr-directus -n wopr

# Remove PVC (DANGER: deletes all uploads)
kubectl delete pvc -n wopr wopr-directus-uploads
```

**WARNING:** Uninstalling does NOT delete database tables created by Directus. Those remain in your PostgreSQL database.

## Security Notes

- **Change default secrets** before deploying to production
- **Use strong admin password**
- Enable TLS (included via cert-manager)
- Consider network policies to restrict access
- Review Directus permissions/roles for multi-user access

## Integration with WOPR

### Option 1: Direct API Usage

Your `wopr-web` can call Directus APIs:

```typescript
// Fetch games
const response = await fetch('https://directus.yourdomain.com/items/games');
const games = await response.json();
```

### Option 2: Schema Management Only

Use Directus UI to manage schema, but keep your custom APIs:
- Directus creates/modifies tables
- Your wopr-api reads from same database
- Separation of concerns

## Documentation

- [Directus Docs](https://docs.directus.io/)
- [REST API Reference](https://docs.directus.io/reference/introduction.html)
- [GraphQL API Reference](https://docs.directus.io/guides/api/graphql.html)
