# Directus Deployment Guide for WOPR

## Dependency Chain

```
┌─────────────────────────────────────────────────────────────┐
│                    Directus Deployment                       │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ depends on
                            ▼
┌────────────────┬────────────────┬────────────────┬────────────────┐
│  PostgreSQL    │    Storage     │   Traefik      │  cert-manager  │
│   (CNPG)       │    (PVC)       │   (Ingress)    │     (TLS)      │
└────────────────┴────────────────┴────────────────┴────────────────┘
        │                 │                 │                 │
        │                 │                 │                 │
        ▼                 ▼                 ▼                 ▼
┌─────────────────────────────────────────────────────────────┐
│              Kubernetes Cluster (k3s)                        │
└─────────────────────────────────────────────────────────────┘
```

## Detailed Component Dependencies

### 1. PostgreSQL (CNPG)
**Status:** ✓ Already deployed
**Resource:** `wopr-api-db-cluster`
**Namespace:** `wopr`
**Secret:** `wopr-api-db-cluster-app` (contains password)

**Verify:**
```bash
kubectl get cluster -n wopr wopr-api-db-cluster
kubectl get secret -n wopr wopr-api-db-cluster-app
```

### 2. Storage Class
**Status:** Check
**Resource:** Default storage class or specific class

**Verify:**
```bash
kubectl get storageclass

# Should show something like:
# NAME                   PROVISIONER
# local-path (default)   rancher.io/local-path
```

**If no default:**
```yaml
# In values.yaml
persistence:
  storageClass: "local-path"  # or your specific class
```

### 3. Traefik Ingress
**Status:** ✓ Assumed deployed
**Resource:** Traefik ingress controller
**Namespace:** `kube-system` or `traefik`

**Verify:**
```bash
kubectl get pods -A | grep traefik
kubectl get ingressclass
```

### 4. cert-manager
**Status:** ✓ Assumed deployed
**Resource:** ClusterIssuer for Let's Encrypt

**Verify:**
```bash
kubectl get clusterissuer
# Should show: letsencrypt-prod
```

**If missing ClusterIssuer:**
```yaml
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt-prod
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: admin@yourdomain.com
    privateKeySecretRef:
      name: letsencrypt-prod-key
    solvers:
    - http01:
        ingress:
          class: traefik
```

## Pre-Deployment Checklist

- [ ] PostgreSQL CNPG cluster running
- [ ] Database secret exists: `wopr-api-db-cluster-app`
- [ ] Storage class available
- [ ] Traefik ingress controller running
- [ ] cert-manager deployed with ClusterIssuer
- [ ] DNS record points to your cluster
- [ ] Generated random KEY (32 chars)
- [ ] Generated random SECRET (64 chars)
- [ ] Set strong admin password

## Step-by-Step Deployment

### Step 1: Generate Secrets

```bash
# Generate KEY (32 characters)
KEY=$(openssl rand -base64 24)
echo "KEY: $KEY"

# Generate SECRET (64 characters)
SECRET=$(openssl rand -base64 48)
echo "SECRET: $SECRET"

# Save these - you'll need them in values.yaml
```

### Step 2: Clone/Copy Helm Chart

```bash
# If in Git repo
cd helm/
git clone <this-chart> wopr-directus

# Or manually copy
mkdir -p helm/wopr-directus
cp -r /path/to/chart/* helm/wopr-directus/
```

### Step 3: Edit values.yaml

```bash
cd helm/wopr-directus
vim values.yaml
```

**Critical changes:**
```yaml
# 1. Set your domain
ingress:
  hosts:
    - host: directus.studio.tailandtraillabs.org  # CHANGE THIS
      ...

# 2. Set public URL
directus:
  publicUrl: https://directus.studio.tailandtraillabs.org  # CHANGE THIS
  key: "paste-your-generated-key-here"      # CHANGE THIS
  secret: "paste-your-generated-secret-here" # CHANGE THIS

# 3. Set admin credentials
admin:
  email: admin@yourdomain.com    # CHANGE THIS
  password: strong-password-here # CHANGE THIS

# 4. Verify database connection (should be correct already)
database:
  host: wopr-api-db-cluster-rw.wopr.svc.cluster.local
  name: wopr
  user: app
  existingSecret: wopr-api-db-cluster-app
```

### Step 4: Verify Configuration

```bash
# Dry run to check for errors
helm install wopr-directus . -n wopr --dry-run --debug

# Check rendered templates
helm template wopr-directus . -n wopr > rendered.yaml
less rendered.yaml
```

### Step 5: Deploy

```bash
# Install to wopr namespace
helm install wopr-directus . -n wopr

# Watch deployment
kubectl get pods -n wopr -w
```

### Step 6: Verify Deployment

```bash
# Check pod status
kubectl get pods -n wopr -l app.kubernetes.io/name=wopr-directus

# Should show:
# NAME                              READY   STATUS    RESTARTS   AGE
# wopr-directus-xxxxxxxxxx-xxxxx   1/1     Running   0          2m

# Check logs
kubectl logs -n wopr -l app.kubernetes.io/name=wopr-directus

# Should see:
# Directus version 11.x.x
# Database connected
# Admin user created (first run only)
# Server started on port 8055
```

### Step 7: Check Ingress

```bash
# Get ingress
kubectl get ingress -n wopr wopr-directus

# Should show:
# NAME            CLASS     HOSTS                                 ADDRESS   PORTS     AGE
# wopr-directus   traefik   directus.studio.tailandtraillabs.org  x.x.x.x   80, 443   5m

# Check certificate
kubectl get certificate -n wopr directus-tls

# Should show:
# NAME           READY   SECRET         AGE
# directus-tls   True    directus-tls   5m
```

### Step 8: Access Directus

1. **Browse to:** `https://directus.studio.tailandtraillabs.org`
2. **Login with:**
   - Email: (from values.yaml)
   - Password: (from values.yaml)
3. **First login:** Change password in settings

## Post-Deployment Configuration

### Create Your Schema

1. Navigate to **Settings → Data Model**
2. Click **"+ Create Collection"**
3. Create `games` table:
   - Name: `games`
   - Fields:
     - `id` (integer, auto-increment, primary key)
     - `name` (string, required)
     - `description` (text)
     - `min_players` (integer)
     - `max_players` (integer)

4. Create `pieces` table:
   - Name: `pieces`
   - Fields:
     - `id` (integer, auto-increment, primary key)
     - `name` (string, required)
     - `game_id` (integer, relation to games)

5. Create `players` table:
   - Name: `players`
   - Fields:
     - `id` (integer, auto-increment, primary key)
     - `name` (string, required)

### Set Up Relationships

1. Click `pieces` collection
2. Click the `game_id` field
3. Set relationship:
   - Type: Many-to-One
   - Related Collection: `games`
   - Field on Related Collection: `pieces` (auto-generated)

### Add Sample Data

1. Navigate to **Content → games**
2. Click **"+ Create Item"**
3. Fill in:
   - Name: Dune Imperium
   - Description: Deck-building worker placement
   - Min Players: 1
   - Max Players: 4
4. Save

Repeat for other games.

### Test APIs

```bash
# Get all games (requires auth token)
curl https://directus.studio.tailandtraillabs.org/items/games

# If you need auth, first login:
curl -X POST https://directus.studio.tailandtraillabs.org/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@example.com","password":"your-password"}' \
  | jq -r '.data.access_token'

# Then use token:
curl https://directus.studio.tailandtraillabs.org/items/games \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

## ArgoCD Integration (Optional)

### Create ArgoCD Application

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: wopr-directus
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/yourusername/wopr.git
    targetRevision: main
    path: helm/wopr-directus
    helm:
      valueFiles:
        - values.yaml
  destination:
    server: https://kubernetes.default.svc
    namespace: wopr
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
    syncOptions:
      - CreateNamespace=true
```

Apply:
```bash
kubectl apply -f argocd-app-directus.yaml
```

## Troubleshooting

### Pod CrashLoopBackOff

**Check logs:**
```bash
kubectl logs -n wopr -l app.kubernetes.io/name=wopr-directus
```

**Common issues:**

1. **Database connection failed**
   - Verify CNPG cluster is running
   - Check secret exists and has correct key
   - Test connection from pod:
     ```bash
     kubectl run -it --rm psql-test --image=postgres:16 -n wopr -- \
       psql postgres://app@wopr-api-db-cluster-rw.wopr:5432/wopr
     ```

2. **Invalid KEY or SECRET**
   - Must be set in values.yaml
   - Cannot be empty strings
   - Regenerate if needed

3. **PVC provisioning failed**
   - Check storage class exists
   - Verify PVC is bound:
     ```bash
     kubectl get pvc -n wopr wopr-directus-uploads
     ```

### Ingress Not Working

**Check certificate:**
```bash
kubectl describe certificate -n wopr directus-tls
```

**Check cert-manager logs:**
```bash
kubectl logs -n cert-manager -l app=cert-manager
```

**Verify DNS:**
```bash
nslookup directus.studio.tailandtraillabs.org
```

### Can't Login

**Reset admin password:**
```bash
# Method 1: Delete pod (triggers re-init)
kubectl delete pod -n wopr -l app.kubernetes.io/name=wopr-directus

# Method 2: Manually in database
kubectl exec -it wopr-api-db-cluster-1 -n wopr -- \
  psql -U app -d wopr -c \
  "UPDATE directus_users SET password = '\$2a\$10\$...' WHERE email = 'admin@example.com';"
```

## Cleanup

### Uninstall Chart

```bash
# Uninstall Directus
helm uninstall wopr-directus -n wopr

# Remove PVC (deletes uploads)
kubectl delete pvc -n wopr wopr-directus-uploads
```

**Note:** Database tables remain. To remove:
```sql
DROP TABLE directus_migrations;
DROP TABLE directus_users;
DROP TABLE directus_permissions;
-- etc...
```

## Next Steps

1. Set up users and permissions in Directus
2. Configure custom fields and layouts
3. Add file upload fields for piece images
4. Set up webhooks for automated workflows
5. Integrate Directus APIs with wopr-web frontend
