# Directus Dependency Diagram for WOPR

## Architecture Overview

```
┌──────────────────────────────────────────────────────────────────┐
│                         Internet / User                          │
└────────────────────────────┬─────────────────────────────────────┘
                             │
                             │ HTTPS
                             ▼
┌──────────────────────────────────────────────────────────────────┐
│                      DNS (your domain)                           │
│              directus.studio.tailandtraillabs.org                │
└────────────────────────────┬─────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────┐
│                   Traefik Ingress Controller                     │
│                     (Port 80/443 routing)                        │
└────────────┬────────────────────────────────────┬────────────────┘
             │                                    │
             │                                    │ TLS Certificate
             │                                    ▼
             │                        ┌──────────────────────────┐
             │                        │     cert-manager         │
             │                        │  (TLS cert generation)   │
             │                        └──────────────────────────┘
             │                                    │
             │                                    │ Let's Encrypt
             │                                    ▼
             │                        ┌──────────────────────────┐
             │                        │  letsencrypt-prod        │
             │                        │   (ClusterIssuer)        │
             │                        └──────────────────────────┘
             │
             │ HTTP Request
             ▼
┌──────────────────────────────────────────────────────────────────┐
│                    Directus Service                              │
│                  (ClusterIP:8055)                                │
└────────────────────────────┬─────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────┐
│                    Directus Pod                                  │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │            Directus Container                              │ │
│  │          (directus/directus:11.2.2)                        │ │
│  │                                                            │ │
│  │  Environment:                                              │ │
│  │  - DB_CLIENT=pg                                            │ │
│  │  - DB_HOST=wopr-api-db-cluster-rw.wopr                    │ │
│  │  - KEY=<from secret>                                       │ │
│  │  - SECRET=<from secret>                                    │ │
│  │  - ADMIN_EMAIL=admin@example.com                           │ │
│  │  - ADMIN_PASSWORD=<from secret>                            │ │
│  │                                                            │ │
│  │  Volumes:                                                  │ │
│  │  - /directus/uploads → PVC                                 │ │
│  └────────────────────────────────────────────────────────────┘ │
└───────────┬────────────────────────────┬─────────────────────────┘
            │                            │
            │ Database Connection        │ File Storage
            ▼                            ▼
┌──────────────────────────┐  ┌──────────────────────────┐
│  CNPG PostgreSQL         │  │  PersistentVolume        │
│  Cluster                 │  │  (uploads)               │
│                          │  │                          │
│  wopr-api-db-cluster     │  │  Size: 10Gi              │
│                          │  │  AccessMode: RWO         │
│  ┌────────────────────┐  │  │  StorageClass: default   │
│  │  Primary Pod       │  │  │                          │
│  │  (Read/Write)      │  │  │  Mount:                  │
│  │  Port: 5432        │  │  │  /directus/uploads       │
│  └────────────────────┘  │  │                          │
│                          │  │  Contents:               │
│  Database: wopr          │  │  - User uploads          │
│  User: app               │  │  - Images                │
│  Password: <from CNPG>   │  │  - Files                 │
│                          │  │  - Thumbnails            │
│  Tables:                 │  └──────────────────────────┘
│  - directus_*            │
│  - games                 │
│  - pieces                │
│  - players               │
│  - settings              │
└──────────────────────────┘
            │
            │ Credentials
            ▼
┌──────────────────────────────────────────────────────────────────┐
│                    Kubernetes Secrets                            │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │ wopr-directus-secrets                                       ││
│  │ - admin-password: <your-admin-password>                     ││
│  │ - key: <random-32-char-string>                              ││
│  │ - secret: <random-64-char-string>                           ││
│  └─────────────────────────────────────────────────────────────┘│
│                                                                  │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │ wopr-api-db-cluster-app (CNPG)                              ││
│  │ - password: <generated-by-cnpg>                             ││
│  │ - username: app                                             ││
│  │ - dbname: wopr                                              ││
│  └─────────────────────────────────────────────────────────────┘│
└──────────────────────────────────────────────────────────────────┘
```

## Component Dependency Tree

```
Directus Deployment
├── PostgreSQL (CNPG)
│   ├── wopr-api-db-cluster
│   │   ├── Primary pod (R/W)
│   │   ├── Replica pod(s) (R/O)
│   │   └── Service (ClusterIP)
│   └── Secret: wopr-api-db-cluster-app
│       ├── password
│       ├── username
│       └── dbname
│
├── Persistence
│   └── PersistentVolumeClaim
│       ├── Size: 10Gi
│       ├── AccessMode: ReadWriteOnce
│       └── StorageClass: default
│
├── Ingress
│   ├── Traefik Ingress Controller
│   │   ├── HTTP → HTTPS redirect
│   │   ├── Path routing
│   │   └── TLS termination
│   └── cert-manager
│       ├── Certificate resource
│       ├── ClusterIssuer: letsencrypt-prod
│       └── ACME challenge (HTTP-01)
│
├── Secrets
│   └── wopr-directus-secrets
│       ├── admin-password
│       ├── key (session encryption)
│       └── secret (JWT signing)
│
└── Kubernetes Resources
    ├── Deployment (1 replica)
    ├── Service (ClusterIP:8055)
    ├── Ingress (HTTPS)
    ├── PVC (uploads)
    └── Secret (credentials)
```

## Data Flow

### User Access Flow
```
User Browser
    │
    ▼
DNS Resolution (directus.yourdomain.com → Load Balancer IP)
    │
    ▼
Traefik Ingress (HTTPS:443)
    │
    ├─→ cert-manager (TLS cert validation)
    │
    ▼
Directus Service (ClusterIP:8055)
    │
    ▼
Directus Pod (Container port 8055)
    │
    ├─→ Database queries → PostgreSQL
    │
    └─→ File operations → PVC
```

### Database Connection Flow
```
Directus Pod
    │
    ├─→ Read DB credentials from Secret
    │   (wopr-api-db-cluster-app)
    │
    ▼
Connect to PostgreSQL
    │
    ├─→ wopr-api-db-cluster-rw.wopr:5432
    │   (CNPG read-write service)
    │
    ▼
Authenticate
    │
    ├─→ User: app
    ├─→ Password: <from secret>
    └─→ Database: wopr
    │
    ▼
Execute queries
    │
    ├─→ Read/Write to directus_* tables
    └─→ Read/Write to user tables (games, pieces, etc)
```

### File Upload Flow
```
User uploads file via Directus UI
    │
    ▼
Directus receives file (HTTP POST /files)
    │
    ▼
Store metadata in database (directus_files table)
    │
    ▼
Write file to disk (STORAGE_LOCAL_ROOT)
    │
    ├─→ Container path: /directus/uploads
    │
    ▼
PVC mount point
    │
    ├─→ PersistentVolume
    │
    ▼
Physical storage (based on StorageClass)
    │
    └─→ local-path, NFS, or cloud storage
```

## Network Policies (Optional)

```
┌─────────────────────────────────────────────────────────────┐
│                     Ingress Traffic                         │
│                 (from Traefik only)                         │
└────────────┬────────────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────────────┐
│                   Directus Pod                               │
│                   Ports: 8055                                │
└────────────┬──────────────────────┬──────────────────────────┘
             │                      │
             │ Egress to DB         │ Egress to Internet
             ▼                      │ (optional - for email, etc)
┌──────────────────────────┐       │
│  PostgreSQL              │       ▼
│  Port: 5432              │  ┌─────────────────────┐
└──────────────────────────┘  │  External Services  │
                              │  (SMTP, S3, etc)    │
                              └─────────────────────┘
```

## Resource Requirements

```
Minimum:
- CPU: 100m
- Memory: 256Mi
- Disk (PVC): 10Gi

Recommended:
- CPU: 500m
- Memory: 512Mi
- Disk (PVC): 20Gi

Production:
- CPU: 1000m
- Memory: 1Gi
- Disk (PVC): 50Gi+
```

## High Availability (Future)

```
┌─────────────────────────────────────────────────────────────┐
│                    Load Balancer                            │
└────────────┬────────────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────────────┐
│             Directus Service (LoadBalancer)                  │
└────┬──────────────────────┬──────────────────────┬───────────┘
     │                      │                      │
     ▼                      ▼                      ▼
┌─────────────┐      ┌─────────────┐      ┌─────────────┐
│ Directus    │      │ Directus    │      │ Directus    │
│ Pod 1       │      │ Pod 2       │      │ Pod 3       │
└─────────────┘      └─────────────┘      └─────────────┘
     │                      │                      │
     └──────────────────────┴──────────────────────┘
                            │
                            ▼
             ┌──────────────────────────┐
             │   PostgreSQL CNPG        │
             │   (with replicas)        │
             └──────────────────────────┘
             │
             ▼
             ┌──────────────────────────┐
             │   Redis (sessions)       │
             └──────────────────────────┘
             │
             ▼
             ┌──────────────────────────┐
             │   S3 (file storage)      │
             └──────────────────────────┘
```

For HA setup:
- replicas: 3
- Session store: Redis (not memory)
- File storage: S3 (not local PVC)
- Database: CNPG with replicas
