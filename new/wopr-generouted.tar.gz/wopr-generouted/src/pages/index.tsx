import WorkInProgress from "@/components/wip";

export default function Home() {
  return <WorkInProgress />;
}
