export default function BackOfHouseIndex() {
  return (
    <div>
      <h1>Back of House</h1>
      <p>Select a section from the navigation to begin.</p>
    </div>
  );
}
