export default function ConfigIndex() {
  return (
    <div>
      <h2>Configuration</h2>
      <p>System configuration options.</p>
    </div>
  );
}
