import WorkInProgress from "@/components/wip";

export default function ConfigControl() {
  return <WorkInProgress />;
}
