export default function CamerasIndex() {
  return (
    <div>
      <h2>Cameras</h2>
      <p>Select a camera operation from the navigation.</p>
    </div>
  );
}
