import WorkInProgress from "@/components/wip";

export default function CameraConfig() {
  return <WorkInProgress />;
}
