import WorkInProgress from "@/components/wip";

export default function CameraCapture() {
  return <WorkInProgress />;
}
