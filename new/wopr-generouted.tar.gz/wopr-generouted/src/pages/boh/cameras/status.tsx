import WorkInProgress from "@/components/wip";

export default function CameraStatus() {
  return <WorkInProgress />;
}
