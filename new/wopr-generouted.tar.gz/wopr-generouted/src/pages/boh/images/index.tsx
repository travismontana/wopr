export default function ImagesIndex() {
  return (
    <div>
      <h2>Images</h2>
      <p>Image management tools.</p>
    </div>
  );
}
