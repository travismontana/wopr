import WorkInProgress from "@/components/wip";

export default function ImageGallery() {
  // TODO: This previously had gameId prop passed in
  // Convert to URL param: /boh/images/gallery/:gameId
  // Or use query param: /boh/images/gallery?gameId=xxx
  return <WorkInProgress />;
}
