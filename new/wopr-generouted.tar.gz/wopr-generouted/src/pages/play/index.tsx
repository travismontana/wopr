import WorkInProgress from "@/components/wip";

export default function Play() {
  return <WorkInProgress />;
}
