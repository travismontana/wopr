# Thumbor Helm Chart

A Helm chart for deploying [Thumbor](https://github.com/MinimalCompact/thumbor) image processing service on Kubernetes.

## Description

Thumbor is an open-source smart imaging service that enables on-demand image cropping, resizing, and filtering. This chart deploys Thumbor as part of the WOPR (Wargaming Oversight & Position Recognition) project for processing game board images.

## Prerequisites

- Kubernetes 1.19+
- Helm 3.0+
- PV provisioner support in the underlying infrastructure (if persistence is enabled)
- Traefik ingress controller (if ingress is enabled)
- cert-manager (if TLS is enabled)

## Installation

### Basic Installation

```bash
# Install with default values
helm install thumbor ./thumbor-chart

# Install in a specific namespace
helm install thumbor ./thumbor-chart -n wopr --create-namespace
```

### Custom Installation

```bash
# Install with custom values
helm install thumbor ./thumbor-chart -f custom-values.yaml

# Install with inline overrides
helm install thumbor ./thumbor-chart \
  --set config.securityKey="your-random-key-here" \
  --set ingress.hosts[0].host="thumbor.yourdomain.com"
```

## Configuration

### Essential Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `config.securityKey` | Security key for URL signing (CHANGE THIS!) | `change-me-to-a-random-string` |
| `config.allowUnsafeUrl` | Allow unsigned URLs (disable in production) | `true` |
| `ingress.hosts[0].host` | Hostname for Thumbor service | `thumbor.studio.local` |

### Image Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `image.repository` | Thumbor image repository | `minimalcompact/thumbor` |
| `image.tag` | Thumbor image tag | `7.7.5` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |

### Service Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `service.type` | Kubernetes service type | `ClusterIP` |
| `service.port` | Service port | `8000` |

### Thumbor Settings

| Parameter | Description | Default |
|-----------|-------------|---------|
| `config.quality` | Default JPEG quality | `85` |
| `config.autoWebp` | Auto-convert to WebP when supported | `true` |
| `config.maxWidth` | Maximum image width | `4096` |
| `config.maxHeight` | Maximum image height | `4096` |
| `config.storageType` | Storage backend | `thumbor.storages.file_storage` |
| `config.resultStorageType` | Result cache storage | `thumbor.result_storages.file_storage` |

### Persistence

| Parameter | Description | Default |
|-----------|-------------|---------|
| `persistence.enabled` | Enable persistent storage | `true` |
| `persistence.size` | PVC size | `10Gi` |
| `persistence.storageClass` | Storage class | `""` (default) |
| `persistence.accessMode` | PVC access mode | `ReadWriteOnce` |
| `persistence.existingClaim` | Use existing PVC | `""` |

### Resource Limits

| Parameter | Description | Default |
|-----------|-------------|---------|
| `resources.limits.cpu` | CPU limit | `1000m` |
| `resources.limits.memory` | Memory limit | `1Gi` |
| `resources.requests.cpu` | CPU request | `250m` |
| `resources.requests.memory` | Memory request | `512Mi` |

## Usage Examples

### Generate a Signed URL

```bash
# Install thumbor-url Python package
pip install thumbor-url

# Generate signed URL
from thumbor_url import Signer
signer = Signer('your-security-key')
url = signer.url_for(
    'https://example.com/image.jpg',
    width=300,
    height=200,
    filters=['quality(90)']
)
print(url)
```

### Unsafe URL Format (Development Only)

```
# Resize to 300x200
/unsafe/300x200/https://example.com/image.jpg

# Resize with filters
/unsafe/300x200/filters:quality(90):sharpen(2,1.0,true)/https://example.com/image.jpg

# Smart crop
/unsafe/300x200/smart/https://example.com/image.jpg
```

### Common Filters

- `quality(N)` - Set JPEG quality (1-100)
- `sharpen(amount, radius, luminance_only)` - Sharpen image
- `blur(radius)` - Blur image
- `grayscale()` - Convert to grayscale
- `rotate(degrees)` - Rotate image
- `brightness(amount)` - Adjust brightness (-100 to 100)
- `contrast(amount)` - Adjust contrast (-100 to 100)
- `format(webp|jpeg|png)` - Convert format

## Security Considerations

### Production Deployment Checklist

1. **Generate a strong security key:**
   ```bash
   openssl rand -base64 32
   ```

2. **Disable unsafe URLs:**
   ```yaml
   config:
     allowUnsafeUrl: false
   ```

3. **Use signed URLs only:**
   - Implement URL signing in your application
   - Never expose the security key to clients

4. **Enable TLS:**
   ```yaml
   ingress:
     tls:
       - secretName: thumbor-tls
         hosts:
           - thumbor.yourdomain.com
   ```

5. **Configure resource limits:**
   - Set appropriate CPU/memory limits
   - Monitor resource usage

## Troubleshooting

### Check pod status
```bash
kubectl get pods -l app.kubernetes.io/name=thumbor
kubectl logs -l app.kubernetes.io/name=thumbor
```

### Test healthcheck
```bash
kubectl exec -it deployment/thumbor -- curl localhost:8000/healthcheck
```

### Debug image processing
```bash
# Port-forward to local machine
kubectl port-forward svc/thumbor 8000:8000

# Test URL
curl http://localhost:8000/healthcheck
```

### Common Issues

**Images not loading:**
- Check that source images are accessible from the pod
- Verify storage permissions (runAsUser: 1000)
- Check pod logs for errors

**Slow performance:**
- Increase resource limits
- Enable result caching
- Consider using Redis for caching (requires additional configuration)

**Security errors:**
- Verify security key matches between signer and deployment
- Check URL signature generation
- Ensure unsafe URLs are disabled in production

## Integration with WOPR

Thumbor processes images for the WOPR computer vision pipeline:

```bash
# Example: Process game board image
POST /api/v1/images/process
{
  "source_url": "http://wopr-cam:8000/capture/latest.jpg",
  "width": 1920,
  "height": 1080,
  "filters": ["sharpen(2,1.0,true)", "quality(95)"]
}
```

## Upgrading

```bash
# Upgrade to new version
helm upgrade thumbor ./thumbor-chart -f values.yaml

# Rollback if needed
helm rollback thumbor
```

## Uninstallation

```bash
# Uninstall release
helm uninstall thumbor

# Optionally delete PVC
kubectl delete pvc thumbor
```

## Links

- [Thumbor Documentation](https://thumbor.readthedocs.io/)
- [MinimalCompact/thumbor GitHub](https://github.com/MinimalCompact/thumbor)
- [Thumbor Filters](https://thumbor.readthedocs.io/en/latest/filters.html)
- [WOPR Project](https://github.com/travismontana/wopr)
