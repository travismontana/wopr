#!/bin/bash
set -euo pipefail

# Thumbor Helm Chart Installation Script
# Usage: ./install.sh [namespace] [release-name]

NAMESPACE="${1:-wopr}"
RELEASE="${2:-thumbor}"
VALUES_FILE="${3:-values.yaml}"

echo "=== Thumbor Installation Script ==="
echo "Namespace: $NAMESPACE"
echo "Release: $RELEASE"
echo "Values: $VALUES_FILE"
echo

# Check prerequisites
echo "Checking prerequisites..."

if ! command -v helm &> /dev/null; then
    echo "ERROR: helm is not installed"
    exit 1
fi

if ! command -v kubectl &> /dev/null; then
    echo "ERROR: kubectl is not installed"
    exit 1
fi

# Verify cluster connection
if ! kubectl cluster-info &> /dev/null; then
    echo "ERROR: Cannot connect to Kubernetes cluster"
    exit 1
fi

echo "✓ Prerequisites OK"
echo

# Lint the chart
echo "Linting Helm chart..."
helm lint .
echo "✓ Chart linting OK"
echo

# Create namespace if it doesn't exist
if ! kubectl get namespace "$NAMESPACE" &> /dev/null; then
    echo "Creating namespace $NAMESPACE..."
    kubectl create namespace "$NAMESPACE"
fi

# Check for security key warning
if grep -q "change-me-to-a-random-string" "$VALUES_FILE"; then
    echo "⚠️  WARNING: Default security key detected!"
    echo "Generate a random key with: openssl rand -base64 32"
    echo "Update values.yaml config.securityKey before production deployment"
    echo
    read -p "Continue anyway? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Install or upgrade
if helm list -n "$NAMESPACE" | grep -q "^$RELEASE"; then
    echo "Upgrading existing release..."
    helm upgrade "$RELEASE" . \
        -n "$NAMESPACE" \
        -f "$VALUES_FILE" \
        --wait
else
    echo "Installing new release..."
    helm install "$RELEASE" . \
        -n "$NAMESPACE" \
        -f "$VALUES_FILE" \
        --wait
fi

echo
echo "=== Installation Complete ==="
echo

# Show status
echo "Release status:"
helm status "$RELEASE" -n "$NAMESPACE"

echo
echo "Pod status:"
kubectl get pods -n "$NAMESPACE" -l "app.kubernetes.io/name=thumbor"

echo
echo "Service:"
kubectl get svc -n "$NAMESPACE" -l "app.kubernetes.io/name=thumbor"

echo
echo "Ingress:"
kubectl get ingress -n "$NAMESPACE" -l "app.kubernetes.io/name=thumbor"

echo
echo "=== Next Steps ==="
echo "1. Test healthcheck: kubectl exec -n $NAMESPACE deployment/$RELEASE-thumbor -- curl localhost:8000/healthcheck"
echo "2. View logs: kubectl logs -n $NAMESPACE -l app.kubernetes.io/name=thumbor"
echo "3. Port-forward for local testing: kubectl port-forward -n $NAMESPACE svc/$RELEASE-thumbor 8000:8000"
echo
echo "Remember to:"
echo "- Change the security key in production!"
echo "- Disable allowUnsafeUrl in production (set to false)"
echo "- Configure proper TLS certificates"
