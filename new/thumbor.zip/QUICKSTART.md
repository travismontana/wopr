# Thumbor Helm Chart - Quick Start Guide

## What You've Got

A complete Helm chart for deploying Thumbor image processing service to your k3s "studio" cluster.

```
thumbor-chart/
├── Chart.yaml                      # Chart metadata
├── values.yaml                     # Default configuration
├── values-production.yaml          # Production-ready config template
├── README.md                       # Full documentation
├── install.sh                      # Automated installation script
├── test.sh                         # Deployment verification script
└── templates/
    ├── deployment.yaml             # Thumbor pod deployment
    ├── service.yaml                # ClusterIP service
    ├── ingress.yaml                # Traefik ingress
    ├── configmap.yaml              # Configuration
    ├── secret.yaml                 # Security key storage
    ├── pvc.yaml                    # Persistent storage
    ├── _helpers.tpl                # Template helpers
    └── NOTES.txt                   # Post-install instructions
```

## Before You Deploy

### 1. Generate a Security Key

```bash
openssl rand -base64 32
```

### 2. Update values.yaml

Edit `values.yaml` and change:

```yaml
config:
  securityKey: "YOUR-RANDOM-KEY-HERE"  # ← Put your key here
  
ingress:
  hosts:
    - host: thumbor.studio.local       # ← Change to your domain
      paths:
        - path: /
          pathType: Prefix
  tls:
    - secretName: thumbor-tls
      hosts:
        - thumbor.studio.local         # ← Change to your domain
```

## Installation Options

### Option 1: Quick Install (Development)

```bash
cd thumbor-chart
./install.sh wopr thumbor
```

### Option 2: Manual Install

```bash
# Create namespace
kubectl create namespace wopr

# Install chart
helm install thumbor ./thumbor-chart -n wopr

# Or upgrade if already installed
helm upgrade thumbor ./thumbor-chart -n wopr
```

### Option 3: Production Deployment

```bash
# 1. Copy production template
cp values-production.yaml values-prod.yaml

# 2. Edit values-prod.yaml
#    - Change securityKey
#    - Set allowUnsafeUrl: false
#    - Update ingress hostname
#    - Adjust resource limits
#    - Configure storage class

# 3. Install with production values
helm install thumbor ./thumbor-chart \
  -n wopr \
  -f values-prod.yaml
```

## Verification

### Run Tests

```bash
./test.sh wopr thumbor
```

### Manual Verification

```bash
# Check pod status
kubectl get pods -n wopr -l app.kubernetes.io/name=thumbor

# View logs
kubectl logs -n wopr -l app.kubernetes.io/name=thumbor

# Test healthcheck
kubectl exec -n wopr deployment/thumbor-thumbor -- \
  curl http://localhost:8000/healthcheck

# Port-forward for local testing
kubectl port-forward -n wopr svc/thumbor-thumbor 8000:8000

# Test from your machine
curl http://localhost:8000/healthcheck
```

## Usage Examples

### Unsafe URLs (Development Only)

**⚠️ INSECURE - Only use for testing!**

```bash
# Resize to 300x200
http://thumbor.studio.local/unsafe/300x200/https://picsum.photos/800/600

# With filters
http://thumbor.studio.local/unsafe/300x200/filters:quality(90):sharpen(2,1.0,true)/https://picsum.photos/800/600

# Smart crop
http://thumbor.studio.local/unsafe/300x200/smart/https://picsum.photos/800/600
```

### Signed URLs (Production)

```python
from thumbor_url import Signer

signer = Signer('your-security-key-here')
url = signer.url_for(
    'https://example.com/image.jpg',
    width=300,
    height=200,
    filters=['quality(90)', 'sharpen(2,1.0,true)']
)
print(url)
```

## Integration with WOPR

### Example API Call

```python
import requests

# Process a game board image
response = requests.get(
    'http://thumbor.studio.local/unsafe/1920x1080/smart/'
    'http://wopr-cam:8000/captures/game-board-001.jpg'
)

with open('processed-board.jpg', 'wb') as f:
    f.write(response.content)
```

### In wopr-api

```python
# config.py
THUMBOR_URL = "http://thumbor-thumbor.wopr.svc.cluster.local:8000"
THUMBOR_SECURITY_KEY = os.getenv("THUMBOR_SECURITY_KEY")

# image_processor.py
from thumbor_url import Signer

def process_game_image(source_url, width=1920, height=1080):
    signer = Signer(THUMBOR_SECURITY_KEY)
    url = signer.url_for(
        source_url,
        width=width,
        height=height,
        smart=True,
        filters=['quality(95)', 'sharpen(2,1.0,true)']
    )
    return f"{THUMBOR_URL}{url}"
```

## Common Filters

- `quality(N)` - JPEG quality (1-100)
- `format(webp|jpeg|png)` - Convert format
- `sharpen(amount, radius, luminance)` - Sharpen image
- `blur(radius)` - Blur effect
- `brightness(amount)` - Adjust brightness (-100 to 100)
- `contrast(amount)` - Adjust contrast (-100 to 100)
- `grayscale()` - Convert to grayscale
- `rotate(degrees)` - Rotate image

## Troubleshooting

### Pod Not Starting

```bash
# Check events
kubectl describe pod -n wopr -l app.kubernetes.io/name=thumbor

# Check logs
kubectl logs -n wopr -l app.kubernetes.io/name=thumbor
```

### Images Not Processing

1. Verify source URL is accessible from pod
2. Check storage permissions
3. Review pod logs for errors
4. Test healthcheck endpoint

### Permission Errors

The pod runs as user 1000. Ensure your PV supports this:

```bash
# Check PVC
kubectl get pvc -n wopr thumbor-thumbor

# If needed, fix permissions on the PV
kubectl exec -n wopr deployment/thumbor-thumbor -- \
  chown -R 1000:1000 /data
```

## Production Checklist

- [ ] Generate strong random security key
- [ ] Set `allowUnsafeUrl: false`
- [ ] Configure proper ingress hostname
- [ ] Enable TLS with valid certificate
- [ ] Set appropriate resource limits
- [ ] Configure fast storage class
- [ ] Enable monitoring/alerting
- [ ] Test signed URL generation
- [ ] Document security key location
- [ ] Configure backup for PVC

## Uninstall

```bash
# Remove Helm release
helm uninstall thumbor -n wopr

# Optionally delete PVC
kubectl delete pvc thumbor-thumbor -n wopr

# Delete namespace (if desired)
kubectl delete namespace wopr
```

## Next Steps

1. Deploy to your studio cluster
2. Test with sample images
3. Integrate with wopr-api for image preprocessing
4. Configure production security settings
5. Set up monitoring and alerts

## Need Help?

- [Thumbor Documentation](https://thumbor.readthedocs.io/)
- [Filters Guide](https://thumbor.readthedocs.io/en/latest/filters.html)
- [MinimalCompact/thumbor](https://github.com/MinimalCompact/thumbor)

---

**Remember:** This is part of the WOPR computer vision pipeline. Thumbor handles the preprocessing - resizing, optimizing, and filtering images before they hit the ML models for piece detection.

*"Shall we play a game?"* - WOPR (WarGames, 1983)
