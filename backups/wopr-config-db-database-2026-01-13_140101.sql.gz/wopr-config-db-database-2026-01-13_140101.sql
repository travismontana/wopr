Defaulted container "postgres" out of: postgres, bootstrap-controller (init)
pg_dump: executing SELECT pg_catalog.set_config('search_path', '', false);
pg_dump: last built-in OID is 16383
pg_dump: reading extensions
pg_dump: identifying extension members
pg_dump: reading schemas
pg_dump: reading user-defined tables
pg_dump: reading user-defined functions
pg_dump: reading user-defined types
pg_dump: reading procedural languages
pg_dump: reading user-defined aggregate functions
pg_dump: reading user-defined operators
pg_dump: reading user-defined access methods
pg_dump: reading user-defined operator classes
pg_dump: reading user-defined operator families
pg_dump: reading user-defined text search parsers
pg_dump: reading user-defined text search templates
pg_dump: reading user-defined text search dictionaries
pg_dump: reading user-defined text search configurations
pg_dump: reading user-defined foreign-data wrappers
pg_dump: reading user-defined foreign servers
pg_dump: reading default privileges
pg_dump: reading user-defined collations
pg_dump: reading user-defined conversions
pg_dump: reading type casts
pg_dump: reading transforms
pg_dump: reading table inheritance information
pg_dump: reading event triggers
pg_dump: finding extension tables
pg_dump: finding inheritance relationships
pg_dump: reading column info for interesting tables
pg_dump: finding table default expressions
pg_dump: flagging inherited columns in subtables
pg_dump: reading partitioning data
pg_dump: reading indexes
pg_dump: flagging indexes in partitioned tables
pg_dump: reading extended statistics
pg_dump: reading constraints
pg_dump: reading triggers
pg_dump: reading rewrite rules
pg_dump: reading policies
pg_dump: reading row-level security policies
pg_dump: reading publications
pg_dump: reading publication membership of tables
pg_dump: reading publication membership of schemas
pg_dump: reading subscriptions
pg_dump: reading subscription membership of tables
pg_dump: reading large objects
pg_dump: reading dependency data
pg_dump: saving encoding = UTF8
pg_dump: saving "standard_conforming_strings = on"
pg_dump: saving "search_path = "
pg_dump: saving database definition
--
-- PostgreSQL database dump
--

\restrict TEyCtzuvIV4z0F803m43mCiDWYqI4aOu6GBaOmHG4ohzAbC6AKBsoU3LJd9gwM5

-- Dumped from database version 18.1 (Debian 18.1-1.pgdg13+2)
-- Dumped by pg_dump version 18.1 (Debian 18.1-1.pgdg13+2)

-- Started on 2026-01-13 20:01:03 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS "wopr-config-db-database";
--
-- TOC entry 4124 (class 1262 OID 16427)
-- Name: wopr-config-db-database; Type: DATABASE; Schema: -; Owner: wopr-config-db-user
--

CREATE DATABASE "wopr-config-db-database" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE "wopr-config-db-database" OWNER TO "wopr-config-db-user";

\unrestrict TEyCtzuvIV4z0F803m43mCiDWYqI4aOu6GBaOmHG4ohzAbC6AKBsoU3LJd9gwM5
\encoding SQL_ASCII
\connect -reuse-previous=on "dbname='wopr-config-db-database'"
\restrict TEyCtzuvIV4z0F803m43mCiDWYqI4aOu6GBaOmHG4ohzAbC6AKBsoU3LJd9gwM5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 222 (class 1259 OID 17426)
-- Name: config_history; Type: TABLE; Schema: public; Owner: wopr-config-db-user
--

CREATE TABLE public.config_history (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    old_value jsonb,
    new_value jsonb,
    changed_by character varying(100),
    changed_at timestamp without time zone DEFAULT now(),
    environment character varying(50) DEFAULT 'default'::character varying
);


ALTER TABLE public.config_history OWNER TO "wopr-config-db-user";

--
-- TOC entry 221 (class 1259 OID 17425)
-- Name: config_history_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-config-db-user
--

CREATE SEQUENCE public.config_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.config_history_id_seq OWNER TO "wopr-config-db-user";

--
-- TOC entry 4125 (class 0 OID 0)
-- Dependencies: 221
-- Name: config_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wopr-config-db-user
--

ALTER SEQUENCE public.config_history_id_seq OWNED BY public.config_history.id;


--
-- TOC entry 220 (class 1259 OID 17404)
-- Name: settings; Type: TABLE; Schema: public; Owner: wopr-config-db-user
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    value jsonb NOT NULL,
    value_type character varying(50) NOT NULL,
    description text,
    environment character varying(50) DEFAULT 'default'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    updated_by character varying(100)
);


ALTER TABLE public.settings OWNER TO "wopr-config-db-user";

--
-- TOC entry 219 (class 1259 OID 17403)
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-config-db-user
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.settings_id_seq OWNER TO "wopr-config-db-user";

--
-- TOC entry 4127 (class 0 OID 0)
-- Dependencies: 219
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wopr-config-db-user
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- TOC entry 3954 (class 2604 OID 17429)
-- Name: config_history id; Type: DEFAULT; Schema: pubpg_dump: dropping DATABASE wopr-config-db-database
pg_dump: creating DATABASE "wopr-config-db-database"
pg_dump: connecting to new database "wopr-config-db-database"
pg_dump: creating TABLE "public.config_history"
pg_dump: creating SEQUENCE "public.config_history_id_seq"
pg_dump: creating SEQUENCE OWNED BY "public.config_history_id_seq"
pg_dump: creating TABLE "public.settings"
pg_dump: creating SEQUENCE "public.settings_id_seq"
pg_dump: creating SEQUENCE OWNED BY "public.settings_id_seq"
pg_dump: creating DEFAULT "public.config_history id"
pg_dump: creating DEFAULT "public.settings id"
pg_dump: processing data for table "public.config_history"
pg_dump: dumping contents of table "public.config_history"
pg_dump: processing data for table "public.settings"
pg_dump: dumping contents of table "public.settings"
pg_dump: executing SEQUENCE SET config_history_id_seq
pg_dump: executing SEQUENCE SET settings_id_seq
pg_dump: creating CONSTRAINT "public.config_history config_history_pkey"
pg_dump: creating CONSTRAINT "public.settings settings_key_environment_key"
pg_dump: creating CONSTRAINT "public.settings settings_pkey"
pg_dump: creating INDEX "public.idx_history_changed_at"
pg_dump: creating INDEX "public.idx_history_key"
pg_dump: creating INDEX "public.idx_settings_environment"
pg_dump: creating INDEX "public.idx_settings_key"
pg_dump: creating INDEX "public.idx_settings_key_env"
pg_dump: creating ACL "public.TABLE settings"
pg_dump: creating ACL "public.SEQUENCE settings_id_seq"
lic; Owner: wopr-config-db-user
--

ALTER TABLE ONLY public.config_history ALTER COLUMN id SET DEFAULT nextval('public.config_history_id_seq'::regclass);


--
-- TOC entry 3950 (class 2604 OID 17407)
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: wopr-config-db-user
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- TOC entry 4118 (class 0 OID 17426)
-- Dependencies: 222
-- Data for Name: config_history; Type: TABLE DATA; Schema: public; Owner: wopr-config-db-user
--

COPY public.config_history (id, key, old_value, new_value, changed_by, changed_at, environment) FROM stdin;
\.


--
-- TOC entry 4116 (class 0 OID 17404)
-- Dependencies: 220
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: wopr-config-db-user
--

COPY public.settings (id, key, value, value_type, description, environment, created_at, updated_at, updated_by) FROM stdin;
1	storage.base_path	"/remote/wopr"	string	Base storage path for images	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
2	storage.games_subdir	"games"	string	Subdirectory for game data	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
3	storage.default_extension	"jpg"	string	Default image extension	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
4	storage.image_extensions	["jpg", "png"]	list	Allowed image extensions	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
5	storage.ensure_directories	true	boolean	Auto-create directories	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
6	storage.thumbnail_size	[480, 480]	list	Thumbnail dimensions [width, height]	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
7	filenames.timestamp_format	"%Y%m%d-%H%M%S"	string	Timestamp format for filenames	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
8	filenames.image_template	"{timestamp}-{subject}.{extension}"	string	Image filename template	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
9	filenames.image_with_sequence_template	"{timestamp}-{subject}-{sequence:03d}.{extension}"	string	Image filename template with sequence	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
10	filenames.thumbnail_template	"{timestamp}-{subject}-thumb.{extension}"	string	Thumbnail filename template	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
11	camera.default_resolution	"4k"	string	Default camera resolution	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
12	camera.resolutions.4k.width	4608	integer	4K width	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
13	camera.resolutions.4k.height	2592	integer	4K height	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
14	camera.resolutions.1080p.width	1920	integer	1080p width	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
15	camera.resolutions.1080p.height	1080	integer	1080p height	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
16	camera.resolutions.720p.width	1280	integer	720p width	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
17	camera.resolutions.720p.height	720	integer	720p height	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
18	camera.capture_delay_seconds	2	integer	Delay before capture	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
19	camera.default_format	"RGB888"	string	Default image format	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
20	camera.buffer_count	2	integer	Camera buffer count	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
21	logging.default_level	"INFO"	string	Default log level	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
22	logging.format	"%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s"	string	Log format string	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
23	logging.date_format	"%Y-%m-%d %H:%M:%S"	string	Log date format	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
24	logging.default_log_dir	"/var/log/wopr"	string	Default log directory	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
25	api.host	"0.0.0.0"	string	API host	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
26	api.port	8000	integer	API port	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
27	api.camera_service_url	"http://raspberrypi.local:5000"	string	Camera service URL	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
28	api.camera_timeout_seconds	30	integer	Camera request timeout	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
29	api.ollama_url	"http://desktop:11434"	string	Ollama service URL	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
30	api.ollama_timeout_seconds	60	integer	Ollama request timeout	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
31	vision.default_model	"qwen2-vl:7b"	string	Default vision model	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
32	vision.opencv_change_threshold	30	integer	OpenCV change detection threshold	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
33	vision.min_change_area_pixels	1000	integer	Minimum change area in pixels	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
34	vision.gaussian_blur_kernel	[21, 21]	list	Gaussian blur kernel size	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
35	vision.morphology_kernel	[5, 5]	list	Morphology kernel size	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
36	vision.morphology_iterations.dilate	2	integer	Dilate iterations	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
37	vision.morphology_iterations.erode	1	integer	Erode iterations	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
38	database.connection_pool_size	5	integer	Connection pool size	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
39	database.connection_timeout_seconds	30	integer	Connection timeout	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
40	database.max_overflow	10	integer	Max overflow connections	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
41	game_types	[{"id": "dune_imperium", "display_name": "Dune Imperium"}, {"id": "star_wars_legion", "display_name": "Star Wars Legion"}]	list	Supported game types	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
42	game_statuses	["setup", "in_progress", "completed", "abandoned"]	list	Valid game statuses	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
43	analysis_statuses	["pending", "processing", "completed", "failed"]	list	Valid analysis statuses	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
44	image_subjects	["setup", "capture", "move", "thumbnail"]	list	Valid image subject types	default	2026-01-03 06:18:34.835959	2026-01-03 06:18:34.835959	\N
89	test2	"{}"	string	Updated	default	2026-01-04 17:16:20.217252	2026-01-04 17:16:24.997892	\N
79	object	"{}"	string	Updated	default	2026-01-04 16:50:37.592433	2026-01-04 16:50:44.698861	\N
83	test	"test"	string	Updated	default	2026-01-04 16:53:14.927799	2026-01-04 17:10:06.591125	\N
97	test44	"[]"	string	Updated	default	2026-01-04 17:31:29.515176	2026-01-04 17:33:03.167398	\N
93	test3	"[]"	string	Updated	default	2026-01-04 17:26:53.866185	2026-01-04 17:26:59.061923	\N
\.


--
-- TOC entry 4129 (class 0 OID 0)
-- Dependencies: 221
-- Name: config_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-config-db-user
--

SELECT pg_catalog.setval('public.config_history_id_seq', 1, false);


--
-- TOC entry 4130 (class 0 OID 0)
-- Dependencies: 219
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-config-db-user
--

SELECT pg_catalog.setval('public.settings_id_seq', 100, true);


--
-- TOC entry 3965 (class 2606 OID 17437)
-- Name: config_history config_history_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-config-db-user
--

ALTER TABLE ONLY public.config_history
    ADD CONSTRAINT config_history_pkey PRIMARY KEY (id);


--
-- TOC entry 3961 (class 2606 OID 17421)
-- Name: settings settings_key_environment_key; Type: CONSTRAINT; Schema: public; Owner: wopr-config-db-user
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_key_environment_key UNIQUE (key, environment);


--
-- TOC entry 3963 (class 2606 OID 17419)
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-config-db-user
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- TOC entry 3966 (class 1259 OID 17439)
-- Name: idx_history_changed_at; Type: INDEX; Schema: public; Owner: wopr-config-db-user
--

CREATE INDEX idx_history_changed_at ON public.config_history USING btree (changed_at);


--
-- TOC entry 3967 (class 1259 OID 17438)
-- Name: idx_history_key; Type: INDEX; Schema: public; Owner: wopr-config-db-user
--

CREATE INDEX idx_history_key ON public.config_history USING btree (key);


--
-- TOC entry 3957 (class 1259 OID 17423)
-- Name: idx_settings_environment; Type: INDEX; Schema: public; Owner: wopr-config-db-user
--

CREATE INDEX idx_settings_environment ON public.settings USING btree (environment);


--
-- TOC entry 3958 (class 1259 OID 17422)
-- Name: idx_settings_key; Type: INDEX; Schema: public; Owner: wopr-config-db-user
--

CREATE INDEX idx_settings_key ON public.settings USING btree (key);


--
-- TOC entry 3959 (class 1259 OID 17424)
-- Name: idx_settings_key_env; Type: INDEX; Schema: public; Owner: wopr-config-db-user
--

CREATE INDEX idx_settings_key_env ON public.settings USING btree (key, environment);


--
-- TOC entry 4126 (class 0 OID 0)
-- Dependencies: 220
-- Name: TABLE settings; Type: ACL; Schema: public; Owner: wopr-config-db-user
--

GRANT ALL ON TABLE public.settings TO app;


--
-- TOC entry 4128 (class 0 OID 0)
-- Dependencies: 219
-- Name: SEQUENCE settings_id_seq; Type: ACL; Schema: public; Owner: wopr-config-db-user
--

GRANT ALL ON SEQUENCE public.settings_id_seq TO app;


-- Completed on 2026-01-13 20:01:03 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict TEyCtzuvIV4z0F803m43mCiDWYqI4aOu6GBaOmHG4ohzAbC6AKBsoU3LJd9gwM5

