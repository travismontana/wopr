Defaulted container "postgres" out of: postgres, bootstrap-controller (init)
pg_dump: executing SELECT pg_catalog.set_config('search_path', '', false);
pg_dump: last built-in OID is 16383
pg_dump: reading extensions
pg_dump: identifying extension members
pg_dump: reading schemas
pg_dump: reading user-defined tables
pg_dump: reading user-defined functions
pg_dump: reading user-defined types
pg_dump: reading procedural languages
pg_dump: reading user-defined aggregate functions
pg_dump: reading user-defined operators
pg_dump: reading user-defined access methods
pg_dump: reading user-defined operator classes
pg_dump: reading user-defined operator families
pg_dump: reading user-defined text search parsers
pg_dump: reading user-defined text search templates
pg_dump: reading user-defined text search dictionaries
pg_dump: reading user-defined text search configurations
pg_dump: reading user-defined foreign-data wrappers
pg_dump: reading user-defined foreign servers
pg_dump: reading default privileges
pg_dump: reading user-defined collations
pg_dump: reading user-defined conversions
pg_dump: reading type casts
pg_dump: reading transforms
pg_dump: reading table inheritance information
pg_dump: reading event triggers
pg_dump: finding extension tables
pg_dump: finding inheritance relationships
pg_dump: reading column info for interesting tables
pg_dump: finding table default expressions
pg_dump: finding table check constraints
pg_dump: flagging inherited columns in subtables
pg_dump: reading partitioning data
pg_dump: reading indexes
pg_dump: flagging indexes in partitioned tables
pg_dump: reading extended statistics
pg_dump: reading constraints
pg_dump: reading triggers
pg_dump: reading rewrite rules
pg_dump: reading policies
pg_dump: reading row-level security policies
pg_dump: reading publications
pg_dump: reading publication membership of tables
pg_dump: reading publication membership of schemas
pg_dump: reading subscriptions
pg_dump: reading subscription membership of tables
pg_dump: reading large objects
pg_dump: reading dependency data
pg_dump: saving encoding = UTF8
pg_dump: saving "standard_conforming_strings = on"
pg_dump: saving "search_path = "
pg_dump: saving database definition
pg_dump: dropping DATABASE wopr-labelstudio-db-database
pg_dump: creating DATABASE "wopr-labelstudio-db-database"
pg_dump: connecting to new database "wopr-labelstudio-db-database"
pg_dump: creating EXTENSION "btree_gin"
pg_dump: creating COMMENT "EXTENSION btree_gin"
pg_dump: creating EXTENSION "pg_trgm"
pg_dump: creating COMMENT "EXTENSION pg_trgm"
pg_dump: creating TABLE "public.auth_group"
pg_dump: creating SEQUENCE "public.auth_group_id_seq"
pg_dump: creating TABLE "public.auth_group_permissions"
pg_dump: creating SEQUENCE "public.auth_group_permissions_id_seq"
pg_dump: creating TABLE "public.auth_permission"
pg_dump: creating SEQUENCE "public.auth_permission_id_seq"
pg_dump: creating TABLE "public.authtoken_token"
pg_dump: creating TABLE "public.core_asyncmigrationstatus"
pg_dump: creating SEQUENCE "public.core_asyncmigrationstatus_id_seq"
pg_dump: creating TABLE "public.core_deletedrow"
pg_dump: creating SEQUENCE "public.core_deletedrow_id_seq"
pg_dump: creating TABLE "public.data_export_convertedformat"
pg_dump: creating SEQUENCE "public.data_export_convertedformat_id_seq"
pg_dump: creating TABLE "public.data_export_export"
pg_dump: creating SEQUENCE "public.data_export_export_id_seq"
pg_dump: creating TABLE "public.data_import_fileupload"
pg_dump: creating SEQUENCE "public.data_import_fileupload_id_seq"
pg_dump: creating TABLE "public.data_manager_filter"
pg_dump: creating SEQUENCE "public.data_manager_filter_id_seq"
pg_dump: creating TABLE "public.data_manager_filtergroup"
pg_dump: creating TABLE "public.data_manager_filtergroup_filters"
pg_dump: creating SEQUENCE "public.data_manager_filtergroup_filters_id_seq"
pg_dump: creating SEQUENCE "public.data_manager_filtergroup_id_seq"
pg_dump: creating TABLE "public.data_manager_view"
pg_dump: creating SEQUENCE "public.data_manager_view_id_seq"
pg_dump: creating TABLE "public.django_admin_log"
pg_dump: creating SEQUENCE "public.django_admin_log_id_seq"
pg_dump: creating TABLE "public.django_content_type"
pg_dump: creating SEQUENCE "public.django_content_type_id_seq"
pg_dump: creating TABLE "public.django_migrations"
pg_dump: creating SEQUENCE "public.django_migrations_id_seq"
pg_dump: creating TABLE "public.django_session"
pg_dump: creating TABLE "public.fsm_annotationstate"
pg_dump: creating TABLE "public.fsm_projectstate"
pg_dump: creating TABLE "public.fsm_taskstate"
pg_dump: creating TABLE "public.htx_user"
pg_dump: creating TABLE "public.htx_user_groups"
pg_dump: creating SEQUENCE "public.htx_user_groups_id_seq"
pg_dump: creating SEQUENCE "public.htx_user_id_seq"
pg_dump: creating TABLE "public.htx_user_user_permissions"
pg_dump: creating SEQUENCE "public.htx_user_user_permissions_id_seq"
pg_dump: creating TABLE "public.io_storages_azureblobexportstorage"
pg_dump: creating TABLE "public.io_storages_azureblobexportstoragelink"
pg_dump: creating SEQUENCE "public.io_storages_azureblobexportstoragelink_id_seq"
pg_dump: creating TABLE "public.io_storages_azureblobimportstorage"
pg_dump: creating TABLE "public.io_storages_azureblobimportstoragelink"
pg_dump: creating SEQUENCE "public.io_storages_azureblobimportstoragelink_id_seq"
pg_dump: creating TABLE "public.io_storages_azureblobstoragemixin"
pg_dump: creating SEQUENCE "public.io_storages_azureblobstoragemixin_id_seq"
pg_dump: creating TABLE "public.io_storages_gcsexportstorage"
pg_dump: creating TABLE "public.io_storages_gcsexportstoragelink"
pg_dump: creating SEQUENCE "public.io_storages_gcsexportstoragelink_id_seq"
pg_dump: creating TABLE "public.io_storages_gcsimportstorage"
pg_dump: creating TABLE "public.io_storages_gcsimportstoragelink"
pg_dump: creating SEQUENCE "public.io_storages_gcsimportstoragelink_id_seq"
pg_dump: creating TABLE "public.io_storages_gcsstoragemixin"
pg_dump: creating SEQUENCE "public.io_storages_gcsstoragemixin_id_seq"
pg_dump: creating TABLE "public.io_storages_localfilesexportstorage"
pg_dump: creating TABLE "public.io_storages_localfilesexportstoragelink"
pg_dump: creating SEQUENCE "public.io_storages_localfilesexportstoragelink_id_seq"
pg_dump: creating TABLE "public.io_storages_localfilesimportstorage"
pg_dump: creating TABLE "public.io_storages_localfilesimportstoragelink"
pg_dump: creating SEQUENCE "public.io_storages_localfilesimportstoragelink_id_seq"
pg_dump: creating TABLE "public.io_storages_localfilesmixin"
pg_dump: creating SEQUENCE "public.io_storages_localfilesmixin_id_seq"
pg_dump: creating TABLE "public.io_storages_redisexportstorage"
pg_dump: creating TABLE "public.io_storages_redisexportstoragelink"
pg_dump: creating SEQUENCE "public.io_storages_redisexportstoragelink_id_seq"
pg_dump: creating TABLE "public.io_storages_redisimportstorage"
pg_dump: creating TABLE "public.io_storages_redisimportstoragelink"
pg_dump: creating SEQUENCE "public.io_storages_redisimportstoragelink_id_seq"
pg_dump: creating TABLE "public.io_storages_redisstoragemixin"
pg_dump: creating SEQUENCE "public.io_storages_redisstoragemixin_id_seq"
pg_dump: creating TABLE "public.io_storages_s3exportstorage"
pg_dump: creating SEQUENCE "public.io_storages_s3exportstorage_id_seq"
pg_dump: creating TABLE "public.io_storages_s3exportstoragelink"
pg_dump: creating SEQUENCE "public.io_storages_s3exportstoragelink_id_seq"
pg_dump: creating TABLE "public.io_storages_s3importstorage"
pg_dump: creating SEQUENCE "public.io_storages_s3importstorage_id_seq"
pg_dump: creating TABLE "public.io_storages_s3importstoragelink"
pg_dump: creating SEQUENCE "public.io_storages_s3importstoragelink_id_seq"
pg_dump: creating TABLE "public.jwt_auth_jwtsettings"
pg_dump: creating TABLE "public.labels_manager_label"
pg_dump: creating SEQUENCE "public.labels_manager_label_id_seq"
pg_dump: creating TABLE "public.labels_manager_labellink"
pg_dump: creating SEQUENCE "public.labels_manager_labellink_id_seq"
pg_dump: creating TABLE "public.ml_mlbackend"
pg_dump: creating SEQUENCE "public.ml_mlbackend_id_seq"
pg_dump: creating TABLE "public.ml_mlbackendpredictionjob"
pg_dump: creating SEQUENCE "public.ml_mlbackendpredictionjob_id_seq"
pg_dump: creating TABLE "public.ml_mlbackendtrainjob"
pg_dump: creating SEQUENCE "public.ml_mlbackendtrainjob_id_seq"
pg_dump: creating TABLE "public.ml_model_providers_modelproviderconnection"
pg_dump: creating SEQUENCE "public.ml_model_providers_modelproviderconnection_id_seq"
pg_dump: creating TABLE "public.ml_models_modelinterface"
pg_dump: creating TABLE "public.ml_models_modelinterface_associated_projects"
pg_dump: creating SEQUENCE "public.ml_models_modelinterface_associated_projects_id_seq"
pg_dump: creating SEQUENCE "public.ml_models_modelinterface_id_seq"
pg_dump: creating TABLE "public.ml_models_modelrun"
pg_dump: creating SEQUENCE "public.ml_models_modelrun_id_seq"
pg_dump: creating TABLE "public.ml_models_thirdpartymodelversion"
pg_dump: creating SEQUENCE "public.ml_models_thirdpartymodelversion_id_seq"
pg_dump: creating TABLE "public.organization"
pg_dump: creating SEQUENCE "public.organization_id_seq"
pg_dump: creating TABLE "public.organizations_organizationmember"
pg_dump: creating SEQUENCE "public.organizations_organizationmember_id_seq"
pg_dump: creating TABLE "public.prediction"
pg_dump: creating SEQUENCE "public.prediction_id_seq"
pg_dump: creating TABLE "public.prediction_meta"
pg_dump: creating SEQUENCE "public.prediction_meta_id_seq"
pg_dump: creating TABLE "public.project"
pg_dump: creating SEQUENCE "public.project_id_seq"
pg_dump: creating TABLE "public.projects_labelstreamhistory"
pg_dump: creating SEQUENCE "public.projects_labelstreamhistory_id_seq"
pg_dump: creating TABLE "public.projects_projectimport"
pg_dump: creating SEQUENCE "public.projects_projectimport_id_seq"
pg_dump: creating TABLE "public.projects_projectmember"
pg_dump: creating SEQUENCE "public.projects_projectmember_id_seq"
pg_dump: creating TABLE "public.projects_projectonboarding"
pg_dump: creating SEQUENCE "public.projects_projectonboarding_id_seq"
pg_dump: creating TABLE "public.projects_projectonboardingsteps"
pg_dump: creating SEQUENCE "public.projects_projectonboardingsteps_id_seq"
pg_dump: creating TABLE "public.projects_projectreimport"
pg_dump: creating SEQUENCE "public.projects_projectreimport_id_seq"
pg_dump: creating TABLE "public.projects_projectsummary"
pg_dump: creating TABLE "public.session_policy_sessiontimeoutpolicy"
pg_dump: creating TABLE "public.task"
pg_dump: creating TABLE "public.task_comment_authors"
pg_dump: creating SEQUENCE "public.task_comment_authors_id_seq"
pg_dump: creating TABLE "public.task_completion"
pg_dump: creating SEQUENCE "public.task_completion_id_seq"
pg_dump: creating SEQUENCE "public.task_id_seq"
pg_dump: creating TABLE "public.tasks_annotationdraft"
pg_dump: creating TABLE "public.tasks_failedprediction"
pg_dump: creating SEQUENCE "public.tasks_failedprediction_id_seq"
pg_dump: creating SEQUENCE "public.tasks_taskcompletiondraft_id_seq"
pg_dump: creating TABLE "public.tasks_tasklock"
pg_dump: creating SEQUENCE "public.tasks_tasklock_id_seq"
pg_dump: creating TABLE "public.token_blacklist_blacklistedtoken"
pg_dump: creating SEQUENCE "public.token_blacklist_blacklistedtoken_id_seq"
pg_dump: creating TABLE "public.token_blacklist_outstandingtoken"
pg_dump: creating SEQUENCE "public.token_blacklist_outstandingtoken_id_seq"
pg_dump: creating TABLE "public.users_userproducttour"
pg_dump: creating SEQUENCE "public.users_userproducttour_id_seq"
pg_dump: creating TABLE "public.webhook"
pg_dump: creating TABLE "public.webhook_action"
pg_dump: creating SEQUENCE "public.webhook_action_id_seq"
pg_dump: creating SEQUENCE "public.webhook_id_seq"
pg_dump: processing data for table "public.auth_group"
pg_dump: dumping contents of table "public.auth_group"
--
-- PostgreSQL database dump
--

\restrict cbLmaJwmNesBagN0t0SGv2ak3rDqjOOM0ebMBVhNEIEFDPSzsoClaYaueoOhF6A

-- Dumped from database version 18.1 (Debian 18.1-1.pgdg13+2)
-- Dumped by pg_dump version 18.1 (Debian 18.1-1.pgdg13+2)

-- Started on 2026-01-13 20:01:04 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS "wopr-labelstudio-db-database";
--
-- TOC entry 5434 (class 1262 OID 24762)
-- Name: wopr-labelstudio-db-database; Type: DATABASE; Schema: -; Owner: wopr-labelstudio-db-user
--

CREATE DATABASE "wopr-labelstudio-db-database" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE "wopr-labelstudio-db-database" OWNER TO "wopr-labelstudio-db-user";

\unrestrict cbLmaJwmNesBagN0t0SGv2ak3rDqjOOM0ebMBVhNEIEFDPSzsoClaYaueoOhF6A
\encoding SQL_ASCII
\connect -reuse-previous=on "dbname='wopr-labelstudio-db-database'"
\restrict cbLmaJwmNesBagN0t0SGv2ak3rDqjOOM0ebMBVhNEIEFDPSzsoClaYaueoOhF6A

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3 (class 3079 OID 26335)
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- TOC entry 5435 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- TOC entry 2 (class 3079 OID 26078)
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- TOC entry 5436 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 228 (class 1259 OID 24798)
-- Name: auth_group; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 227 (class 1259 OID 24797)
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 230 (class 1259 OID 24808)
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 229 (class 1259 OID 24807)
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 226 (class 1259 OID 24788)
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 225 (class 1259 OID 24787)
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 239 (class 1259 OID 24949)
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 254 (class 1259 OID 25337)
-- Name: core_asyncmigrationstatus; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.core_asyncmigrationstatus (
    id integer NOT NULL,
    meta jsonb,
    name text NOT NULL,
    status character varying(100),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    project_id integer
);


ALTER TABLE public.core_asyncmigrationstatus OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 253 (class 1259 OID 25336)
-- Name: core_asyncmigrationstatus_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.core_asyncmigrationstatus ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_asyncmigrationstatus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 256 (class 1259 OID 25355)
-- Name: core_deletedrow; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.core_deletedrow (
    id integer NOT NULL,
    model character varying(1024) NOT NULL,
    row_id integer,
    data jsonb,
    reason text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    organization_id integer,
    project_id integer,
    user_id integer
);


ALTER TABLE public.core_deletedrow OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 255 (class 1259 OID 25354)
-- Name: core_deletedrow_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.core_deletedrow ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_deletedrow_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 262 (class 1259 OID 25425)
-- Name: data_export_convertedformat; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.data_export_convertedformat (
    id integer NOT NULL,
    file character varying(100),
    status character varying(64) NOT NULL,
    export_type character varying(64) NOT NULL,
    export_id integer NOT NULL,
    created_at timestamp with time zone,
    created_by_id integer,
    finished_at timestamp with time zone,
    organization_id integer,
    project_id integer,
    updated_at timestamp with time zone,
    traceback text
);


ALTER TABLE public.data_export_convertedformat OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 261 (class 1259 OID 25424)
-- Name: data_export_convertedformat_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.data_export_convertedformat ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.data_export_convertedformat_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 260 (class 1259 OID 25394)
-- Name: data_export_export; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.data_export_export (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    file character varying(100),
    md5 character varying(128) NOT NULL,
    finished_at timestamp with time zone,
    status character varying(64) NOT NULL,
    counters jsonb NOT NULL,
    created_by_id integer,
    project_id integer NOT NULL,
    title character varying(2048) NOT NULL
);


ALTER TABLE public.data_export_export OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 259 (class 1259 OID 25393)
-- Name: data_export_export_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.data_export_export ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.data_export_export_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 264 (class 1259 OID 25463)
-- Name: data_import_fileupload; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.data_import_fileupload (
    id integer NOT NULL,
    file character varying(100) NOT NULL,
    project_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.data_import_fileupload OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 263 (class 1259 OID 25462)
-- Name: data_import_fileupload_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.data_import_fileupload ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.data_import_fileupload_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 308 (class 1259 OID 26204)
-- Name: data_manager_filter; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.data_manager_filter (
    id integer NOT NULL,
    "column" character varying(1024) NOT NULL,
    type character varying(1024) NOT NULL,
    operator character varying(1024) NOT NULL,
    value jsonb,
    index integer,
    parent_id integer
);


ALTER TABLE public.data_manager_filter OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 307 (class 1259 OID 26203)
-- Name: data_manager_filter_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.data_manager_filter ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.data_manager_filter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 310 (class 1259 OID 26217)
-- Name: data_manager_filtergroup; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.data_manager_filtergroup (
    id integer NOT NULL,
    conjunction character varying(1024) NOT NULL
);


ALTER TABLE public.data_manager_filtergroup OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 312 (class 1259 OID 26227)
-- Name: data_manager_filtergroup_filters; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.data_manager_filtergroup_filters (
    id integer NOT NULL,
    filtergroup_id integer NOT NULL,
    filter_id integer NOT NULL
);


ALTER TABLE public.data_manager_filtergroup_filters OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 311 (class 1259 OID 26226)
-- Name: data_manager_filtergroup_filters_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.data_manager_filtergroup_filters ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.data_manager_filtergroup_filters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 309 (class 1259 OID 26216)
-- Name: data_manager_filtergroup_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.data_manager_filtergroup ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.data_manager_filtergroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 314 (class 1259 OID 26236)
-- Name: data_manager_view; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.data_manager_view (
    id integer NOT NULL,
    data jsonb,
    project_id integer NOT NULL,
    ordering jsonb,
    filter_group_id integer,
    selected_items jsonb,
    user_id integer,
    "order" integer
);


ALTER TABLE public.data_manager_view OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 313 (class 1259 OID 26235)
-- Name: data_manager_view_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.data_manager_view ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.data_manager_view_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 238 (class 1259 OID 24919)
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 237 (class 1259 OID 24918)
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 224 (class 1259 OID 24776)
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 223 (class 1259 OID 24775)
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 222 (class 1259 OID 24764)
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 221 (class 1259 OID 24763)
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 358 (class 1259 OID 27578)
-- Name: django_session; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 339 (class 1259 OID 27126)
-- Name: fsm_annotationstate; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.fsm_annotationstate (
    id uuid NOT NULL,
    organization_id integer,
    previous_state character varying(50),
    transition_name character varying(100),
    context_data jsonb NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    state character varying(50) NOT NULL,
    task_id integer NOT NULL,
    project_id integer NOT NULL,
    completed_by_id integer,
    annotation_id integer NOT NULL,
    triggered_by_id integer,
    CONSTRAINT fsm_annotationstate_completed_by_id_check CHECK ((completed_by_id >= 0)),
    CONSTRAINT fsm_annotationstate_organization_id_check CHECK ((organization_id >= 0)),
    CONSTRAINT fsm_annotationstate_project_id_check CHECK ((project_id >= 0)),
    CONSTRAINT fsm_annotationstate_task_id_check CHECK ((task_id >= 0))
);


ALTER TABLE public.fsm_annotationstate OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 340 (class 1259 OID 27145)
-- Name: fsm_projectstate; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.fsm_projectstate (
    id uuid NOT NULL,
    organization_id integer,
    previous_state character varying(50),
    transition_name character varying(100),
    context_data jsonb NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    state character varying(50) NOT NULL,
    created_by_id integer,
    project_id integer NOT NULL,
    triggered_by_id integer,
    CONSTRAINT fsm_projectstate_created_by_id_check CHECK ((created_by_id >= 0)),
    CONSTRAINT fsm_projectstate_organization_id_check CHECK ((organization_id >= 0))
);


ALTER TABLE public.fsm_projectstate OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 341 (class 1259 OID 27160)
-- Name: fsm_taskstate; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.fsm_taskstate (
    id uuid NOT NULL,
    organization_id integer,
    previous_state character varying(50),
    transition_name character varying(100),
    context_data jsonb NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    state character varying(50) NOT NULL,
    project_id integer NOT NULL,
    task_id integer NOT NULL,
    triggered_by_id integer,
    CONSTRAINT fsm_taskstate_organization_id_check CHECK ((organization_id >= 0)),
    CONSTRAINT fsm_taskstate_project_id_check CHECK ((project_id >= 0))
);


ALTER TABLE public.fsm_taskstate OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 232 (class 1259 OID 24841)
-- Name: htx_user; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.htx_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(256) NOT NULL,
    email character varying(254) NOT NULL,
    first_name character varying(256) NOT NULL,
    last_name character varying(256) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    last_activity timestamp with time zone NOT NULL,
    activity_at timestamp with time zone NOT NULL,
    phone character varying(256) NOT NULL,
    avatar character varying(100) NOT NULL,
    active_organization_id integer,
    allow_newsletters boolean,
    custom_hotkeys jsonb
);


ALTER TABLE public.htx_user OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 234 (class 1259 OID 24862)
-- Name: htx_user_groups; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.htx_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.htx_user_groups OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 233 (class 1259 OID 24861)
-- Name: htx_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.htx_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.htx_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 231 (class 1259 OID 24840)
-- Name: htx_user_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.htx_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.htx_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 236 (class 1259 OID 24871)
-- Name: htx_user_user_permissions; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.htx_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.htx_user_user_permissions OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 235 (class 1259 OID 24870)
-- Name: htx_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.htx_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.htx_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 285 (class 1259 OID 25707)
-- Name: io_storages_azureblobexportstorage; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_azureblobexportstorage (
    azureblobstoragemixin_ptr_id integer CONSTRAINT io_storages_azureblobexport_azureblobstoragemixin_ptr__not_null NOT NULL,
    title character varying(256),
    description text,
    created_at timestamp with time zone NOT NULL,
    project_id integer NOT NULL,
    last_sync timestamp with time zone,
    last_sync_count integer,
    can_delete_objects boolean,
    last_sync_job character varying(256),
    meta jsonb,
    status character varying(64) NOT NULL,
    traceback text,
    synchronizable boolean NOT NULL,
    CONSTRAINT io_storages_azureblobexportstorage_last_sync_count_check CHECK ((last_sync_count >= 0))
);


ALTER TABLE public.io_storages_azureblobexportstorage OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 306 (class 1259 OID 25881)
-- Name: io_storages_azureblobexportstoragelink; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_azureblobexportstoragelink (
    id integer NOT NULL,
    object_exists boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    annotation_id integer NOT NULL,
    storage_id integer NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.io_storages_azureblobexportstoragelink OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 305 (class 1259 OID 25880)
-- Name: io_storages_azureblobexportstoragelink_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_azureblobexportstoragelink ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_azureblobexportstoragelink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 286 (class 1259 OID 25717)
-- Name: io_storages_azureblobimportstorage; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_azureblobimportstorage (
    azureblobstoragemixin_ptr_id integer CONSTRAINT io_storages_azureblobimport_azureblobstoragemixin_ptr__not_null NOT NULL,
    title character varying(256),
    description text,
    created_at timestamp with time zone NOT NULL,
    presign boolean NOT NULL,
    presign_ttl smallint NOT NULL,
    project_id integer NOT NULL,
    last_sync timestamp with time zone,
    last_sync_count integer,
    last_sync_job character varying(256),
    meta jsonb,
    status character varying(64) NOT NULL,
    traceback text,
    synchronizable boolean NOT NULL,
    recursive_scan boolean DEFAULT false,
    CONSTRAINT io_storages_azureblobimportstorage_last_sync_count_check CHECK ((last_sync_count >= 0)),
    CONSTRAINT io_storages_azureblobimportstorage_presign_ttl_check CHECK ((presign_ttl >= 0))
);


ALTER TABLE public.io_storages_azureblobimportstorage OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 304 (class 1259 OID 25865)
-- Name: io_storages_azureblobimportstoragelink; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_azureblobimportstoragelink (
    id integer NOT NULL,
    key text NOT NULL,
    object_exists boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    task_id integer NOT NULL,
    storage_id integer NOT NULL,
    row_group integer,
    row_index integer
);


ALTER TABLE public.io_storages_azureblobimportstoragelink OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 303 (class 1259 OID 25864)
-- Name: io_storages_azureblobimportstoragelink_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_azureblobimportstoragelink ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_azureblobimportstoragelink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 276 (class 1259 OID 25651)
-- Name: io_storages_azureblobstoragemixin; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_azureblobstoragemixin (
    id integer NOT NULL,
    container text,
    prefix text,
    regex_filter text,
    use_blob_urls boolean NOT NULL,
    account_name text,
    account_key text
);


ALTER TABLE public.io_storages_azureblobstoragemixin OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 275 (class 1259 OID 25650)
-- Name: io_storages_azureblobstoragemixin_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_azureblobstoragemixin ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_azureblobstoragemixin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 287 (class 1259 OID 25730)
-- Name: io_storages_gcsexportstorage; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_gcsexportstorage (
    gcsstoragemixin_ptr_id integer NOT NULL,
    title character varying(256),
    description text,
    created_at timestamp with time zone NOT NULL,
    project_id integer NOT NULL,
    last_sync timestamp with time zone,
    last_sync_count integer,
    can_delete_objects boolean,
    last_sync_job character varying(256),
    meta jsonb,
    status character varying(64) NOT NULL,
    traceback text,
    synchronizable boolean NOT NULL,
    CONSTRAINT io_storages_gcsexportstorage_last_sync_count_check CHECK ((last_sync_count >= 0))
);


ALTER TABLE public.io_storages_gcsexportstorage OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 302 (class 1259 OID 25852)
-- Name: io_storages_gcsexportstoragelink; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_gcsexportstoragelink (
    id integer NOT NULL,
    object_exists boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    annotation_id integer NOT NULL,
    storage_id integer NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.io_storages_gcsexportstoragelink OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 301 (class 1259 OID 25851)
-- Name: io_storages_gcsexportstoragelink_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_gcsexportstoragelink ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_gcsexportstoragelink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 288 (class 1259 OID 25740)
-- Name: io_storages_gcsimportstorage; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_gcsimportstorage (
    gcsstoragemixin_ptr_id integer NOT NULL,
    title character varying(256),
    description text,
    created_at timestamp with time zone NOT NULL,
    presign boolean NOT NULL,
    presign_ttl smallint NOT NULL,
    project_id integer NOT NULL,
    last_sync timestamp with time zone,
    last_sync_count integer,
    last_sync_job character varying(256),
    meta jsonb,
    status character varying(64) NOT NULL,
    traceback text,
    synchronizable boolean NOT NULL,
    recursive_scan boolean DEFAULT false,
    CONSTRAINT io_storages_gcsimportstorage_last_sync_count_check CHECK ((last_sync_count >= 0)),
    CONSTRAINT io_storages_gcsimportstorage_presign_ttl_check CHECK ((presign_ttl >= 0))
);


ALTER TABLE public.io_storages_gcsimportstorage OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 300 (class 1259 OID 25836)
-- Name: io_storages_gcsimportstoragelink; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_gcsimportstoragelink (
    id integer NOT NULL,
    key text NOT NULL,
    object_exists boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    task_id integer NOT NULL,
    storage_id integer NOT NULL,
    row_group integer,
    row_index integer
);


ALTER TABLE public.io_storages_gcsimportstoragelink OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 299 (class 1259 OID 25835)
-- Name: io_storages_gcsimportstoragelink_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_gcsimportstoragelink ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_gcsimportstoragelink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 278 (class 1259 OID 25661)
-- Name: io_storages_gcsstoragemixin; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_gcsstoragemixin (
    id integer NOT NULL,
    bucket text,
    prefix text,
    regex_filter text,
    use_blob_urls boolean NOT NULL,
    google_application_credentials text,
    google_project_id text
);


ALTER TABLE public.io_storages_gcsstoragemixin OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 277 (class 1259 OID 25660)
-- Name: io_storages_gcsstoragemixin_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_gcsstoragemixin ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_gcsstoragemixin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 344 (class 1259 OID 27255)
-- Name: io_storages_localfilesexportstorage; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_localfilesexportstorage (
    localfilesmixin_ptr_id integer CONSTRAINT io_storages_localfilesexportsto_localfilesmixin_ptr_id_not_null NOT NULL,
    title character varying(256),
    description text,
    created_at timestamp with time zone NOT NULL,
    last_sync timestamp with time zone,
    last_sync_count integer,
    project_id integer NOT NULL,
    can_delete_objects boolean,
    last_sync_job character varying(256),
    meta jsonb,
    status character varying(64) NOT NULL,
    traceback text,
    synchronizable boolean NOT NULL,
    CONSTRAINT io_storages_localfilesexportstorage_last_sync_count_check CHECK ((last_sync_count >= 0))
);


ALTER TABLE public.io_storages_localfilesexportstorage OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 349 (class 1259 OID 27294)
-- Name: io_storages_localfilesexportstoragelink; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_localfilesexportstoragelink (
    id integer NOT NULL,
    object_exists boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    annotation_id integer NOT NULL,
    storage_id integer NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.io_storages_localfilesexportstoragelink OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 348 (class 1259 OID 27293)
-- Name: io_storages_localfilesexportstoragelink_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_localfilesexportstoragelink ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_localfilesexportstoragelink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 345 (class 1259 OID 27266)
-- Name: io_storages_localfilesimportstorage; Type: TABLEpg_dump: processing data for table "public.auth_group_permissions"
pg_dump: dumping contents of table "public.auth_group_permissions"
pg_dump: processing data for table "public.auth_permission"
pg_dump: dumping contents of table "public.auth_permission"
pg_dump: processing data for table "public.authtoken_token"
pg_dump: dumping contents of table "public.authtoken_token"
; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_localfilesimportstorage (
    localfilesmixin_ptr_id integer CONSTRAINT io_storages_localfilesimportsto_localfilesmixin_ptr_id_not_null NOT NULL,
    title character varying(256),
    description text,
    created_at timestamp with time zone NOT NULL,
    last_sync timestamp with time zone,
    last_sync_count integer,
    project_id integer NOT NULL,
    last_sync_job character varying(256),
    meta jsonb,
    status character varying(64) NOT NULL,
    traceback text,
    synchronizable boolean NOT NULL,
    recursive_scan boolean DEFAULT false,
    CONSTRAINT io_storages_localfilesimportstorage_last_sync_count_check CHECK ((last_sync_count >= 0))
);


ALTER TABLE public.io_storages_localfilesimportstorage OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 347 (class 1259 OID 27278)
-- Name: io_storages_localfilesimportstoragelink; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_localfilesimportstoragelink (
    id integer NOT NULL,
    key text NOT NULL,
    object_exists boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    task_id integer NOT NULL,
    storage_id integer NOT NULL,
    row_group integer,
    row_index integer
);


ALTER TABLE public.io_storages_localfilesimportstoragelink OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 346 (class 1259 OID 27277)
-- Name: io_storages_localfilesimportstoragelink_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_localfilesimportstoragelink ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_localfilesimportstoragelink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 343 (class 1259 OID 27246)
-- Name: io_storages_localfilesmixin; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_localfilesmixin (
    id integer NOT NULL,
    path text,
    regex_filter text,
    use_blob_urls boolean NOT NULL
);


ALTER TABLE public.io_storages_localfilesmixin OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 342 (class 1259 OID 27245)
-- Name: io_storages_localfilesmixin_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_localfilesmixin ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_localfilesmixin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 289 (class 1259 OID 25753)
-- Name: io_storages_redisexportstorage; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_redisexportstorage (
    redisstoragemixin_ptr_id integer CONSTRAINT io_storages_redisexportstorag_redisstoragemixin_ptr_id_not_null NOT NULL,
    title character varying(256),
    description text,
    created_at timestamp with time zone NOT NULL,
    db smallint NOT NULL,
    project_id integer NOT NULL,
    last_sync timestamp with time zone,
    last_sync_count integer,
    can_delete_objects boolean,
    last_sync_job character varying(256),
    meta jsonb,
    status character varying(64) NOT NULL,
    traceback text,
    synchronizable boolean NOT NULL,
    CONSTRAINT io_storages_redisexportstorage_db_check CHECK ((db >= 0)),
    CONSTRAINT io_storages_redisexportstorage_last_sync_count_check CHECK ((last_sync_count >= 0))
);


ALTER TABLE public.io_storages_redisexportstorage OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 298 (class 1259 OID 25823)
-- Name: io_storages_redisexportstoragelink; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_redisexportstoragelink (
    id integer NOT NULL,
    object_exists boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    annotation_id integer NOT NULL,
    storage_id integer NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.io_storages_redisexportstoragelink OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 297 (class 1259 OID 25822)
-- Name: io_storages_redisexportstoragelink_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_redisexportstoragelink ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_redisexportstoragelink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 290 (class 1259 OID 25765)
-- Name: io_storages_redisimportstorage; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_redisimportstorage (
    redisstoragemixin_ptr_id integer CONSTRAINT io_storages_redisimportstorag_redisstoragemixin_ptr_id_not_null NOT NULL,
    title character varying(256),
    description text,
    created_at timestamp with time zone NOT NULL,
    db smallint NOT NULL,
    project_id integer NOT NULL,
    last_sync timestamp with time zone,
    last_sync_count integer,
    last_sync_job character varying(256),
    meta jsonb,
    status character varying(64) NOT NULL,
    traceback text,
    synchronizable boolean NOT NULL,
    CONSTRAINT io_storages_redisimportstorage_db_check CHECK ((db >= 0)),
    CONSTRAINT io_storages_redisimportstorage_last_sync_count_check CHECK ((last_sync_count >= 0))
);


ALTER TABLE public.io_storages_redisimportstorage OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 296 (class 1259 OID 25807)
-- Name: io_storages_redisimportstoragelink; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_redisimportstoragelink (
    id integer NOT NULL,
    key text NOT NULL,
    object_exists boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    task_id integer NOT NULL,
    storage_id integer NOT NULL,
    row_group integer,
    row_index integer
);


ALTER TABLE public.io_storages_redisimportstoragelink OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 295 (class 1259 OID 25806)
-- Name: io_storages_redisimportstoragelink_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_redisimportstoragelink ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_redisimportstoragelink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 280 (class 1259 OID 25671)
-- Name: io_storages_redisstoragemixin; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_redisstoragemixin (
    id integer NOT NULL,
    path text,
    host text,
    port text,
    password text,
    regex_filter text,
    use_blob_urls boolean NOT NULL
);


ALTER TABLE public.io_storages_redisstoragemixin OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 279 (class 1259 OID 25670)
-- Name: io_storages_redisstoragemixin_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_redisstoragemixin ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_redisstoragemixin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 282 (class 1259 OID 25681)
-- Name: io_storages_s3exportstorage; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_s3exportstorage (
    id integer NOT NULL,
    title character varying(256),
    description text,
    created_at timestamp with time zone NOT NULL,
    bucket text,
    prefix text,
    regex_filter text,
    use_blob_urls boolean NOT NULL,
    aws_access_key_id text,
    aws_secret_access_key text,
    aws_session_token text,
    region_name text,
    s3_endpoint text,
    project_id integer NOT NULL,
    last_sync timestamp with time zone,
    last_sync_count integer,
    can_delete_objects boolean,
    last_sync_job character varying(256),
    meta jsonb,
    status character varying(64) NOT NULL,
    traceback text,
    synchronizable boolean NOT NULL,
    aws_sse_kms_key_id text,
    CONSTRAINT io_storages_s3exportstorage_last_sync_count_check CHECK ((last_sync_count >= 0))
);


ALTER TABLE public.io_storages_s3exportstorage OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 281 (class 1259 OID 25680)
-- Name: io_storages_s3exportstorage_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_s3exportstorage ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_s3exportstorage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 294 (class 1259 OID 25794)
-- Name: io_storages_s3exportstoragelink; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_s3exportstoragelink (
    id integer NOT NULL,
    object_exists boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    annotation_id integer NOT NULL,
    storage_id integer NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.io_storages_s3exportstoragelink OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 293 (class 1259 OID 25793)
-- Name: io_storages_s3exportstoragelink_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_s3exportstoragelink ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_s3exportstoragelink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 284 (class 1259 OID 25693)
-- Name: io_storages_s3importstorage; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_s3importstorage (
    id integer NOT NULL,
    title character varying(256),
    description text,
    created_at timestamp with time zone NOT NULL,
    bucket text,
    prefix text,
    regex_filter text,
    use_blob_urls boolean NOT NULL,
    aws_access_key_id text,
    aws_secret_access_key text,
    aws_session_token text,
    region_name text,
    s3_endpoint text,
    presign boolean NOT NULL,
    presign_ttl smallint NOT NULL,
    project_id integer NOT NULL,
    last_sync timestamp with time zone,
    last_sync_count integer,
    recursive_scan boolean NOT NULL,
    last_sync_job character varying(256),
    meta jsonb,
    status character varying(64) NOT NULL,
    traceback text,
    synchronizable boolean NOT NULL,
    aws_sse_kms_key_id text,
    CONSTRAINT io_storages_s3importstorage_last_sync_count_check CHECK ((last_sync_count >= 0)),
    CONSTRAINT io_storages_s3importstorage_presign_ttl_check CHECK ((presign_ttl >= 0))
);


ALTER TABLE public.io_storages_s3importstorage OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 283 (class 1259 OID 25692)
-- Name: io_storages_s3importstorage_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_s3importstorage ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_s3importstorage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 292 (class 1259 OID 25778)
-- Name: io_storages_s3importstoragelink; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.io_storages_s3importstoragelink (
    id integer NOT NULL,
    key text NOT NULL,
    object_exists boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    storage_id integer NOT NULL,
    task_id integer NOT NULL,
    row_group integer,
    row_index integer
);


ALTER TABLE public.io_storages_s3importstoragelink OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 291 (class 1259 OID 25777)
-- Name: io_storages_s3importstoragelink_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.io_storages_s3importstoragelink ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.io_storages_s3importstoragelink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 350 (class 1259 OID 27445)
-- Name: jwt_auth_jwtsettings; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.jwt_auth_jwtsettings (
    organization_id integer NOT NULL,
    api_tokens_enabled boolean NOT NULL,
    api_token_ttl_days integer NOT NULL,
    legacy_api_tokens_enabled boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.jwt_auth_jwtsettings OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 352 (class 1259 OID 27462)
-- Name: labels_manager_label; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.labels_manager_label (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    value jsonb NOT NULL,
    title character varying(2048) NOT NULL,
    description text,
    approved boolean NOT NULL,
    approved_by_id integer,
    created_by_id integer NOT NULL,
    organization_id integer NOT NULL
);


ALTER TABLE public.labels_manager_label OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 351 (class 1259 OID 27461)
-- Name: labels_manager_label_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.labels_manager_label ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.labels_manager_label_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 354 (class 1259 OID 27478)
-- Name: labels_manager_labellink; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.labels_manager_labellink (
    id integer NOT NULL,
    from_name character varying(2048) NOT NULL,
    label_id integer NOT NULL,
    project_id integer NOT NULL
);


ALTER TABLE public.labels_manager_labellink OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 353 (class 1259 OID 27477)
-- Name: labels_manager_labellink_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.labels_manager_labellink ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.labels_manager_labellink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 330 (class 1259 OID 26970)
-- Name: ml_mlbackend; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.ml_mlbackend (
    id integer NOT NULL,
    state character varying(2) NOT NULL,
    url text NOT NULL,
    error_message text,
    title text,
    description text,
    model_version text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    project_id integer NOT NULL,
    is_interactive boolean NOT NULL,
    timeout double precision NOT NULL,
    auto_update boolean NOT NULL,
    auth_method character varying(255) NOT NULL,
    basic_auth_pass text,
    basic_auth_user text,
    extra_params jsonb
);


ALTER TABLE public.ml_mlbackend OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 329 (class 1259 OID 26969)
-- Name: ml_mlbackend_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.ml_mlbackend ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ml_mlbackend_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 334 (class 1259 OID 26997)
-- Name: ml_mlbackendpredictionjob; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.ml_mlbackendpredictionjob (
    id integer NOT NULL,
    job_id character varying(128) NOT NULL,
    model_version text,
    batch_size smallint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    ml_backend_id integer NOT NULL,
    CONSTRAINT ml_mlbackendpredictionjob_batch_size_check CHECK ((batch_size >= 0))
);


ALTER TABLE public.ml_mlbackendpredictionjob OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 333 (class 1259 OID 26996)
-- Name: ml_mlbackendpredictionjob_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.ml_mlbackendpredictionjob ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ml_mlbackendpredictionjob_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 332 (class 1259 OID 26984)
-- Name: ml_mlbackendtrainjob; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.ml_mlbackendtrainjob (
    id integer NOT NULL,
    job_id character varying(128) NOT NULL,
    model_version text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    ml_backend_id integer NOT NULL
);


ALTER TABLE public.ml_mlbackendtrainjob OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 331 (class 1259 OID 26983)
-- Name: ml_mlbackendtrainjob_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.ml_mlbackendtrainjob ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ml_mlbackendtrainjob_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 356 (class 1259 OID 27524)
-- Name: ml_model_providers_modelproviderconnection; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.ml_model_providers_modelproviderconnection (
    id integer NOT NULL,
    provider character varying(255) NOT NULL,
    api_key text,
    scope character varying(255) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by_id integer,
    organization_id integer,
    deployment_name character varying(512),
    endpoint character varying(512),
    cached_available_models character varying(4096),
    auth_token text,
    budget_alert_threshold double precision,
    budget_last_reset_date timestamp with time zone,
    budget_limit double precision,
    budget_reset_period character varying(20),
    budget_total_spent double precision,
    is_internal boolean,
    google_application_credentials text,
    google_location character varying(255),
    google_project_id character varying(255)
);


ALTER TABLE public.ml_model_providers_modelproviderconnection OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 355 (class 1259 OID 27523)
-- Name: ml_model_providers_modelproviderconnection_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.ml_model_providers_modelproviderconnection ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ml_model_providers_modelproviderconnection_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 322 (class 1259 OID 26840)
-- Name: ml_models_modelinterface; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.ml_models_modelinterface (
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by_id integer,
    organization_id integer,
    input_fields jsonb NOT NULL,
    output_classes jsonb NOT NULL,
    skill_name character varying(255)
);


ALTER TABLE public.ml_models_modelinterface OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 328 (class 1259 OID 26937)
-- Name: ml_models_modelinterface_associated_projects; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.ml_models_modelinterface_associated_projects (
    id integer NOT NULL,
    modelinterface_id integer CONSTRAINT ml_models_modelinterface_associated__modelinterface_id_not_null NOT NULL,
    project_id integer CONSTRAINT ml_models_modelinterface_associated_project_project_id_not_null NOT NULL
);


ALTER TABLE public.ml_models_modelinterface_associated_projects OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 327 (class 1259 OID 26936)
-- Name: ml_models_modelinterface_associated_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.ml_models_modelinterface_associated_projects ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ml_models_modelinterface_associated_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 321 (class 1259 OID 26839)
-- Name: ml_models_modelinterface_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.ml_models_modelinterface ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ml_models_modelinterface_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 326 (class 1259 OID 26898)
-- Name: ml_models_modelrun; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.ml_models_modelrun (
    id integer NOT NULL,
    project_subset character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    triggered_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_by_id integer,
    model_version_id integer NOT NULL,
    organization_id integer,
    project_id integer NOT NULL,
    job_id character varying(255),
    predictions_updated_at timestamp with time zone,
    total_correct_predictions integer NOT NULL,
    total_predictions integer NOT NULL,
    total_tasks integer NOT NULL
);


ALTER TABLE public.ml_models_modelrun OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 325 (class 1259 OID 26897)
-- Name: ml_models_modelrun_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.ml_models_modelrun ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ml_models_modelrun_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 324 (class 1259 OID 26852)
-- Name: ml_models_thirdpartymodelversion; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.ml_models_thirdpartymodelversion (
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    prompt text NOT NULL,
    provider character varying(255) NOT NULL,
    provider_model_id character varying(255) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by_id integer,
    organization_id integer,
    parent_model_id integer NOT NULL,
    model_provider_connection_id integer
);


ALTER TABLE public.ml_models_thirdpartymodelversion OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 323 (class 1259 OID 26851)
-- Name: ml_models_thirdpartymodelversion_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.ml_models_thirdpartymodelversion ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ml_models_thirdpartymodelversion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 241 (class 1259 OID 24966)
-- Name: organization; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.organization (
    id integer NOT NULL,
    title character varying(1000) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by_id integer,
    token character varying(256),
    contact_info character varying(254)
);


ALTER TABLE public.organization OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 240 (class 1259 OID 24965)
-- Name: organization_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.organization ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.organization_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 243 (class 1259 OID 24980)
-- Name: organizations_organizationmember; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.organizations_organizationmember (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    organization_id integer NOT NULL,
    user_id integer NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.organizations_organizationmember OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 242 (class 1259 OID 24979)
-- Name: organizations_organizationmember_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.organizations_organizationmember ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.organizations_organizationmember_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 268 (class 1259 OID 25498)
-- Name: prediction; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.prediction (
    id integer NOT NULL,
    result jsonb,
    score double precision,
    model_version text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    task_id integer NOT NULL,
    cluster integer,
    neighbors jsonb,
    mislabeling double precision NOT NULL,
    project_id integer,
    model_run_id integer,
    model_id integer
);


ALTER TABLE public.prediction OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 267 (class 1259 OID 25497)
-- Name: prediction_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.prediction ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.prediction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 338 (class 1259 OID 27087)
-- Name: prediction_meta; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.prediction_meta (
    id integer NOT NULL,
    inference_time double precision,
    prompt_tokens_count integer,
    completion_tokens_count integer,
    total_tokens_count integer,
    prompt_cost double precision,
    completion_cost double precision,
    total_cost double precision,
    extra jsonb,
    failed_prediction_id integer,
    prediction_id integer,
    CONSTRAINT prediction_or_failed_prediction_not_null CHECK ((((prediction_id IS NOT NULL) AND (failed_prediction_id IS NULL)) OR ((prediction_id IS NULL) AND (failed_prediction_id IS NOT NULL))))
);


ALTER TABLE public.prediction_meta OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 337 (class 1259 OID 27086)
-- Name: prediction_meta_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.prediction_meta ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.prediction_meta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 245 (class 1259 OID 25026)
-- Name: project; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.project (
    id integer NOT NULL,
    title character varying(50),
    label_config text,
    expert_instruction text,
    show_instruction boolean NOT NULL,
    maximum_annotations integer CONSTRAINT project_maximum_completions_not_null NOT NULL,
    model_version text,
    data_types jsonb,
    is_published boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by_id integer,
    show_skip_button boolean NOT NULL,
    enable_empty_annotation boolean CONSTRAINT project_enable_empty_completion_not_null NOT NULL,
    min_annotations_to_start_training integer CONSTRAINT project_min_completions_to_start_training_not_null NOT NULL,
    show_annotation_history boolean CONSTRAINT project_show_completion_history_not_null NOT NULL,
    show_collab_predictions boolean NOT NULL,
    show_ground_truth_first boolean CONSTRAINT project_show_ground_truths_first_not_null NOT NULL,
    sampling character varying(100),
    task_data_login character varying(256),
    task_data_password character varying(256),
    overlap_cohort_percentage integer NOT NULL,
    show_overlap_first boolean NOT NULL,
    control_weights jsonb,
    token character varying(256),
    result_count integer NOT NULL,
    organization_id integer,
    is_draft boolean NOT NULL,
    description text,
    color character varying(16),
    evaluate_predictions_automatically boolean NOT NULL,
    reveal_preannotations_interactively boolean NOT NULL,
    skip_queue character varying(100),
    parsed_label_config jsonb,
    pinned_at timestamp with time zone,
    label_config_hash bigint,
    custom_task_lock_ttl integer,
    search_vector tsvector GENERATED ALWAYS AS (((setweight(to_tsvector('english'::regconfig, COALESCE((id)::text, ''::text)), 'A'::"char") || setweight(to_tsvector('english'::regconfig, (COALESCE(title, ''::character varying))::text), 'B'::"char")) || setweight(to_tsvector('english'::regconfig, COALESCE("substring"(description, 1, 250000), ''::text)), 'C'::"char"))) STORED,
    deleted_at timestamp with time zone,
    deleted_by_id integer,
    purge_at timestamp with time zone
);


ALTER TABLE public.project OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 244 (class 1259 OID 25025)
-- Name: project_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.project ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 258 (class 1259 OID 25367)
-- Name: projects_labelstreamhistory; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.projects_labelstreamhistory (
    id integer NOT NULL,
    data jsonb NOT NULL,
    project_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.projects_labelstreamhistory OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 257 (class 1259 OID 25366)
-- Name: projects_labelstreamhistory_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.projects_labelstreamhistory ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.projects_labelstreamhistory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 318 (class 1259 OID 26777)
-- Name: projects_projectimport; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.projects_projectimport (
    id integer NOT NULL,
    preannotated_from_fields jsonb,
    commit_to_project boolean NOT NULL,
    return_task_ids boolean NOT NULL,
    status character varying(64) NOT NULL,
    url character varying(2048),
    traceback text,
    error text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    finished_at timestamp with time zone,
    task_count integer NOT NULL,
    annotation_count integer NOT NULL,
    prediction_count integer NOT NULL,
    duration integer NOT NULL,
    file_upload_ids jsonb NOT NULL,
    could_be_tasks_list boolean NOT NULL,
    found_formats jsonb NOT NULL,
    data_columns jsonb NOT NULL,
    tasks jsonb,
    task_ids jsonb NOT NULL,
    project_id integer
);


ALTER TABLE public.projects_projectimport OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 317 (class 1259 OID 26776)
-- Name: projects_projectimport_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.projects_projectimport ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.projects_projectimport_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 251 (class 1259 OID 25246)
-- Name: projects_projectmember; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.projects_projectmember (
    id integer NOT NULL,
    enabled boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    project_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.projects_projectmember OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 250 (class 1259 OID 25245)
-- Name: projects_projectmember_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.projects_projectmember ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.projects_projectmember_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 249 (class 1259 OID 25102)
-- Name: projects_projectonboarding; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.projects_projectonboarding (
    id integer NOT NULL,
    finished boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    project_id integer NOT NULL,
    step_id integer NOT NULL
);


ALTER TABLE public.projects_projectonboarding OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 248 (class 1259 OID 25101)
-- Name: projects_projectonboarding_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.projects_projectonboarding ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.projects_projectonboarding_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 247 (class 1259 OID 25044)
-- Name: projects_projectonboardingsteps; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.projects_projectonboardingsteps (
    id integer NOT NULL,
    code character varying(2),
    title character varying(1000) NOT NULL,
    description text NOT NULL,
    "order" integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.projects_projectonboardingsteps OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 246 (class 1259 OID 25043)
-- Name: projects_projectonboardingsteps_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.projects_projectonboardingsteps ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.projects_projectonboardingsteps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 320 (class 1259 OID 26804)
-- Name: projects_projectreimport; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.projects_projectreimport (
    id integer NOT NULL,
    status character varying(64) NOT NULL,
    error text,
    task_count integer NOT NULL,
    annotation_count integer NOT NULL,
    prediction_count integer NOT NULL,
    duration integer NOT NULL,
    file_upload_ids jsonb NOT NULL,
    files_as_tasks_list boolean NOT NULL,
    found_formats jsonb NOT NULL,
    data_columns jsonb NOT NULL,
    traceback text,
    project_id integer
);


ALTER TABLE public.projects_projectreimport OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 319 (class 1259 OID 26803)
-- Name: projects_projectreimport_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.projects_projectreimport ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.projects_projectreimport_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 252 (class 1259 OID 25288)
-- Name: projects_projectsummary; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.projects_projectsummary (
    project_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    all_data_columns jsonb,
    common_data_columns jsonb,
    created_annotations jsonb,
    created_labels jsonb,
    created_labels_drafts jsonb
);


ALTER TABLE public.projects_projectsummary OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 357 (class 1259 OID 27563)
-- Name: session_policy_sessiontimeoutpolicy; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.session_policy_sessiontimeoutpolicy (
    organization_id integer NOT NULL,
    max_session_age integer NOT NULL,
    max_time_between_activity integer CONSTRAINT session_policy_sessiontimeou_max_time_between_activity_not_null NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.session_policy_sessiontimeoutpolicy OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 266 (class 1259 OID 25485)
-- Name: task; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.task (
    id integer NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_labeled boolean NOT NULL,
    project_id integer,
    meta jsonb,
    overlap integer NOT NULL,
    file_upload_id integer,
    updated_by_id integer,
    inner_id bigint,
    total_annotations integer NOT NULL,
    cancelled_annotations integer NOT NULL,
    total_predictions integer NOT NULL,
    comment_count integer NOT NULL,
    last_comment_updated_at timestamp with time zone,
    unresolved_comment_count integer NOT NULL,
    precomputed_agreement double precision,
    allow_skip boolean
);


ALTER TABLE public.task OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 316 (class 1259 OID 26287)
-- Name: task_comment_authors; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.task_comment_authors (
    id integer NOT NULL,
    task_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.task_comment_authors OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 315 (class 1259 OID 26286)
-- Name: task_comment_authors_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.task_comment_authors ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.task_comment_authors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 270 (class 1259 OID 25511)
-- Name: task_completion; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.task_completion (
    id integer NOT NULL,
    result jsonb,
    was_cancelled boolean NOT NULL,
    ground_truth boolean CONSTRAINT task_completion_honeypot_not_null NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    task_id integer,
    prediction jsonb,
    lead_time double precision,
    result_count integer NOT NULL,
    completed_by_id integer,
    parent_prediction_id integer,
    parent_annotation_id integer,
    last_action character varying(128),
    last_created_by_id integer,
    project_id integer,
    updated_by_id integer,
    unique_id uuid,
    draft_created_at timestamp with time zone,
    import_id bigint,
    bulk_created boolean DEFAULT false
);


ALTER TABLE public.task_completion OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 269 (class 1259 OID 25510)
-- Name: task_completion_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.task_completion ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.task_completion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 265 (class 1259 OID 25484)
-- Name: task_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.task ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 272 (class 1259 OID 25555)
-- Name: tasks_annotationdraft; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.tasks_annotationdraft (
    id integer CONSTRAINT tasks_taskcompletiondraft_id_not_null NOT NULL,
    result jsonb CONSTRAINT tasks_taskcompletiondraft_result_not_null NOT NULL,
    lead_time double precision,
    created_at timestamp with time zone CONSTRAINT tasks_taskcompletiondraft_created_at_not_null NOT NULL,
    updated_at timestamp with time zone CONSTRAINT tasks_taskcompletiondraft_updated_at_not_null NOT NULL,
    annotation_id integer,
    task_id integer,
    user_id integer CONSTRAINT tasks_taskcompletiondraft_user_id_not_null NOT NULL,
    was_postponed boolean NOT NULL,
    import_id bigint
);


ALTER TABLE public.tasks_annotationdraft OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 336 (class 1259 OID 27052)
-- Name: tasks_failedprediction; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.tasks_failedprediction (
    id integer NOT NULL,
    message text,
    error_type character varying(512),
    model_version text,
    created_at timestamp with time zone NOT NULL,
    ml_backend_model_id integer,
    model_run_id integer,
    project_id integer,
    task_id integer NOT NULL
);


ALTER TABLE public.tasks_failedprediction OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 335 (class 1259 OID 27051)
-- Name: tasks_failedprediction_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.tasks_failedprediction ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tasks_failedprediction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 271 (class 1259 OID 25554)
-- Name: tasks_taskcompletiondraft_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.tasks_annotationdraft ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tasks_taskcompletiondraft_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 274 (class 1259 OID 25599)
-- Name: tasks_tasklock; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.tasks_tasklock (
    id integer NOT NULL,
    expire_at timestamp with time zone NOT NULL,
    task_id integer NOT NULL,
    user_id integer NOT NULL,
    unique_id uuid,
    created_at timestamp with time zone
);


ALTER TABLE public.tasks_tasklock OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 273 (class 1259 OID 25598)
-- Name: tasks_tasklock_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.tasks_tasklock ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tasks_tasklock_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 360 (class 1259 OID 27593)
-- Name: token_blacklist_blacklistedtoken; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.token_blacklist_blacklistedtoken (
    id bigint NOT NULL,
    blacklisted_at timestamp with time zone NOT NULL,
    token_id bigint NOT NULL
);


ALTER TABLE public.token_blacklist_blacklistedtoken OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 359 (class 1259 OID 27592)
-- Name: token_blacklist_blacklistedtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.token_blacklist_blacklistedtoken ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.token_blacklist_blacklistedtoken_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 362 (class 1259 OID 27601)
-- Name: token_blacklist_outstandingtoken; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.token_blacklist_outstandingtoken (
    id bigint NOT NULL,
    token text NOT NULL,
    created_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    user_id integer,
 pg_dump: processing data for table "public.core_asyncmigrationstatus"
pg_dump: dumping contents of table "public.core_asyncmigrationstatus"
pg_dump: processing data for table "public.core_deletedrow"
pg_dump: dumping contents of table "public.core_deletedrow"
pg_dump: processing data for table "public.data_export_convertedformat"
pg_dump: dumping contents of table "public.data_export_convertedformat"
pg_dump: processing data for table "public.data_export_export"
pg_dump: dumping contents of table "public.data_export_export"
pg_dump: processing data for table "public.data_import_fileupload"
pg_dump: dumping contents of table "public.data_import_fileupload"
pg_dump: processing data for table "public.data_manager_filter"
pg_dump: dumping contents of table "public.data_manager_filter"
pg_dump: processing data for table "public.data_manager_filtergroup"
pg_dump: dumping contents of table "public.data_manager_filtergroup"
   jti character varying(255) CONSTRAINT token_blacklist_outstandingtoken_jti_hex_not_null NOT NULL
);


ALTER TABLE public.token_blacklist_outstandingtoken OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 361 (class 1259 OID 27600)
-- Name: token_blacklist_outstandingtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.token_blacklist_outstandingtoken ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.token_blacklist_outstandingtoken_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 364 (class 1259 OID 27691)
-- Name: users_userproducttour; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.users_userproducttour (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    state character varying(32) NOT NULL,
    interaction_data jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.users_userproducttour OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 363 (class 1259 OID 27690)
-- Name: users_userproducttour_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.users_userproducttour ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_userproducttour_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 366 (class 1259 OID 27713)
-- Name: webhook; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.webhook (
    id integer NOT NULL,
    url character varying(2048) NOT NULL,
    send_payload boolean NOT NULL,
    send_for_all_actions boolean NOT NULL,
    headers jsonb NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    organization_id integer NOT NULL,
    project_id integer
);


ALTER TABLE public.webhook OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 368 (class 1259 OID 27730)
-- Name: webhook_action; Type: TABLE; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE TABLE public.webhook_action (
    id integer NOT NULL,
    action character varying(128) NOT NULL,
    webhook_id integer NOT NULL
);


ALTER TABLE public.webhook_action OWNER TO "wopr-labelstudio-db-user";

--
-- TOC entry 367 (class 1259 OID 27729)
-- Name: webhook_action_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.webhook_action ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.webhook_action_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 365 (class 1259 OID 27712)
-- Name: webhook_id_seq; Type: SEQUENCE; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE public.webhook ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.webhook_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 5288 (class 0 OID 24798)
-- Dependencies: 228
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- TOC entry 5290 (class 0 OID 24808)
-- Dependencies: 230
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- TOC entry 5286 (class 0 OID 24788)
-- Dependencies: 226
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add content type	4	add_contenttype
14	Can change content type	4	change_contenttype
15	Can delete content type	4	delete_contenttype
16	Can view content type	4	view_contenttype
17	Can add session	5	add_session
18	Can change session	5	change_session
19	Can delete session	5	delete_session
20	Can view session	5	view_session
21	Access admin page	6	view
22	Can add Token	7	add_token
23	Can change Token	7	change_token
24	Can delete Token	7	delete_token
25	Can view Token	7	view_token
26	Can add Token	8	add_tokenproxy
27	Can change Token	8	change_tokenproxy
28	Can delete Token	8	delete_tokenproxy
29	Can view Token	8	view_tokenproxy
30	Can add Blacklisted Token	9	add_blacklistedtoken
31	Can change Blacklisted Token	9	change_blacklistedtoken
32	Can delete Blacklisted Token	9	delete_blacklistedtoken
33	Can view Blacklisted Token	9	view_blacklistedtoken
34	Can add Outstanding Token	10	add_outstandingtoken
35	Can change Outstanding Token	10	change_outstandingtoken
36	Can delete Outstanding Token	10	delete_outstandingtoken
37	Can view Outstanding Token	10	view_outstandingtoken
38	Can add annotation state	11	add_annotationstate
39	Can change annotation state	11	change_annotationstate
40	Can delete annotation state	11	delete_annotationstate
41	Can view annotation state	11	view_annotationstate
42	Can add project state	12	add_projectstate
43	Can change project state	12	change_projectstate
44	Can delete project state	12	delete_projectstate
45	Can view project state	12	view_projectstate
46	Can add task state	13	add_taskstate
47	Can change task state	13	change_taskstate
48	Can delete task state	13	delete_taskstate
49	Can view task state	13	view_taskstate
50	Can add async migration status	14	add_asyncmigrationstatus
51	Can change async migration status	14	change_asyncmigrationstatus
52	Can delete async migration status	14	delete_asyncmigrationstatus
53	Can view async migration status	14	view_asyncmigrationstatus
54	Can add deleted row	15	add_deletedrow
55	Can change deleted row	15	change_deletedrow
56	Can delete deleted row	15	delete_deletedrow
57	Can view deleted row	15	view_deletedrow
58	Can add user	16	add_user
59	Can change user	16	change_user
60	Can delete user	16	delete_user
61	Can view user	16	view_user
62	Can add user product tour	17	add_userproducttour
63	Can change user product tour	17	change_userproducttour
64	Can delete user product tour	17	delete_userproducttour
65	Can view user product tour	17	view_userproducttour
66	Can add organization	18	add_organization
67	Can change organization	18	change_organization
68	Can delete organization	18	delete_organization
69	Can view organization	18	view_organization
70	Can add organization member	19	add_organizationmember
71	Can change organization member	19	change_organizationmember
72	Can delete organization member	19	delete_organizationmember
73	Can view organization member	19	view_organizationmember
74	Can add file upload	20	add_fileupload
75	Can change file upload	20	change_fileupload
76	Can delete file upload	20	delete_fileupload
77	Can view file upload	20	view_fileupload
78	Can add export	21	add_export
79	Can change export	21	change_export
80	Can delete export	21	delete_export
81	Can view export	21	view_export
82	Can add converted format	22	add_convertedformat
83	Can change converted format	22	change_convertedformat
84	Can delete converted format	22	delete_convertedformat
85	Can view converted format	22	view_convertedformat
86	Can add project	23	add_project
87	Can change project	23	change_project
88	Can delete project	23	delete_project
89	Can view project	23	view_project
90	Can add project onboarding steps	24	add_projectonboardingsteps
91	Can change project onboarding steps	24	change_projectonboardingsteps
92	Can delete project onboarding steps	24	delete_projectonboardingsteps
93	Can view project onboarding steps	24	view_projectonboardingsteps
94	Can add project onboarding	25	add_projectonboarding
95	Can change project onboarding	25	change_projectonboarding
96	Can delete project onboarding	25	delete_projectonboarding
97	Can view project onboarding	25	view_projectonboarding
98	Can add project member	26	add_projectmember
99	Can change project member	26	change_projectmember
100	Can delete project member	26	delete_projectmember
101	Can view project member	26	view_projectmember
102	Can add project summary	27	add_projectsummary
103	Can change project summary	27	change_projectsummary
104	Can delete project summary	27	delete_projectsummary
105	Can view project summary	27	view_projectsummary
106	Can add label stream history	28	add_labelstreamhistory
107	Can change label stream history	28	change_labelstreamhistory
108	Can delete label stream history	28	delete_labelstreamhistory
109	Can view label stream history	28	view_labelstreamhistory
110	Can add project import	29	add_projectimport
111	Can change project import	29	change_projectimport
112	Can delete project import	29	delete_projectimport
113	Can view project import	29	view_projectimport
114	Can add project reimport	30	add_projectreimport
115	Can change project reimport	30	change_projectreimport
116	Can delete project reimport	30	delete_projectreimport
117	Can view project reimport	30	view_projectreimport
118	Can add task	31	add_task
119	Can change task	31	change_task
120	Can delete task	31	delete_task
121	Can view task	31	view_task
122	Can add prediction	32	add_prediction
123	Can change prediction	32	change_prediction
124	Can delete prediction	32	delete_prediction
125	Can view prediction	32	view_prediction
126	Can add task lock	33	add_tasklock
127	Can change task lock	33	change_tasklock
128	Can delete task lock	33	delete_tasklock
129	Can view task lock	33	view_tasklock
130	Can add annotation	34	add_annotation
131	Can change annotation	34	change_annotation
132	Can delete annotation	34	delete_annotation
133	Can view annotation	34	view_annotation
134	Can add annotation draft	35	add_annotationdraft
135	Can change annotation draft	35	change_annotationdraft
136	Can delete annotation draft	35	delete_annotationdraft
137	Can view annotation draft	35	view_annotationdraft
138	Can add failed prediction	36	add_failedprediction
139	Can change failed prediction	36	change_failedprediction
140	Can delete failed prediction	36	delete_failedprediction
141	Can view failed prediction	36	view_failedprediction
142	Can add Prediction Meta	37	add_predictionmeta
143	Can change Prediction Meta	37	change_predictionmeta
144	Can delete Prediction Meta	37	delete_predictionmeta
145	Can view Prediction Meta	37	view_predictionmeta
146	Can add filter	38	add_filter
147	Can change filter	38	change_filter
148	Can delete filter	38	delete_filter
149	Can view filter	38	view_filter
150	Can add filter group	39	add_filtergroup
151	Can change filter group	39	change_filtergroup
152	Can delete filter group	39	delete_filtergroup
153	Can view filter group	39	view_filtergroup
154	Can add view	40	add_view
155	Can change view	40	change_view
156	Can delete view	40	delete_view
157	Can view view	40	view_view
158	Can add azure blob storage mixin	41	add_azureblobstoragemixin
159	Can change azure blob storage mixin	41	change_azureblobstoragemixin
160	Can delete azure blob storage mixin	41	delete_azureblobstoragemixin
161	Can view azure blob storage mixin	41	view_azureblobstoragemixin
162	Can add gcs storage mixin	42	add_gcsstoragemixin
163	Can change gcs storage mixin	42	change_gcsstoragemixin
164	Can delete gcs storage mixin	42	delete_gcsstoragemixin
165	Can view gcs storage mixin	42	view_gcsstoragemixin
166	Can add redis storage mixin	43	add_redisstoragemixin
167	Can change redis storage mixin	43	change_redisstoragemixin
168	Can delete redis storage mixin	43	delete_redisstoragemixin
169	Can view redis storage mixin	43	view_redisstoragemixin
170	Can add s3 export storage	44	add_s3exportstorage
171	Can change s3 export storage	44	change_s3exportstorage
172	Can delete s3 export storage	44	delete_s3exportstorage
173	Can view s3 export storage	44	view_s3exportstorage
174	Can add s3 import storage	45	add_s3importstorage
175	Can change s3 import storage	45	change_s3importstorage
176	Can delete s3 import storage	45	delete_s3importstorage
177	Can view s3 import storage	45	view_s3importstorage
178	Can add azure blob export storage	46	add_azureblobexportstorage
179	Can change azure blob export storage	46	change_azureblobexportstorage
180	Can delete azure blob export storage	46	delete_azureblobexportstorage
181	Can view azure blob export storage	46	view_azureblobexportstorage
182	Can add azure blob import storage	47	add_azureblobimportstorage
183	Can change azure blob import storage	47	change_azureblobimportstorage
184	Can delete azure blob import storage	47	delete_azureblobimportstorage
185	Can view azure blob import storage	47	view_azureblobimportstorage
186	Can add gcs export storage	48	add_gcsexportstorage
187	Can change gcs export storage	48	change_gcsexportstorage
188	Can delete gcs export storage	48	delete_gcsexportstorage
189	Can view gcs export storage	48	view_gcsexportstorage
190	Can add gcs import storage	49	add_gcsimportstorage
191	Can change gcs import storage	49	change_gcsimportstorage
192	Can delete gcs import storage	49	delete_gcsimportstorage
193	Can view gcs import storage	49	view_gcsimportstorage
194	Can add redis export storage	50	add_redisexportstorage
195	Can change redis export storage	50	change_redisexportstorage
196	Can delete redis export storage	50	delete_redisexportstorage
197	Can view redis export storage	50	view_redisexportstorage
198	Can add redis import storage	51	add_redisimportstorage
199	Can change redis import storage	51	change_redisimportstorage
200	Can delete redis import storage	51	delete_redisimportstorage
201	Can view redis import storage	51	view_redisimportstorage
202	Can add s3 import storage link	52	add_s3importstoragelink
203	Can change s3 import storage link	52	change_s3importstoragelink
204	Can delete s3 import storage link	52	delete_s3importstoragelink
205	Can view s3 import storage link	52	view_s3importstoragelink
206	Can add s3 export storage link	53	add_s3exportstoragelink
207	Can change s3 export storage link	53	change_s3exportstoragelink
208	Can delete s3 export storage link	53	delete_s3exportstoragelink
209	Can view s3 export storage link	53	view_s3exportstoragelink
210	Can add redis import storage link	54	add_redisimportstoragelink
211	Can change redis import storage link	54	change_redisimportstoragelink
212	Can delete redis import storage link	54	delete_redisimportstoragelink
213	Can view redis import storage link	54	view_redisimportstoragelink
214	Can add redis export storage link	55	add_redisexportstoragelink
215	Can change redis export storage link	55	change_redisexportstoragelink
216	Can delete redis export storage link	55	delete_redisexportstoragelink
217	Can view redis export storage link	55	view_redisexportstoragelink
218	Can add gcs import storage link	56	add_gcsimportstoragelink
219	Can change gcs import storage link	56	change_gcsimportstoragelink
220	Can delete gcs import storage link	56	delete_gcsimportstoragelink
221	Can view gcs import storage link	56	view_gcsimportstoragelink
222	Can add gcs export storage link	57	add_gcsexportstoragelink
223	Can change gcs export storage link	57	change_gcsexportstoragelink
224	Can delete gcs export storage link	57	delete_gcsexportstoragelink
225	Can view gcs export storage link	57	view_gcsexportstoragelink
226	Can add azure blob import storage link	58	add_azureblobimportstoragelink
227	Can change azure blob import storage link	58	change_azureblobimportstoragelink
228	Can delete azure blob import storage link	58	delete_azureblobimportstoragelink
229	Can view azure blob import storage link	58	view_azureblobimportstoragelink
230	Can add azure blob export storage link	59	add_azureblobexportstoragelink
231	Can change azure blob export storage link	59	change_azureblobexportstoragelink
232	Can delete azure blob export storage link	59	delete_azureblobexportstoragelink
233	Can view azure blob export storage link	59	view_azureblobexportstoragelink
234	Can add local files mixin	60	add_localfilesmixin
235	Can change local files mixin	60	change_localfilesmixin
236	Can delete local files mixin	60	delete_localfilesmixin
237	Can view local files mixin	60	view_localfilesmixin
238	Can add local files export storage	61	add_localfilesexportstorage
239	Can change local files export storage	61	change_localfilesexportstorage
240	Can delete local files export storage	61	delete_localfilesexportstorage
241	Can view local files export storage	61	view_localfilesexportstorage
242	Can add local files import storage	62	add_localfilesimportstorage
243	Can change local files import storage	62	change_localfilesimportstorage
244	Can delete local files import storage	62	delete_localfilesimportstorage
245	Can view local files import storage	62	view_localfilesimportstorage
246	Can add local files import storage link	63	add_localfilesimportstoragelink
247	Can change local files import storage link	63	change_localfilesimportstoragelink
248	Can delete local files import storage link	63	delete_localfilesimportstoragelink
249	Can view local files import storage link	63	view_localfilesimportstoragelink
250	Can add local files export storage link	64	add_localfilesexportstoragelink
251	Can change local files export storage link	64	change_localfilesexportstoragelink
252	Can delete local files export storage link	64	delete_localfilesexportstoragelink
253	Can view local files export storage link	64	view_localfilesexportstoragelink
254	Can add ml backend	65	add_mlbackend
255	Can change ml backend	65	change_mlbackend
256	Can delete ml backend	65	delete_mlbackend
257	Can view ml backend	65	view_mlbackend
258	Can add ml backend train job	66	add_mlbackendtrainjob
259	Can change ml backend train job	66	change_mlbackendtrainjob
260	Can delete ml backend train job	66	delete_mlbackendtrainjob
261	Can view ml backend train job	66	view_mlbackendtrainjob
262	Can add ml backend prediction job	67	add_mlbackendpredictionjob
263	Can change ml backend prediction job	67	change_mlbackendpredictionjob
264	Can delete ml backend prediction job	67	delete_mlbackendpredictionjob
265	Can view ml backend prediction job	67	view_mlbackendpredictionjob
266	Can add webhook	68	add_webhook
267	Can change webhook	68	change_webhook
268	Can delete webhook	68	delete_webhook
269	Can view webhook	68	view_webhook
270	Can add webhook action	69	add_webhookaction
271	Can change webhook action	69	change_webhookaction
272	Can delete webhook action	69	delete_webhookaction
273	Can view webhook action	69	view_webhookaction
274	Can add label	70	add_label
275	Can change label	70	change_label
276	Can delete label	70	delete_label
277	Can view label	70	view_label
278	Can add label link	71	add_labellink
279	Can change label link	71	change_labellink
280	Can delete label link	71	delete_labellink
281	Can view label link	71	view_labellink
282	Can add model interface	72	add_modelinterface
283	Can change model interface	72	change_modelinterface
284	Can delete model interface	72	delete_modelinterface
285	Can view model interface	72	view_modelinterface
286	Can add third party model version	73	add_thirdpartymodelversion
287	Can change third party model version	73	change_thirdpartymodelversion
288	Can delete third party model version	73	delete_thirdpartymodelversion
289	Can view third party model version	73	view_thirdpartymodelversion
290	Can add model run	74	add_modelrun
291	Can change model run	74	change_modelrun
292	Can delete model run	74	delete_modelrun
293	Can view model run	74	view_modelrun
294	Can add model provider connection	75	add_modelproviderconnection
295	Can change model provider connection	75	change_modelproviderconnection
296	Can delete model provider connection	75	delete_modelproviderconnection
297	Can view model provider connection	75	view_modelproviderconnection
298	Can add jwt settings	76	add_jwtsettings
299	Can change jwt settings	76	change_jwtsettings
300	Can delete jwt settings	76	delete_jwtsettings
301	Can view jwt settings	76	view_jwtsettings
302	Can add session timeout policy	77	add_sessiontimeoutpolicy
303	Can change session timeout policy	77	change_sessiontimeoutpolicy
304	Can delete pg_dump: processing data for table "public.data_manager_filtergroup_filters"
pg_dump: dumping contents of table "public.data_manager_filtergroup_filters"
pg_dump: processing data for table "public.data_manager_view"
pg_dump: dumping contents of table "public.data_manager_view"
session timeout policy	77	delete_sessiontimeoutpolicy
305	Can view session timeout policy	77	view_sessiontimeoutpolicy
\.


--
-- TOC entry 5299 (class 0 OID 24949)
-- Dependencies: 239
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
19d714ba17a64ede188b7f5e0e3a0912592bfb04	2026-01-06 06:33:34.641955+00	1
\.


--
-- TOC entry 5314 (class 0 OID 25337)
-- Dependencies: 254
-- Data for Name: core_asyncmigrationstatus; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.core_asyncmigrationstatus (id, meta, name, status, created_at, updated_at, project_id) FROM stdin;
1	{}	0013_cleanup_inconsistent_filtergroup_20250624_2119	FINISHED	2026-01-06 06:25:09.944779+00	2026-01-06 06:25:09.944792+00	\N
2	{}	0016_migrate_agreement_selected_annotators_to_unique	FINISHED	2026-01-06 06:25:10.033797+00	2026-01-06 06:25:10.03381+00	\N
3	{}	0017_update_agreement_selected_to_nested_structure	FINISHED	2026-01-06 06:25:10.088452+00	2026-01-06 06:25:10.088465+00	\N
4	{}	0052_auto_20241030_1757	FINISHED	2026-01-06 06:25:13.977758+00	2026-01-06 06:25:13.983118+00	\N
5	{}	0054_add_brin_index_updated_at	FINISHED	2026-01-06 06:25:14.076148+00	2026-01-06 06:25:14.089291+00	\N
6	{}	0055_task_proj_octlen_idx_async	FINISHED	2026-01-06 06:25:14.139828+00	2026-01-06 06:25:14.152469+00	\N
7	{}	0056_prediction_result_proj_gin_idx_async	FINISHED	2026-01-06 06:25:14.203437+00	2026-01-06 06:25:14.21615+00	\N
8	{}	0057_annotation_proj_result_octlen_idx_async	FINISHED	2026-01-06 06:25:14.270472+00	2026-01-06 06:25:14.282608+00	\N
9	{}	0028_auto_20241107_1031	FINISHED	2026-01-06 06:25:14.369285+00	2026-01-06 06:25:14.375733+00	\N
10	{}	0030_project_search_vector_index	FINISHED	2026-01-06 06:25:14.470229+00	2026-01-06 06:25:14.483231+00	\N
11	{}	0017_auto_20240731_1638	FINISHED	2026-01-06 06:25:20.210178+00	2026-01-06 06:25:20.295238+00	\N
12	{}	0033_projects_soft_delete_indexes_async	FINISHED	2026-01-06 06:25:23.602986+00	2026-01-06 06:25:23.642948+00	\N
13	{}	tasks.migrations.0059_task_completion_id_updated_at_idx_async	FINISHED	2026-01-06 06:25:23.958048+00	2026-01-06 06:25:23.973863+00	\N
\.


--
-- TOC entry 5316 (class 0 OID 25355)
-- Dependencies: 256
-- Data for Name: core_deletedrow; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.core_deletedrow (id, model, row_id, data, reason, created_at, updated_at, organization_id, project_id, user_id) FROM stdin;
\.


--
-- TOC entry 5322 (class 0 OID 25425)
-- Dependencies: 262
-- Data for Name: data_export_convertedformat; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.data_export_convertedformat (id, file, status, export_type, export_id, created_at, created_by_id, finished_at, organization_id, project_id, updated_at, traceback) FROM stdin;
\.


--
-- TOC entry 5320 (class 0 OID 25394)
-- Dependencies: 260
-- Data for Name: data_export_export; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.data_export_export (id, created_at, file, md5, finished_at, status, counters, created_by_id, project_id, title) FROM stdin;
\.


--
-- TOC entry 5324 (class 0 OID 25463)
-- Dependencies: 264
-- Data for Name: data_import_fileupload; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.data_import_fileupload (id, file, project_id, user_id) FROM stdin;
\.


--
-- TOC entry 5368 (class 0 OID 26204)
-- Dependencies: 308
-- Data for Name: data_manager_filter; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.data_manager_filter (id, "column", type, operator, value, index, parent_id) FROM stdin;
\.


--
-- TOC entry 5370 (class 0 OID 26217)
-- Dependencies: 310
-- Data for Name: data_manager_filtergroup; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.data_manager_filtergroup (id, conjunction) FROM stdin;
1	and
\.


--
-- TOC entry 5372 (class 0 OID 26227)
-- Dependencies: 312
-- Data for Name: data_manager_filtergroup_filters; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.data_manager_filtergroup_filters (id, filtergroup_id, filter_id) FROM stdin;
\.


--
-- TOC entry 5374 (class 0 OID 26236)
-- Dependencies: 314
-- Data for Name: data_manager_view; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.data_manager_view (id, data, project_id, ordering, filter_group_id, selected_items, user_id, "order") FROM stdin;
1	{"type": "list", "title": "Default", "target": "tasks", "gridWidth": 4, "columnsWidth": {}, "hiddenColumns": {"explore": ["tasks:inner_id", "tasks:annotations_results", "tasks:annotations_ids", "tasks:predictions_score", "tasks:predictions_model_versions", "tasks:predictions_results", "tasks:file_upload", "tasks:storage_filename", "tasks:created_at", "tasks:updated_at", "tasks:updated_by", "tasks:avg_lead_time", "tasks:draft_exists"], "labeling": ["tasks:inner_id", "tasks:completed_at", "tasks:cancelled_annotations", "tasks:total_predictions", "tasks:annotators", "tasks:annotations_results", "tasks:annotations_ids", "tasks:predictions_score", "tasks:predictions_model_versions", "tasks:predictions_results", "tasks:created_at", "tasks:updated_at", "tasks:updated_by", "tasks:avg_lead_time", "tasks:draft_exists", "tasks:file_upload", "tasks:id"]}, "semantic_search": [], "agreement_selected": {}, "columnsDisplayType": {}, "gridFitImagesToWidth": false}	1	[]	1	{}	1	0
\.


--
-- TOC entry 5298 (class 0 OID 24919)
-- Dependencies: 238
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- TOC entry 5284 (class 0 OID 24776)
-- Dependencies: 224
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	contenttypes	contenttype
5	sessions	session
6	django_rq	queue
7	authtoken	token
8	authtoken	tokenproxy
9	token_blacklist	blacklistedtoken
10	token_blacklist	outstandingtoken
11	fsm	annotationstate
12	fsm	projectstate
13	fsm	taskstate
14	core	asyncmigrationstatus
15	core	deletedrow
16	users	user
17	users	userproducttour
18	organizations	organization
19	organizations	organizationmember
20	data_import	fileupload
21	data_export	export
22	data_export	convertedformat
23	projects	project
24	projects	projectonboardingsteps
25	projects	projectonboarding
26	projects	projectmember
27	projects	projectsummary
28	projects	labelstreamhistory
29	projects	projectimport
30	projects	projectreimport
31	tasks	task
32	tasks	prediction
33	tasks	tasklock
34	tasks	annotation
35	tasks	annotationdraft
36	tasks	failedprediction
37	tasks	predictionmeta
38	data_manager	filter
39	data_manager	filtergroup
40	data_manager	view
41	io_storages	azureblobstoragemixin
42	io_storages	gcsstoragemixin
43	io_storages	redisstoragemixin
44	io_storages	s3exportstorage
45	io_storages	s3importstorage
46	io_storages	azureblobexportstorage
47	io_storages	azureblobimportstorage
48	io_storages	gcsexportstorage
49	io_storages	gcsimportstorage
50	io_storages	redisexportstorage
51	io_storages	redisimportstorage
52	io_storages	s3importstoragelink
53	io_storages	s3exportstoragelink
54	io_storages	redisimportstoragelink
55	io_storages	redisexportstoragelink
56	io_storages	gcsimportstoragelink
57	io_storages	gcsexportstoragelink
58	io_storages	azureblobimportstoragelink
59	io_storages	azureblobexportstoragelink
60	io_storages	localfilesmixin
61	io_storages	localfilesexportstorage
62	io_storages	localfilesimportstorage
63	io_storages	localfilesimportstoragelink
64	io_storages	localfilesexportstoragelink
65	ml	mlbackend
66	ml	mlbackendtrainjob
67	ml	mlbackendpredictionjob
68	webhooks	webhook
69	webhooks	webhookaction
70	labels_manager	label
71	labels_manager	labellink
72	ml_models	modelinterface
73	ml_models	thirdpartymodelversion
74	ml_modepg_dump: processing data for table "public.django_admin_log"
pg_dump: dumping contents of table "public.django_admin_log"
ls	modelrun
75	ml_model_providers	modelproviderconnection
76	jwt_auth	jwtsettings
77	session_policy	sessiontimeoutpolicy
\.


--
-- TOC entry 5282 (class 0 OID 24764)
-- Dependencies: 222
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2026-01-06 06:25:01.401532+00
2	contenttypes	0002_remove_content_type_name	2026-01-06 06:25:01.410039+00
3	auth	0001_initial	2026-01-06 06:25:01.441447+00
4	auth	0002_alter_permission_name_max_length	2026-01-06 06:25:01.449089+00
5	auth	0003_alter_user_email_max_length	2026-01-06 06:25:01.456377+00
6	auth	0004_alter_user_username_opts	2026-01-06 06:25:01.464056+00
7	auth	0005_alter_user_last_login_null	2026-01-06 06:25:01.471711+00
8	auth	0006_require_contenttypes_0002	2026-01-06 06:25:01.476615+00
9	auth	0007_alter_validators_add_error_messages	2026-01-06 06:25:01.483441+00
10	auth	0008_alter_user_username_max_length	2026-01-06 06:25:01.490761+00
11	auth	0009_alter_user_last_name_max_length	2026-01-06 06:25:01.497652+00
12	users	0001_initial	2026-01-06 06:25:01.55919+00
13	users	0002_user_last_activity	2026-01-06 06:25:01.562504+00
14	users	0003_add_tokens_to_all	2026-01-06 06:25:01.566097+00
15	users	0004_add_removed_user	2026-01-06 06:25:01.568987+00
16	users	0005_auto_20200731_1943	2026-01-06 06:25:01.571864+00
17	users	0006_auto_20201015_1553	2026-01-06 06:25:01.575027+00
18	users	0007_user_activity_at	2026-01-06 06:25:01.57845+00
19	users	0008_auto_20210211_1606	2026-01-06 06:25:01.581542+00
20	users	0009_auto_20210219_1237	2026-01-06 06:25:01.584481+00
21	admin	0001_initial	2026-01-06 06:25:01.601602+00
22	admin	0002_logentry_remove_auto_add	2026-01-06 06:25:01.609771+00
23	admin	0003_logentry_add_action_flag_choices	2026-01-06 06:25:01.618479+00
24	auth	0010_alter_group_name_max_length	2026-01-06 06:25:01.62931+00
25	auth	0011_update_proxy_permissions	2026-01-06 06:25:01.639417+00
26	auth	0012_alter_user_first_name_max_length	2026-01-06 06:25:01.648979+00
27	authtoken	0001_initial	2026-01-06 06:25:01.668426+00
28	authtoken	0002_auto_20160226_1747	2026-01-06 06:25:01.693885+00
29	authtoken	0003_tokenproxy	2026-01-06 06:25:01.699407+00
30	authtoken	0004_alter_tokenproxy_options	2026-01-06 06:25:01.706084+00
31	organizations	0001_initial	2026-01-06 06:25:01.797783+00
32	organizations	0002_organization_token	2026-01-06 06:25:01.801018+00
33	organizations	0003_auto_20200418_0202	2026-01-06 06:25:01.80548+00
34	organizations	0004_auto_20200501_1751	2026-01-06 06:25:01.808423+00
35	organizations	0005_auto_20200811_2313	2026-01-06 06:25:01.811408+00
36	organizations	0006_auto_20200923_1423	2026-01-06 06:25:01.814272+00
37	organizations	0007_auto_20200923_2200	2026-01-06 06:25:01.817091+00
38	organizations	0008_auto_20201005_1552	2026-01-06 06:25:01.819817+00
39	projects	0001_initial	2026-01-06 06:25:03.406897+00
40	projects	0002_auto_20190318_2010	2026-01-06 06:25:03.410491+00
41	projects	0003_auto_20190318_2011	2026-01-06 06:25:03.413409+00
42	projects	0004_auto_20190318_2012	2026-01-06 06:25:03.416951+00
43	projects	0005_auto_20190318_2014	2026-01-06 06:25:03.419927+00
44	projects	0006_auto_20190321_1457	2026-01-06 06:25:03.422868+00
45	projects	0007_auto_20190326_2059	2026-01-06 06:25:03.425801+00
46	projects	0008_auto_20190328_2028	2026-01-06 06:25:03.428917+00
47	projects	0009_auto_20190403_1517	2026-01-06 06:25:03.432188+00
48	projects	0010_mlbackendscheduledjob	2026-01-06 06:25:03.435315+00
49	projects	0011_auto_20190418_2056	2026-01-06 06:25:03.43826+00
50	projects	0012_auto_20190423_1445	2026-01-06 06:25:03.442019+00
51	projects	0012_auto_20190422_1253	2026-01-06 06:25:03.445102+00
52	projects	0013_merge_20190424_0748	2026-01-06 06:25:03.448916+00
53	projects	0014_auto_20190424_0748	2026-01-06 06:25:03.451906+00
54	projects	0015_auto_20190506_1532	2026-01-06 06:25:03.454761+00
55	projects	0016_projecttemplate_ml_backend	2026-01-06 06:25:03.457707+00
56	projects	0017_auto_20190507_1126	2026-01-06 06:25:03.460699+00
57	projects	001pg_dump: processing data for table "public.django_content_type"
pg_dump: dumping contents of table "public.django_content_type"
8_auto_20190507_1633	2026-01-06 06:25:03.46362+00
58	projects	0019_auto_20190507_2010	2026-01-06 06:25:03.466444+00
59	projects	0020_auto_20190508_1850	2026-01-06 06:25:03.469567+00
60	projects	0021_auto_20190509_2057	2026-01-06 06:25:03.472563+00
61	projects	0022_auto_20190510_1324	2026-01-06 06:25:03.475559+00
62	projects	0023_project_show_skip_button	2026-01-06 06:25:03.478424+00
63	projects	0024_project_enable_empty_completion	2026-01-06 06:25:03.481254+00
64	projects	0025_project_cluster_annotation	2026-01-06 06:25:03.484079+00
65	projects	0026_auto_20190624_1254	2026-01-06 06:25:03.486892+00
66	projects	0029_auto_20190702_0959	2026-01-06 06:25:03.489771+00
67	projects	0030_mlbackendtrainjob	2026-01-06 06:25:03.492736+00
68	projects	0031_project_show_completion_history	2026-01-06 06:25:03.495677+00
69	projects	0032_auto_20190708_1648	2026-01-06 06:25:03.498797+00
70	projects	0033_auto_20190712_0849	2026-01-06 06:25:03.501839+00
71	projects	0034_auto_20190726_1928	2026-01-06 06:25:03.504763+00
72	projects	0035_auto_20190805_1955	2026-01-06 06:25:03.507915+00
73	projects	0036_auto_20190805_2058	2026-01-06 06:25:03.511651+00
74	projects	0037_remove_project_active_learning_enabled	2026-01-06 06:25:03.514637+00
75	projects	0038_auto_20190921_0830	2026-01-06 06:25:03.517643+00
76	projects	0039_auto_20190923_1323	2026-01-06 06:25:03.520499+00
77	projects	0040_auto_20190930_0909	2026-01-06 06:25:03.523322+00
78	projects	0041_project_use_kappa	2026-01-06 06:25:03.526057+00
79	projects	0042_auto_20191114_1430	2026-01-06 06:25:03.528926+00
80	projects	0043_auto_20191126_1145	2026-01-06 06:25:03.531837+00
81	projects	0044_auto_20191206_1641	2026-01-06 06:25:03.535554+00
82	projects	0045_auto_20200302_1221	2026-01-06 06:25:03.538781+00
83	projects	0046_project_agreement_method	2026-01-06 06:25:03.541778+00
84	projects	0047_auto_20200313_1925	2026-01-06 06:25:03.544799+00
85	projects	0048_auto_20200316_1400	2026-01-06 06:25:03.547826+00
86	projects	0049_project_control_weights	2026-01-06 06:25:03.550896+00
87	projects	0050_auto_20200417_1019	2026-01-06 06:25:03.554516+00
88	projects	0051_project_team	2026-01-06 06:25:03.558868+00
89	projects	0052_projecttemplate_organization	2026-01-06 06:25:03.56269+00
90	projects	0053_auto_20200504_1324	2026-01-06 06:25:03.565723+00
91	projects	0054_project_result_count	2026-01-06 06:25:03.568675+00
92	projects	0055_storage	2026-01-06 06:25:03.571686+00
93	projects	0056_set_project_skip_onboarding	2026-01-06 06:25:03.574507+00
94	projects	0057_auto_20201015_1553	2026-01-06 06:25:03.577379+00
95	projects	0058_project_organization	2026-01-06 06:25:03.580308+00
96	projects	0059_remove_project_team	2026-01-06 06:25:03.583064+00
97	projects	0058_remove_projecttemplate_business	2026-01-06 06:25:03.586558+00
98	projects	0059_auto_20210122_1542	2026-01-06 06:25:03.589456+00
99	projects	0060_merge_20210126_1328	2026-01-06 06:25:03.592519+00
100	projects	0061_delete_storage	2026-01-06 06:25:03.595649+00
101	projects	0062_auto_20210217_2135	2026-01-06 06:25:03.598469+00
102	projects	0063_auto_20210222_1246	2026-01-06 06:25:03.601145+00
103	projects	0064_auto_20210223_0726	2026-01-06 06:25:03.603908+00
104	projects	0065_auto_20210223_2014	2026-01-06 06:25:03.606658+00
105	projects	0002_auto_20210304_1457	2026-01-06 06:25:03.625513+00
106	projects	0003_project_color	2026-01-06 06:25:03.64361+00
107	projects	0004_auto_20210306_0506	2026-01-06 06:25:03.866762+00
108	projects	0003_auto_20210305_1008	2026-01-06 06:25:03.975963+00
109	projects	0005_merge_20210308_1141	2026-01-06 06:25:03.982826+00
110	projects	0006_auto_20210308_1559	2026-01-06 06:25:04.028847+00
111	projects	0007_auto_20210309_1304	2026-01-06 06:25:04.055306+00
112	projects	0008_auto_20210314_1840	2026-01-06 06:25:04.07967+00
113	projects	0009_project_evaluate_predictions_automatically	2026-01-06 06:25:04.097364+00
114	projects	0010_auto_20210505_2037	2026-01-06 06:25:04.128135+00
115	projects	0011_auto_20210517_2101	2026-01-06 06:25:04.144534+00
116	projects	0012_auto_20210906_1323	2026-01-06 06:25:04.174701+00
117	projects	0013_project_reveal_preannotations_interactively	2026-01-06 06:25:04.197011+00
118	projects	0014_project_parsed_label_config	2026-01-06 06:25:04.216174+00
119	projects	0013_project_skip_queue	2026-01-06 06:25:04.234652+00
120	projects	0015_merge_20220117_0749	2026-01-06 06:25:04.238704+00
121	projects	0016_auto_20220211_2218	2026-01-06 06:25:04.275685+00
122	core	0001_initial	2026-01-06 06:25:04.301362+00
123	core	0002_deletedrow	2026-01-06 06:25:04.308475+00
124	core	0003_asyncmigrationstatus_add_scheduled_status	2026-01-06 06:25:04.320584+00
125	projects	0017_project_pinned_at	2026-01-06 06:25:04.346713+00
126	projects	0018_alter_project_control_weights	2026-01-06 06:25:04.362238+00
127	projects	0019_labelstreamhistory	2026-01-06 06:25:04.388823+00
128	projects	0020_labelstreamhistory_unique_history	2026-01-06 06:25:04.405133+00
129	projects	0019_project_project_pinned__a39ccb_idx	2026-01-06 06:25:04.422838+00
130	projects	0021_merge_20230215_1943	2026-01-06 06:25:04.427304+00
131	organizations	0002_auto_20210310_2044	2026-01-06 06:25:04.451014+00
132	organizations	0003_auto_20211010_1339	2026-01-06 06:25:04.46494+00
133	data_export	0001_initial	2026-01-06 06:25:04.493521+00
134	data_export	0002_auto_20210921_0954	2026-01-06 06:25:04.520426+00
135	data_export	0003_auto_20211004_1416	2026-01-06 06:25:04.556303+00
136	data_export	0004_auto_20211019_0852	2026-01-06 06:25:04.573573+00
137	data_export	0005_auto_20211025_1137	2026-01-06 06:25:04.590612+00
138	data_export	0006_convertedformat	2026-01-06 06:25:04.615286+00
139	data_export	0007_auto_20230327_1910	2026-01-06 06:25:04.697834+00
140	data_export	0008_convertedformat_traceback	2026-01-06 06:25:04.7171+00
141	data_export	0009_alter_convertedformat_traceback	2026-01-06 06:25:04.746787+00
142	data_export	0010_alter_convertedformat_export_type	2026-01-06 06:25:04.769982+00
143	data_import	0001_initial	2026-01-06 06:25:04.801376+00
144	data_import	0002_alter_fileupload_file	2026-01-06 06:25:04.82004+00
145	tasks	0001_initial	2026-01-06 06:25:05.858676+00
146	tasks	0002_task_meta	2026-01-06 06:25:05.86232+00
147	tasks	0003_auto_20190328_1641	2026-01-06 06:25:05.865237+00
148	tasks	0003_auto_20190327_1906	2026-01-06 06:25:05.869125+00
149	tasks	0004_merge_20190329_1219	2026-01-06 06:25:05.872618+00
150	tasks	0005_auto_20190506_1532	2026-01-06 06:25:05.875732+00
151	tasks	0006_task_exposed	2026-01-06 06:25:05.878574+00
152	tasks	0007_auto_20190621_1106	2026-01-06 06:25:05.881449+00
153	tasks	0008_auto_20190621_1426	2026-01-06 06:25:05.884385+00
154	tasks	0009_remove_taskcompletion_was_generated	2026-01-06 06:25:05.887131+00
155	tasks	0010_auto_20190813_2215	2026-01-06 06:25:05.889872+00
156	tasks	0011_taskcompletion_updates_history	2026-01-06 06:25:05.89269+00
157	tasks	0012_auto_20190921_0830	2026-01-06 06:25:05.895744+00
158	tasks	0013_auto_20190925_1602	2026-01-06 06:25:05.8986+00
159	tasks	0014_auto_20191002_1002	2026-01-06 06:25:05.901385+00
160	tasks	0015_taskcompletion_lead_time	2026-01-06 06:25:05.904042+00
161	tasks	0016_completionpairwisestats	2026-01-06 06:25:05.906884+00
162	tasks	0017_task_taken_at	2026-01-06 06:25:05.909651+00
163	tasks	0018_auto_20200202_2017	2026-01-06 06:25:05.912542+00
164	tasks	0019_task_overlap	2026-01-06 06:25:05.915588+00
165	tasks	0020_review	2026-01-06 06:25:05.919262+00
166	tasks	0021_auto_20200417_1019	2026-01-06 06:25:05.922307+00
167	tasks	0022_taskcompletion_result_count	2026-01-06 06:25:05.925083+00
168	tasks	0023_storagelink	2026-01-06 06:25:05.927883+00
169	tasks	0024_auto_20200705_1436	2026-01-06 06:25:05.931346+00
170	tasks	0025_taskcompletionhistory	2026-01-06 06:25:05.934101+00
171	tasks	0026_remove_taskcompletion_updates_history	2026-01-06 06:25:05.936831+00
172	tasks	0027_taskcompletion_draft	2026-01-06 06:25:05.939681+00
173	tasks	0028_auto_20200814_1514	2026-01-06 06:25:05.944107+00
174	tasks	0029_auto_20200904_2035	2026-01-06 06:25:05.947798+00
175	tasks	0030_auto_20200904_2043	2026-01-06 06:25:05.951345+00
176	tasks	0031_auto_20200910_1402	2026-01-06 06:25:05.955419+00
177	tasks	0032_auto_20200921_1921	2026-01-06 06:25:05.958995+00
178	tasks	0033_auto_20201005_1552	2026-01-06 06:25:05.962135+00
179	tasks	0034_auto_20201203_1113	2026-01-06 06:25:05.965386+00
180	tasks	0035_remove_experts	2026-01-06 06:25:05.968727+00
181	tasks	0036_auto_20210121_1524	2026-01-06 06:25:05.972698+00
182	tasks	0036_auto_20210119_1144	2026-01-06 06:25:05.976159+00
183	tasks	0037_merge_20210126_1328	2026-01-06 06:25:05.980081+00
184	tasks	0038_delete_storagelink	2026-01-06 06:25:05.983853+00
185	tasks	0039_task_file_upload	2026-01-06 06:25:05.987487+00
186	tasks	0035_tasklock	2026-01-06 06:25:05.99099+00
187	tasks	0039_merge_20210222_1244	2026-01-06 06:25:05.994351+00
188	tasks	0040_merge_20210225_1126	2026-01-06 06:25:05.997807+00
189	tasks	0041_taskcompletionhistory_was_cancelled	2026-01-06 06:25:06.002154+00
190	tasks	0002_auto_20210305_2035	2026-01-06 06:25:06.026615+00
191	io_storages	0001_initial	2026-01-06 06:25:06.54395+00
192	io_storages	0002_auto_20210302_1827	2026-01-06 06:25:06.547348+00
193	tasks	0002_auto_20210304_1423	2026-01-06 06:25:07.011558+00
194	tasks	0003_merge_20210308_1141	2026-01-06 06:25:07.017544+00
195	tasks	0004_auto_20210308_1559	2026-01-06 06:25:07.788652+00
196	tasks	0005_auto_20210309_1239	2026-01-06 06:25:07.976588+00
197	tasks	0006_remove_annotation_state	2026-01-06 06:25:08.006227+00
198	tasks	0007_auto_20210618_1653	2026-01-06 06:25:08.051406+00
199	tasks	0008_auto_20210903_1332	2026-01-06 06:25:08.077734+00
200	tasks	0009_auto_20210914_0020	2026-01-06 06:25:08.146185+00
201	tasks	0010_auto_20210914_0032	2026-01-06 06:25:08.195451+00
202	tasks	0009_auto_20210913_0739	2026-01-06 06:25:08.26454+00
203	tasks	0011_merge_20210914_1036	2026-01-06 06:25:08.268356+00
204	tasks	0012_auto_20211010_1339	2026-01-06 06:25:08.378891+00
205	tasks	0013_task_updated_by	2026-01-06 06:25:08.420059+00
206	tasks	0014_task_inner_id	2026-01-06 06:25:08.460073+00
207	tasks	0015_task_fill_inner_id	2026-01-06 06:25:08.492239+00
208	tasks	0016_auto_20220414_1408	2026-01-06 06:25:08.54229+00
209	tasks	0017_auto_20220330_1310	2026-01-06 06:25:08.633767+00
210	tasks	0018_manual_migrate_counters	2026-01-06 06:25:08.667674+00
211	tasks	0017_new_index_anno_result	2026-01-06 06:25:08.714238+00
212	tasks	0019_merge_20220512_2038	2026-01-06 06:25:08.717852+00
213	tasks	0020_auto_20220515_2332	2026-01-06 06:25:08.74787+00
214	tasks	0021_auto_20220515_2358	2026-01-06 06:25:08.856972+00
215	tasks	0020_auto_20220516_0545	2026-01-06 06:25:08.905398+00
216	tasks	0022_merge_20220517_1128	2026-01-06 06:25:08.909586+00
217	tasks	0023_auto_20220620_1007	2026-01-06 06:25:08.978306+00
218	data_manager	0001_initial	2026-01-06 06:25:09.038767+00
219	data_manager	0002_auto_20210201_1316	2026-01-06 06:25:09.042148+00
220	data_manager	0003_filter_index	2026-01-06 06:25:09.045112+00
221	data_manager	0004_auto_20210204_1231	2026-01-06 06:25:09.048347+00
222	data_manager	0005_view_user	2026-01-06 06:25:09.051808+00
223	data_manager	0002_remove_annotations_ids	2026-01-06 06:25:09.089098+00
224	data_manager	0003_remove_predictions_model_versions	2026-01-06 06:25:09.131563+00
225	data_manager	0004_remove_avg_lead_time	2026-01-06 06:25:09.168127+00
226	data_manager	0005_remove_updated_by	2026-01-06 06:25:09.206332+00
227	data_manager	0006_remove_inner_id	2026-01-06 06:25:09.242698+00
228	data_manager	0007_auto_20220708_0832	2026-01-06 06:25:09.283131+00
229	data_manager	0008_manual_counters_update	2026-01-06 06:25:09.319703+00
230	data_manager	0009_alter_view_user	2026-01-06 06:25:09.35562+00
231	data_manager	0010_auto_20230718_1423	2026-01-06 06:25:09.393722+00
232	data_manager	0011_auto_20240718_1355	2026-01-06 06:25:09.477726+00
233	data_manager	0012_alter_view_user	2026-01-06 06:25:09.514241+00
234	data_manager	0013_filter_parent_alter_filter_index	2026-01-06 06:25:09.908663+00
235	data_manager	0013_cleanup_inconsistent_filtergroup_20250624_2119	2026-01-06 06:25:09.955695+00
236	data_manager	0014_merge_20250701_2259	2026-01-06 06:25:09.959243+00
237	data_manager	0015_alter_view_options	2026-01-06 06:25:09.994709+00
238	data_manager	0016_migrate_agreement_selected_annotators_to_unique	2026-01-06 06:25:10.043231+00
239	data_manager	0017_update_agreement_selected_to_nested_structure	2026-01-06 06:25:10.096983+00
240	django_rq	0001_initial	2026-01-06 06:25:10.101465+00
241	tasks	0024_manual_migrate_counters_again	2026-01-06 06:25:10.137917+00
242	tasks	0025_auto_20220721_0110	2026-01-06 06:25:10.272193+00
243	tasks	0026_auto_20220725_1705	2026-01-06 06:25:10.331782+00
244	tasks	0027_auto_20220801_1728	2026-01-06 06:25:10.368957+00
245	tasks	0028_auto_20220802_2220	2026-01-06 06:25:10.396469+00
246	tasks	0029_annotation_project	2026-01-06 06:25:10.440272+00
247	tasks	0030_auto_20221102_1118	2026-01-06 06:25:10.478376+00
248	tasks	0031_alter_task_options	2026-01-06 06:25:10.509949+00
249	tasks	0032_annotation_updated_by	2026-01-06 06:25:10.559594+00
250	tasks	0033_annotation_updated_by_fill	2026-01-06 06:25:10.598113+00
251	tasks	0034_annotation_unique_id	2026-01-06 06:25:10.632603+00
252	tasks	0035_tasklock_unique_id	2026-01-06 06:25:10.65734+00
253	tasks	0036_auto_20221223_1102	2026-01-06 06:25:10.716553+00
254	tasks	0034_auto_20221221_1101	2026-01-06 06:25:10.883594+00
255	tasks	0035_auto_20221221_1116	2026-01-06 06:25:10.95687+00
256	tasks	0037_merge_0035_auto_20221221_1116_0036_auto_20221223_1102	2026-01-06 06:25:10.960175+00
257	tasks	0038_auto_20230209_1412	2026-01-06 06:25:11.029261+00
258	tasks	0039_annotation_draft_created_at	2026-01-06 06:25:11.068348+00
259	tasks	0040_auto_20230628_1101	2026-01-06 06:25:11.129097+00
260	projects	0022_projectimport	2026-01-06 06:25:11.178166+00
261	projects	0023_projectreimport	2026-01-06 06:25:11.223175+00
262	projects	0022_projectsummary_created_labels_drafts	2026-01-06 06:25:11.250235+00
263	projects	0023_merge_20230512_1333	2026-01-06 06:25:11.254101+00
264	projects	0024_merge_0023_merge_20230512_1333_0023_projectreimport	2026-01-06 06:25:11.259636+00
265	tasks	0041_prediction_project	2026-01-06 06:25:11.305589+00
266	tasks	0042_auto_20230810_2304	2026-01-06 06:25:11.349816+00
267	tasks	0043_auto_20230825	2026-01-06 06:25:11.390434+00
268	tasks	0044_auto_20230907_0155	2026-01-06 06:25:11.471349+00
269	tasks	0045_auto_20231124_1238	2026-01-06 06:25:11.531315+00
270	projects	0025_project_label_config_hash	2026-01-06 06:25:11.564646+00
271	projects	0026_auto_20231103_0020	2026-01-06 06:25:11.60637+00
272	organizations	0004_organization_contact_info	2026-01-06 06:25:11.629467+00
273	organizations	0005_organizationmember_deleted_at	2026-01-06 06:25:11.662363+00
274	organizations	0006_alter_organizationmember_deleted_at	2026-01-06 06:25:12.005308+00
275	ml_models	0001_initial	2026-01-06 06:25:12.100071+00
276	ml_models	0002_modelrun	2026-01-06 06:25:12.160052+00
277	ml_models	0003_auto_20240228_2228	2026-01-06 06:25:12.274336+00
278	ml_models	0004_modelrun_job_id	2026-01-06 06:25:12.312614+00
279	tasks	0046_prediction_model_run	2026-01-06 06:25:12.361548+00
280	ml	0001_initial	2026-01-06 06:25:12.498373+00
281	ml	0002_auto_20210308_1559	2026-01-06 06:25:12.588231+00
282	ml	0003_auto_20210309_1239	2026-01-06 06:25:12.698032+00
283	ml	0004_auto_20210820_1610	2026-01-06 06:25:12.78502+00
284	ml	0005_auto_20211010_1344	2026-01-06 06:25:12.853918+00
285	ml	0006_mlbackend_auto_update	2026-01-06 06:25:12.886708+00
286	ml	0007_auto_20240314_1957	2026-01-06 06:25:13.003366+00
287	tasks	0046_auto_20240314_1957	2026-01-06 06:25:13.085363+00
288	tasks	0047_merge_20240318_2210	2026-01-06 06:25:13.088755+00
289	ml_models	0005_auto_20240319_1738	2026-01-06 06:25:13.159422+00
290	ml_models	0006_alter_modelrun_project_subset	2026-01-06 06:25:13.194226+00
291	ml_models	0007_auto_20240617_2200	2026-01-06 06:25:13.265491+00
292	ml_models	0008_modelrun_total_tasks	2026-01-06 06:25:13.306926+00
293	ml_models	0009_alter_thirdpartymodelversion_provider	2026-01-06 06:25:13.331799+00
294	tasks	0048_failedprediction	2026-01-06 06:25:13.391731+00
295	tasks	0049_auto_20240905_1602	2026-01-06 06:25:13.465508+00
296	tasks	0050_alter_predictionmeta_failed_prediction_and_more	2026-01-06 06:25:13.550869+00
297	tasks	0051_tasklock_created_at	2026-01-06 06:25:13.585353+00
298	tasks	0052_auto_20241030_1757	2pg_dump: processing data for table "public.django_migrations"
pg_dump: dumping contents of table "public.django_migrations"
pg_dump: processing data for table "public.django_session"
pg_dump: dumping contents of table "public.django_session"
pg_dump: processing data for table "public.fsm_annotationstate"
pg_dump: dumping contents of table "public.fsm_annotationstate"
026-01-06 06:25:13.987471+00
299	tasks	0053_annotation_bulk_created	2026-01-06 06:25:14.027921+00
300	tasks	0054_add_brin_index_updated_at	2026-01-06 06:25:14.092944+00
301	tasks	0055_task_proj_octlen_idx_async	2026-01-06 06:25:14.155792+00
302	tasks	0056_task_prediction_result_proj_gin_idx_async	2026-01-06 06:25:14.219774+00
303	tasks	0057_annotation_proj_result_octlen_idx_async	2026-01-06 06:25:14.285903+00
304	projects	0027_project_custom_task_lock_ttl	2026-01-06 06:25:14.324806+00
305	projects	0028_auto_20241107_1031	2026-01-06 06:25:14.379113+00
306	projects	0029_project_search_vector_and_more	2026-01-06 06:25:14.423184+00
307	projects	0030_project_search_vector_index	2026-01-06 06:25:14.486774+00
308	fsm	0001_initial	2026-01-06 06:25:14.787374+00
309	io_storages	0002_auto_20210311_0530	2026-01-06 06:25:15.288277+00
310	io_storages	0003_localfilesimportstorage	2026-01-06 06:25:15.510525+00
311	io_storages	0004_gcsstoragemixin_google_application_credentials	2026-01-06 06:25:15.51983+00
312	io_storages	0005_s3importstorage_recursive_scan	2026-01-06 06:25:15.5601+00
313	io_storages	0006_auto_20210906_1323	2026-01-06 06:25:16.229263+00
314	io_storages	0007_auto_20210928_1252	2026-01-06 06:25:16.399241+00
315	io_storages	0008_auto_20211129_1132	2026-01-06 06:25:16.897552+00
316	io_storages	0009_auto_20220310_0922	2026-01-06 06:25:16.986927+00
317	io_storages	0010_auto_20221014_1708	2026-01-06 06:25:17.318887+00
318	io_storages	0011_gcsstoragemixin_google_project_id	2026-01-06 06:25:17.327737+00
319	io_storages	0012_auto_20230418_1510	2026-01-06 06:25:18.879097+00
320	io_storages	0013_auto_20230420_0259	2026-01-06 06:25:19.223063+00
321	io_storages	0014_init_statuses	2026-01-06 06:25:19.297117+00
322	io_storages	0015_auto_20230804_1732	2026-01-06 06:25:20.058563+00
323	io_storages	0016_add_aws_sse_kms_key	2026-01-06 06:25:20.146818+00
324	io_storages	0017_auto_20240731_1638	2026-01-06 06:25:20.299121+00
325	io_storages	0018_alter_azureblobexportstorage_project_and_more	2026-01-06 06:25:20.30313+00
326	io_storages	0019_azureblobimportstoragelink_row_group_and_more	2026-01-06 06:25:20.55765+00
327	io_storages	0020_alter_azureblobexportstorage_status_and_more	2026-01-06 06:25:20.910967+00
328	io_storages	0021_azureblobimportstorage_recursive_scan_and_more	2026-01-06 06:25:21.023271+00
329	io_storages	0022_normalize_localfiles_paths	2026-01-06 06:25:21.093298+00
330	jwt_auth	0001_initial	2026-01-06 06:25:21.159223+00
331	jwt_auth	0002_alter_jwtsettings_api_tokens_enabled_and_more	2026-01-06 06:25:21.189691+00
332	labels_manager	0001_initial	2026-01-06 06:25:21.427754+00
333	labels_manager	0002_auto_20220131_1325	2026-01-06 06:25:21.479619+00
334	labels_manager	0003_auto_20221213_1612	2026-01-06 06:25:21.638478+00
335	ml_model_providers	0001_initial	2026-01-06 06:25:22.323378+00
336	ml_model_providers	0002_auto_20240722_2054	2026-01-06 06:25:22.409039+00
337	ml_model_providers	0003_modelproviderconnection_cached_available_models	2026-01-06 06:25:22.447977+00
338	ml_model_providers	0004_auto_20240830_1206	2026-01-06 06:25:22.506112+00
339	ml_model_providers	0005_modelproviderconnection_budget_alert_threshold_and_more	2026-01-06 06:25:22.677148+00
340	ml_model_providers	0006_modelproviderconnection_google_application_credentials_and_more	2026-01-06 06:25:22.805117+00
341	ml_model_providers	0007_alter_modelproviderconnection_provider	2026-01-06 06:25:22.837888+00
342	ml_model_providers	0008_alter_modelproviderconnection_provider	2026-01-06 06:25:22.88075+00
343	ml_model_providers	0009_alter_modelproviderconnection_provider	2026-01-06 06:25:22.915382+00
344	ml_models	0010_modelinterface_skill_name	2026-01-06 06:25:22.970452+00
345	ml_models	0011_thirdpartymodelversion_model_provider_connection	2026-01-06 06:25:23.105748+00
346	ml_models	0012_alter_thirdpartymodelversion_provider	2026-01-06 06:25:23.137104+00
347	ml_models	0013_alter_thirdpartymodelversion_provider	2026-01-06 06:25:23.16911+00
348	ml_models	0014_alter_thirdpartymodelversion_provider	2026-01-06 06:25:23.209871+00
349	ml_models	0015_alter_thirdpartymodelversion_provider	2026-01-06 06:25:23.250075+00
350	ml_models	0016_alter_thirdpartymodelversion_provider	2026-01-06 06:25:23.283443+00
351	projects	0031_alter_project_show_ground_truth_first	2026-01-06 06:25:23.350729+00
352	projects	0032_project_deleted_at_project_deleted_by_and_more	2026-01-06 06:25:23.537434+00
353	projects	0033_projects_soft_delete_indexes_async	2026-01-06 06:25:23.647021+00
354	session_policy	0001_initial	2026-01-06 06:25:23.731614+00
355	session_policy	0002_alter_sessiontimeoutpolicy_max_session_age_and_more	2026-01-06 06:25:23.772289+00
356	session_policy	0003_alter_sessiontimeoutpolicy_max_session_age_and_more	2026-01-06 06:25:23.810076+00
357	sessions	0001_initial	2026-01-06 06:25:23.826047+00
358	tasks	0058_task_precomputed_agreement	2026-01-06 06:25:23.881868+00
359	tasks	0059_task_completion_id_updated_at_idx_async	2026-01-06 06:25:23.978409+00
360	tasks	0060_add_allow_skip_to_task	2026-01-06 06:25:24.036433+00
361	token_blacklist	0001_initial	2026-01-06 06:25:24.540515+00
362	token_blacklist	0002_outstandingtoken_jti_hex	2026-01-06 06:25:24.581194+00
363	token_blacklist	0003_auto_20171017_2007	2026-01-06 06:25:24.665008+00
364	token_blacklist	0004_auto_20171017_2013	2026-01-06 06:25:24.706353+00
365	token_blacklist	0005_remove_outstandingtoken_jti	2026-01-06 06:25:24.744734+00
366	token_blacklist	0006_auto_20171017_2113	2026-01-06 06:25:24.795588+00
367	token_blacklist	0007_auto_20171017_2214	2026-01-06 06:25:24.933696+00
368	token_blacklist	0008_migrate_to_bigautofield	2026-01-06 06:25:25.05319+00
369	token_blacklist	0010_fix_migrate_to_bigautofield	2026-01-06 06:25:25.139392+00
370	token_blacklist	0011_linearizes_history	2026-01-06 06:25:25.144364+00
371	token_blacklist	0012_alter_outstandingtoken_user	2026-01-06 06:25:25.214405+00
372	token_blacklist	0013_alter_blacklistedtoken_options_and_more	2026-01-06 06:25:25.257168+00
373	users	0002_auto_20210308_1559	2026-01-06 06:25:25.393975+00
374	users	0003_user_active_organization	2026-01-06 06:25:25.479398+00
375	users	0004_auto_20210914_0109	2026-01-06 06:25:25.651612+00
376	users	0005_auto_20211010_1339	2026-01-06 06:25:25.71782+00
377	users	0006_user_allow_newsletters	2026-01-06 06:25:25.757376+00
378	users	0007_user_is_deleted	2026-01-06 06:25:25.803335+00
379	users	0008_alter_user_managers	2026-01-06 06:25:25.852382+00
380	users	0009_auto_20231201_0001	2026-01-06 06:25:25.919181+00
381	users	0010_userproducttour	2026-01-06 06:25:26.017368+00
382	users	0011_user_custom_hotkeys	2026-01-06 06:25:26.059053+00
383	webhooks	0001_initial	2026-01-06 06:25:26.220859+00
384	webhooks	0002_auto_20220319_0013	2026-01-06 06:25:26.877997+00
385	webhooks	0003_alter_webhookaction_action	2026-01-06 06:25:26.890063+00
386	webhooks	0004_auto_20221221_1101	2026-01-06 06:25:27.042582+00
387	users	0001_squashed_0009_auto_20210219_1237	2026-01-06 06:25:27.06218+00
388	organizations	0001_squashed_0008_auto_20201005_1552	2026-01-06 06:25:27.06618+00
389	projects	0001_squashed_0065_auto_20210223_2014	2026-01-06 06:25:27.070943+00
390	tasks	0001_squashed_0041_taskcompletionhistory_was_cancelled	2026-01-06 06:25:27.075516+00
391	data_manager	0001_squashed_0005_view_user	2026-01-06 06:25:27.080355+00
392	io_storages	0001_squashed_0002_auto_20210302_1827	2026-01-06 06:25:27.084182+00
\.


--
-- TOC entry 5418 (class 0 OID 27578)
-- Dependencies: 358
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- TOC entry 5399 (class 0 OID 27126)
-- Dependencies: 339
-- Data for Name: fsm_annotationstate; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.fsm_annotationstate (id, organization_id, previous_state, transition_name, context_data, reason, created_at, state, task_id, project_id, completed_by_id, annotation_id, triggered_by_id) FROM stdin;
\.


--
-- TOC entry 5400 (class 0 OID 27145)
-- Dependencies: 340
-- Data for Name: fsm_projectstate; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.fsm_projectstate (id, organization_id, previous_state, transition_name, context_data, reason, created_at, state, created_by_id, project_id, triggered_by_id) FROM stdin;
\.


--
-- TOC entry 5401 (class 0 OID 27160)
-- Dependencies: 341
-- Data for Name: fsm_taskstate; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.fsm_taskstate (id, organization_id, previous_state, transition_name, context_data, reason, created_at, state, project_id, task_id, triggered_by_id) FROM stdin;
\.


--
-- TOC entry 5292 (class 0 OID 24841)
-- Dependencies: 232
-- Data for Name: htx_user; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.htx_user (id, password, last_login, is_superuser, username, email, first_name, last_name, is_staff, is_active, date_joined, last_activity, activity_at, phone, avatar, active_organization_id, allow_newsletters, custom_hotkeys) FROM stdin;
1	pbkdf2_sha256$870000$aWy6PJCB0AeWixDtIXsL0l$x+iMtjcuAg+CQ9QKB8Pn/E0ktEOpPz7c+6A1DFEUeis=	2026-01-06 22:26:11.537844+00	f	bob	bob@bomar.us			f	t	2026-01-06 06:33:34.247497+00	2026-01-06 23:30:22.983991+00	2026-01-06 23:30:23.091866+00			1	f	{}
\.


--
-- TOC entry 5294 (class 0 OID 24862)
-- Dependencies: 234
-- Data for Name: htx_user_groups; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.htx_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- TOC entry 5296 (class 0 OID 24871)
-- Dependencies: 236
-- Data for Name: htx_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.htx_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- TOC entry 5345 (class 0 OID 25707)
-- Dependencies: 285
-- Data for Name: io_storages_azureblobexportstorage; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_azureblobexportstorage (azureblobstoragemixin_ptr_id, title, description, created_at, project_id, last_sync, last_sync_count, can_delete_objects, last_sync_job, meta, status, traceback, synchronizable) FROM stdin;
\.


--
-- TOC entry 5366 (class 0 OID 25881)
-- Dependencies: 306
-- Data for Name: io_storages_azureblobexportstoragelink; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_azureblobexportstoragelink (id, object_exists, created_at, annotation_id, storage_id, updated_at) FROM stdin;
\.


--
-- TOC entry 5346 (class 0 OID 25717)
-- Dependencies: 286
-- Data for Name: io_storages_azureblobimportstorage; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_azureblobimportstorage (azureblobstoragemixin_ptr_id, title, description, created_at, presign, presign_ttl, project_id, last_sync, last_sync_count, last_sync_job, meta, status, traceback, synchronizable, recursive_scan) FROM stdin;
\.


--
-- TOC entry 5364 (class 0 OID 25865)
-- Dependencies: 304
-- Data for Name: io_storages_azureblobimportstoragelink; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_azureblobimportstoragelink (id, key, object_exists, created_at, task_id, storage_id, row_group, row_index) FROM stdin;
\.


--
-- TOC entry 5336 (class 0 OID 25651)
-- Dependencies: 276
-- Data for Name: io_storages_azureblobstoragemixin; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_azureblobstoragemixin (id, container, prefix, regex_filter, use_blob_urls, account_name, account_key) FROM stdin;
\.


--
-- TOC entry 5347 (class 0 OID 25730)
-- Dependencies: 287
-- Data for Name: io_storages_gcsexportstorage; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_gcsexportstorage (gcsstoragemixin_ptr_id, title, description, created_at, project_id, last_sync, last_sync_count, can_delete_objects, last_sync_job, meta, status, traceback, synchronizable) FROM stdin;
\.


--
-- TOC entry 5362 (class 0 OID 25852)
-- Dependencies: 302
-- Data for Name: io_storages_gcsexportstoragelink; Type: TABLE DATA; pg_dump: processing data for table "public.fsm_projectstate"
pg_dump: dumping contents of table "public.fsm_projectstate"
pg_dump: processing data for table "public.fsm_taskstate"
pg_dump: dumping contents of table "public.fsm_taskstate"
pg_dump: processing data for table "public.htx_user"
pg_dump: dumping contents of table "public.htx_user"
pg_dump: processing data for table "public.htx_user_groups"
pg_dump: dumping contents of table "public.htx_user_groups"
pg_dump: processing data for table "public.htx_user_user_permissions"
pg_dump: dumping contents of table "public.htx_user_user_permissions"
pg_dump: processing data for table "public.io_storages_azureblobexportstorage"
pg_dump: dumping contents of table "public.io_storages_azureblobexportstorage"
pg_dump: processing data for table "public.io_storages_azureblobexportstoragelink"
pg_dump: dumping contents of table "public.io_storages_azureblobexportstoragelink"
pg_dump: processing data for table "public.io_storages_azureblobimportstorage"
pg_dump: dumping contents of table "public.io_storages_azureblobimportstorage"
pg_dump: processing data for table "public.io_storages_azureblobimportstoragelink"
pg_dump: dumping contents of table "public.io_storages_azureblobimportstoragelink"
pg_dump: processing data for table "public.io_storages_azureblobstoragemixin"
pg_dump: dumping contents of table "public.io_storages_azureblobstoragemixin"
pg_dump: processing data for table "public.io_storages_gcsexportstorage"
pg_dump: dumping contents of table "public.io_storages_gcsexportstorage"
pg_dump: processing data for table "public.io_storages_gcsexportstoragelink"
pg_dump: dumping contents of table "public.io_storages_gcsexportstoragelink"
pg_dump: processing data for table "public.io_storages_gcsimportstorage"
pg_dump: dumping contents of table "public.io_storages_gcsimportstorage"
pg_dump: processing data for table "public.io_storages_gcsimportstoragelink"
pg_dump: dumping contents of table "public.io_storages_gcsimportstoragelink"
pg_dump: processing data for table "public.io_storages_gcsstoragemixin"
pg_dump: dumping contents of table "public.io_storages_gcsstoragemixin"
pg_dump: processing data for table "public.io_storages_localfilesexportstorage"
pg_dump: dumping contents of table "public.io_storages_localfilesexportstorage"
pg_dump: processing data for table "public.io_storages_localfilesexportstoragelink"
pg_dump: dumping contents of table "public.io_storages_localfilesexportstoragelink"
pg_dump: processing data for table "public.io_storages_localfilesimportstorage"
pg_dump: dumping contents of table "public.io_storages_localfilesimportstorage"
Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_gcsexportstoragelink (id, object_exists, created_at, annotation_id, storage_id, updated_at) FROM stdin;
\.


--
-- TOC entry 5348 (class 0 OID 25740)
-- Dependencies: 288
-- Data for Name: io_storages_gcsimportstorage; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_gcsimportstorage (gcsstoragemixin_ptr_id, title, description, created_at, presign, presign_ttl, project_id, last_sync, last_sync_count, last_sync_job, meta, status, traceback, synchronizable, recursive_scan) FROM stdin;
\.


--
-- TOC entry 5360 (class 0 OID 25836)
-- Dependencies: 300
-- Data for Name: io_storages_gcsimportstoragelink; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_gcsimportstoragelink (id, key, object_exists, created_at, task_id, storage_id, row_group, row_index) FROM stdin;
\.


--
-- TOC entry 5338 (class 0 OID 25661)
-- Dependencies: 278
-- Data for Name: io_storages_gcsstoragemixin; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_gcsstoragemixin (id, bucket, prefix, regex_filter, use_blob_urls, google_application_credentials, google_project_id) FROM stdin;
\.


--
-- TOC entry 5404 (class 0 OID 27255)
-- Dependencies: 344
-- Data for Name: io_storages_localfilesexportstorage; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_localfilesexportstorage (localfilesmixin_ptr_id, title, description, created_at, last_sync, last_sync_count, project_id, can_delete_objects, last_sync_job, meta, status, traceback, synchronizable) FROM stdin;
2	WOPR - Target - NFS	\N	2026-01-06 22:26:55.473991+00	2026-01-06 22:26:55.502505+00	0	1	\N	\N	{"attempts": 1, "duration": 0.008492, "time_queued": "2026-01-06 22:26:55.483671+00:00", "time_completed": "2026-01-06 22:26:55.502509+00:00", "time_last_ping": "2026-01-06 22:26:55.494017+00:00", "time_in_progress": "2026-01-06 22:26:55.494017+00:00", "total_annotations": 0}	completed	\N	t
\.


--
-- TOC entry 5409 (class 0 OID 27294)
-- Dependencies: 349
-- Data for Name: io_storages_localfilesexportstoragelink; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_localfilesexportstoragelink (id, object_exists, created_at, annotation_id, storage_id, updated_at) FROM stdin;
1	t	2026-01-06 22:56:49.889048+00	1	2	2026-01-06 22:56:49.889061+00
2	t	2026-01-06 22:57:36.049629+00	2	2	2026-01-06 22:57:36.049639+00
3	t	2026-01-06 23:09:58.955323+00	3	2	2026-01-06 23:10:28.487938+00
4	t	2026-01-06 23:11:03.485355+00	4	2	2026-01-06 23:11:03.485365+00
5	t	2026-01-06 23:11:32.207584+00	5	2	2026-01-06 23:11:32.207598+00
6	t	2026-01-06 23:12:24.266278+00	6	2	2026-01-06 23:12:24.266288+00
7	t	2026-01-06 23:14:07.859702+00	7	2	2026-01-06 23:14:07.859712+00
8	t	2026-01-06 23:14:38.329655+00	8	2	2026-01-06 23:14:38.32967+00
9	t	2026-01-06 23:15:04.676939+00	9	2	2026-01-06 23:15:04.676949+00
10	t	2026-01-06 23:15:56.336315+00	10	2	2026-01-06 23:15:56.336324+00
11	t	2026-01-06 23:16:06.549382+00	11	2	2026-01-06 23:16:06.549393+00
12	t	2026-01-06 23:16:16.466955+00	12	2	2026-01-06 23:16:16.466965+00
13	t	2026-01-06 23:16:44.92289+00	13	2	2026-01-06 23:16:44.922901+00
14	t	2026-01-06 23:16:54.38565+00	14	2	2026-01-06 23:16:54.38566+00
15	t	2026-01-06 23:27:55.249184+00	15	2	2026-01-06 23:27:55.249196+00
16	t	2026-01-06 23:28:06.634795+00	16	2	2026-01-06 23:28:06.634806+00
17	t	2026-01-06 23:28:17.162371+00	17	2	2026-01-06 23:28:17.162382+00
18	t	2026-01-06 23:28:26.52498+00	18	2	2026-01-06 23:28:26.524989+00
19	t	2026-01-06 23:28:36.213682+00	19	2	2026-01-06 23:28:36.213694+00
20	t	2026-01-06 23:28:46.575652+00	20	2	2026-01-06 23:28:46.575663+00
21	t	2026-01-06 23:29:10.122518+00	21	2	2026-01-06 23:29:10.122528+00
22	t	2026-01-06 23:29:19.373445+00	22	2	2026-01-06 23:29:19.373455+00
23	t	2026-01-06 23:29:28.475432+00	23	2	2026-01-06 23:29:28.475442+00
24	t	2026-01-06 23:29:39.032567+00	24	2	2026-01-06 23:29:39.032578+00
25	t	2026-01-06 23:29:49pg_dump: processing data for table "public.io_storages_localfilesimportstoragelink"
pg_dump: dumping contents of table "public.io_storages_localfilesimportstoragelink"
pg_dump: processing data for table "public.io_storages_localfilesmixin"
pg_dump: dumping contents of table "public.io_storages_localfilesmixin"
.170723+00	25	2	2026-01-06 23:29:49.170734+00
26	t	2026-01-06 23:29:57.928417+00	26	2	2026-01-06 23:29:57.928427+00
27	t	2026-01-06 23:30:06.709681+00	27	2	2026-01-06 23:30:06.709691+00
28	t	2026-01-06 23:30:14.65229+00	28	2	2026-01-06 23:30:14.652304+00
29	t	2026-01-06 23:30:23.074942+00	29	2	2026-01-06 23:30:23.074969+00
\.


--
-- TOC entry 5405 (class 0 OID 27266)
-- Dependencies: 345
-- Data for Name: io_storages_localfilesimportstorage; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_localfilesimportstorage (localfilesmixin_ptr_id, title, description, created_at, last_sync, last_sync_count, project_id, last_sync_job, meta, status, traceback, synchronizable, recursive_scan) FROM stdin;
1	WOPR - Source - NFS	\N	2026-01-06 22:26:37.396305+00	2026-01-06 22:30:39.311428+00	30	1	\N	{"attempts": 2, "duration": 0.393564, "time_queued": "2026-01-06 22:30:38.911486+00:00", "tasks_existed": 0, "time_completed": "2026-01-06 22:30:39.311431+00:00", "time_last_ping": "2026-01-06 22:30:38.917867+00:00", "time_in_progress": "2026-01-06 22:30:38.917867+00:00"}	completed	Traceback (most recent call last):\n  File "/label-studio/label_studio/io_storages/base_models.py", line 731, in import_sync_background\n    storage.scan_and_create_links()\n    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^^\n  File "/label-studio/label_studio/io_storages/localfiles/models.py", line 172, in scan_and_create_links\n    return self._scan_and_create_links(LocalFilesImportStorageLink)\n           ~~~~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File "/label-studio/label_studio/io_storages/base_models.py", line 587, in _scan_and_create_links\n    raise UnsupportedFileFormatError(\n    ...<3 lines>...\n    )\nio_storages.exceptions.UnsupportedFileFormatError: File "/label-studio/mydata/labelstudio/source/15-4-082b0b5c-c2d4-4d23-8f80-76570bd292e3.jpg" is not a JSON/JSONL/Parquet file. Only .json, .jsonl, and .parquet files can be processed.\nIf you're trying to import non-JSON data (images, audio, text, etc.), edit storage settings and enable "Tasks" import method\n	t	f
\.


--
-- TOC entry 5407 (class 0 OID 27278)
-- Dependencies: 347
-- Data for Name: io_storages_localfilesimportstoragelink; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_localfilesimportstoragelink (id, key, object_exists, created_at, task_id, storage_id, row_group, row_index) FROM stdin;
1	/label-studio/mydata/labelstudio/source/15-4-082b0b5c-c2d4-4d23-8f80-76570bd292e3.jpg	t	2026-01-06 22:30:38.939263+00	1	1	\N	\N
2	/label-studio/mydata/labelstudio/source/15-4-1156042f-713d-471b-82bf-b9ff670e8b5d.jpg	t	2026-01-06 22:30:38.952731+00	2	1	\N	\N
3	/label-studio/mydata/labelstudio/source/15-4-138922bb-4039-4418-a0d2-60599b7a5831.jpg	t	2026-01-06 22:30:38.964601+00	3	1	\N	\N
4	/label-studio/mydata/labelstudio/source/15-4-2c5a5b3b-3edc-4a63-97bf-a8ca611e6359.jpg	t	2026-01-06 22:30:38.978478+00	4	1	\N	\N
5	/label-studio/mydata/labelstudio/source/15-4-352d8816-1adb-44e6-8d30-f00bf1e7c692.jpg	t	2026-01-06 22:30:38.991471+00	5	1	\N	\N
6	/label-studio/mydata/labelstudio/source/15-4-3e11cf06-0251-47dd-8df1-f5fbbcdd3939.jpg	t	2026-01-06 22:30:39.004429+00	6	1	\N	\N
7	/label-studio/mydata/labelstudio/source/15-4-429c948e-1446-4c6c-823b-f53af50ac9b6.jpg	t	2026-01-06 22:30:39.017373+00	7	1	\N	\N
8	/label-studio/mydata/labelstudio/source/15-4-4782053a-a4ca-4cc1-8d83-8d79017864be.jpg	t	2026-01-06 22:30:39.029826+00	8	1	\N	\N
9	/label-studio/mydata/labelstudio/source/15-4-49d7b98a-e5fa-4507-bde4-7a7c4ac78fb9.jpg	t	2026-01-06 22:30:39.044543+00	9	1	\N	\N
10	/label-studio/mydata/labelstudio/source/15-4-4eb32dd4-4d36-44c2-930a-5e985ba18ba3.jpg	t	2026-01-06 22:30:39.057228+00	10	1	\N	\N
11	/label-studio/mydata/labelstudio/source/15-4-502c252b-425a-4512-96aa-19ca4be391d4.jpg	t	2026-01-06 22:30:39.071571+00	11	1	\N	\N
12	/label-studio/mydata/labelstudio/source/15-4-5337b2bd-8a71-46a4-b053-59742ea6bca3.jpg	t	2026-01-06 22:30:39.084226+00	12	1	\N	\N
13	/label-studio/mydata/labelstudio/source/15-4-58d50d89-0d8d-4e5c-978d-aac2fcpg_dump: processing data for table "public.io_storages_redisexportstorage"
pg_dump: dumping contents of table "public.io_storages_redisexportstorage"
pg_dump: processing data for table "public.io_storages_redisexportstoragelink"
pg_dump: dumping contents of table "public.io_storages_redisexportstoragelink"
45841d.jpg	t	2026-01-06 22:30:39.095907+00	13	1	\N	\N
14	/label-studio/mydata/labelstudio/source/15-4-64cb597f-639a-4b30-86a3-ceb190c00074.jpg	t	2026-01-06 22:30:39.10813+00	14	1	\N	\N
15	/label-studio/mydata/labelstudio/source/15-4-72ed6794-3aef-4d1b-bc1d-e041d79a6898.jpg	t	2026-01-06 22:30:39.120257+00	15	1	\N	\N
16	/label-studio/mydata/labelstudio/source/15-4-7944784e-bdf5-4182-8acc-9b9a229b89e5.jpg	t	2026-01-06 22:30:39.132714+00	16	1	\N	\N
17	/label-studio/mydata/labelstudio/source/15-4-7d73aee6-da44-4cc3-8859-68d3dfc1936c.jpg	t	2026-01-06 22:30:39.145113+00	17	1	\N	\N
18	/label-studio/mydata/labelstudio/source/15-4-86731d17-875d-41b6-a9aa-fd3963e04013.jpg	t	2026-01-06 22:30:39.157484+00	18	1	\N	\N
19	/label-studio/mydata/labelstudio/source/15-4-88f00ad9-cf00-422b-bac8-a3b1eab78782.jpg	t	2026-01-06 22:30:39.169677+00	19	1	\N	\N
20	/label-studio/mydata/labelstudio/source/15-4-8b91290f-fe26-4029-82ea-826b691e445b.jpg	t	2026-01-06 22:30:39.182083+00	20	1	\N	\N
21	/label-studio/mydata/labelstudio/source/15-4-a5188272-78e3-46e8-b888-c4ae1bb66abc.jpg	t	2026-01-06 22:30:39.194834+00	21	1	\N	\N
22	/label-studio/mydata/labelstudio/source/15-4-cb263722-f788-414a-a57c-acfbf5f32f39.jpg	t	2026-01-06 22:30:39.206603+00	22	1	\N	\N
23	/label-studio/mydata/labelstudio/source/15-4-cce57477-652d-4607-9f75-57d37ce23819.jpg	t	2026-01-06 22:30:39.219173+00	23	1	\N	\N
24	/label-studio/mydata/labelstudio/source/15-4-cfff75f1-b31a-4b32-9844-65227345c259.jpg	t	2026-01-06 22:30:39.230468+00	24	1	\N	\N
25	/label-studio/mydata/labelstudio/source/15-4-d055a31b-8127-4b9d-a525-0d096a755e80.jpg	t	2026-01-06 22:30:39.242021+00	25	1	\N	\N
26	/label-studio/mydata/labelstudio/source/15-4-d11f1f02-f198-44b7-9c06-cfd06f4634d8.jpg	t	2026-01-06 22:30:39.25474+00	26	1	\N	\N
27	/label-studio/mydata/labelstudio/source/15-4-d9acd417-c548-4b3c-9c16-f84f364d9cb9.jpg	t	2026-01-06 22:30:39.266694+00	27	1	\N	\N
28	/label-studio/mydata/labelstudio/source/15-4-de0748da-acd4-4831-9c2e-90fb08dfa314.jpg	t	2026-01-06 22:30:39.27834+00	28	1	\N	\N
29	/label-studio/mydata/labelstudio/source/15-4-e41381c8-4de9-4bf8-a423-87080f2ccb7e.jpg	t	2026-01-06 22:30:39.290229+00	29	1	\N	\N
30	/label-studio/mydata/labelstudio/source/15-4-ff526d40-0dc1-4928-9cec-32c7c029ad0d.jpg	t	2026-01-06 22:30:39.301857+00	30	1	\N	\N
\.


--
-- TOC entry 5403 (class 0 OID 27246)
-- Dependencies: 343
-- Data for Name: io_storages_localfilesmixin; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_localfilesmixin (id, path, regex_filter, use_blob_urls) FROM stdin;
2	/label-studio/mydata/labelstudio/target		f
1	/label-studio/mydata/labelstudio/source		t
\.


--
-- TOC entry 5349 (class 0 OID 25753)
-- Dependencies: 289
-- Data for Name: io_storages_redisexportstorage; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_redisexportstorage (redisstoragemixin_ptr_id, title, description, created_at, db, project_id, last_sync, last_sync_count, can_delete_objects, last_sync_job, meta, status, traceback, synchronizable) FROM stdin;
\.


--
-- TOC entry 5358 (class 0 OID 25823)
-- Dependencies: 298
-- Data for Name: io_storages_redisexportstoragelink; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_redisexportstoragelink (id, object_exists, created_at, annotation_id, storage_id, updated_at) FROM stdin;
\.


--
-- TOC entry 5350 (class 0 OID 25765)
-- Dependencies: 290
-- Data for Name: io_storages_redisimportstorage; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_redisimportstorage (redisstoragemixin_ptr_id, title, description, created_at, db, project_id, last_sync, last_sync_count, last_sync_job, meta, status, traceback, synchronizable) FROM stdin;
\.


--
-- TOC entry 5356 (class 0 OID 25807)
-- Dependencies: 296
-- Data for Name: io_storages_redisimportstoragelink; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_redisimportstoragelink (id, key, object_exists, created_at, task_id, storage_pg_dump: processing data for table "public.io_storages_redisimportstorage"
pg_dump: dumping contents of table "public.io_storages_redisimportstorage"
pg_dump: processing data for table "public.io_storages_redisimportstoragelink"
pg_dump: dumping contents of table "public.io_storages_redisimportstoragelink"
pg_dump: processing data for table "public.io_storages_redisstoragemixin"
pg_dump: dumping contents of table "public.io_storages_redisstoragemixin"
pg_dump: processing data for table "public.io_storages_s3exportstorage"
pg_dump: dumping contents of table "public.io_storages_s3exportstorage"
pg_dump: processing data for table "public.io_storages_s3exportstoragelink"
pg_dump: dumping contents of table "public.io_storages_s3exportstoragelink"
id, row_group, row_index) FROM stdin;
\.


--
-- TOC entry 5340 (class 0 OID 25671)
-- Dependencies: 280
-- Data for Name: io_storages_redisstoragemixin; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_redisstoragemixin (id, path, host, port, password, regex_filter, use_blob_urls) FROM stdin;
\.


--
-- TOC entry 5342 (class 0 OID 25681)
-- Dependencies: 282
-- Data for Name: io_storages_s3exportstorage; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_s3exportstorage (id, title, description, created_at, bucket, prefix, regex_filter, use_blob_urls, aws_access_key_id, aws_secret_access_key, aws_session_token, region_name, s3_endpoint, project_id, last_sync, last_sync_count, can_delete_objects, last_sync_job, meta, status, traceback, synchronizable, aws_sse_kms_key_id) FROM stdin;
1	WOPR - Target - S3	\N	2026-01-06 22:15:15.852555+00	wopr-ls-target-bucket			f	FBVX7HQB1HAWUQQCWVGH	K0U4yPRwCnCM5MS6DXTaItr7uCwErRgD3xIEawIx			http://rook-ceph-rgw-objectstore.rook-ceph.svc	1	2026-01-06 22:25:03.743023+00	0	\N	\N	{"attempts": 2, "duration": 0.007306, "time_queued": "2026-01-06 22:25:03.726902+00:00", "time_completed": "2026-01-06 22:25:03.743025+00:00", "time_last_ping": "2026-01-06 22:25:03.735719+00:00", "time_in_progress": "2026-01-06 22:25:03.735719+00:00", "total_annotations": 0}	completed	\N	t	\N
\.


--
-- TOC entry 5354 (class 0 OID 25794)
-- Dependencies: 294
-- Data for Name: io_storages_s3exportstoragelink; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_s3exportstoragelink (id, object_exists, created_at, annotation_id, storage_id, updated_at) FROM stdin;
1	t	2026-01-06 22:56:49.868603+00	1	1	2026-01-06 22:56:49.868612+00
2	t	2026-01-06 22:57:36.030676+00	2	1	2026-01-06 22:57:36.030688+00
3	t	2026-01-06 23:09:58.937989+00	3	1	2026-01-06 23:10:28.470654+00
4	t	2026-01-06 23:11:03.466934+00	4	1	2026-01-06 23:11:03.466948+00
5	t	2026-01-06 23:11:32.190591+00	5	1	2026-01-06 23:11:32.190604+00
6	t	2026-01-06 23:12:24.247969+00	6	1	2026-01-06 23:12:24.247982+00
7	t	2026-01-06 23:14:07.842893+00	7	1	2026-01-06 23:14:07.842906+00
8	t	2026-01-06 23:14:38.307867+00	8	1	2026-01-06 23:14:38.307881+00
9	t	2026-01-06 23:15:04.659141+00	9	1	2026-01-06 23:15:04.659163+00
10	t	2026-01-06 23:15:56.320116+00	10	1	2026-01-06 23:15:56.320143+00
11	t	2026-01-06 23:16:06.532655+00	11	1	2026-01-06 23:16:06.532681+00
12	t	2026-01-06 23:16:16.450956+00	12	1	2026-01-06 23:16:16.450968+00
13	t	2026-01-06 23:16:44.907178+00	13	1	2026-01-06 23:16:44.90719+00
14	t	2026-01-06 23:16:54.369336+00	14	1	2026-01-06 23:16:54.36935+00
15	t	2026-01-06 23:27:55.232314+00	15	1	2026-01-06 23:27:55.232326+00
16	t	2026-01-06 23:28:06.61834+00	16	1	2026-01-06 23:28:06.618353+00
17	t	2026-01-06 23:28:17.14589+00	17	1	2026-01-06 23:28:17.145905+00
18	t	2026-01-06 23:28:26.509723+00	18	1	2026-01-06 23:28:26.509735+00
19	t	2026-01-06 23:28:36.19315+00	19	1	2026-01-06 23:28:36.193163+00
20	t	2026-01-06 23:28:46.560226+00	20	1	2026-01-06 23:28:46.560239+00
21	t	2026-01-06 23:29:10.106395+00	21	1	2026-01-06 23:29:10.106407+00
22	t	2026-01-06 23:29:19.357851+00	22	1	2026-01-06 23:29:19.35787+00
23	t	2026-01-06 23:29:28.457472+00	23	1	2026-01-06 23:29:28.457483+00
24	t	2026-01-06 23:29:39.013341+00	24	1	2026-01-06 23:29:39.013354+00
25	t	2026-01-06 23:29:49.15405+00	25	1	2026-01-06 23:29:49.154061+00
26	t	2026-01-06 23:29:57.912065+00	26	1	2026-01-06 23:29:57.912079+00
27	t	2026-01-06 23:30:06.694342+00	27	1	2026-01-06 23:30:06.694354+00
28	t	2026-01-06 23:30:14.63734+00	28	1	2026-01-06 23:30:14.637355+00
29	t	2026-01-06 23:30:23.060081+00	29	1	2026-01-06 23:30:23.060094+00
\.


--
-- TOC entry 5344 (class 0 OID 25693)
-- Dependencies: 284
-- Data for Name: io_storages_s3importstorage; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_s3importstorage (id, title, description, created_at, bucket, prefix, regex_filter, use_blob_urls, aws_access_key_id, aws_secret_access_key, aws_session_token, regpg_dump: processing data for table "public.io_storages_s3importstorage"
pg_dump: dumping contents of table "public.io_storages_s3importstorage"
pg_dump: processing data for table "public.io_storages_s3importstoragelink"
pg_dump: dumping contents of table "public.io_storages_s3importstoragelink"
pg_dump: processing data for table "public.jwt_auth_jwtsettings"
pg_dump: dumping contents of table "public.jwt_auth_jwtsettings"
pg_dump: processing data for table "public.labels_manager_label"
pg_dump: dumping contents of table "public.labels_manager_label"
pg_dump: processing data for table "public.labels_manager_labellink"
pg_dump: dumping contents of table "public.labels_manager_labellink"
pg_dump: processing data for table "public.ml_mlbackend"
pg_dump: dumping contents of table "public.ml_mlbackend"
pg_dump: processing data for table "public.ml_mlbackendpredictionjob"
pg_dump: dumping contents of table "public.ml_mlbackendpredictionjob"
pg_dump: processing data for table "public.ml_mlbackendtrainjob"
pg_dump: dumping contents of table "public.ml_mlbackendtrainjob"
pg_dump: processing data for table "public.ml_model_providers_modelproviderconnection"
pg_dump: dumping contents of table "public.ml_model_providers_modelproviderconnection"
pg_dump: processing data for table "public.ml_models_modelinterface"
pg_dump: dumping contents of table "public.ml_models_modelinterface"
pg_dump: processing data for table "public.ml_models_modelinterface_associated_projects"
pg_dump: dumping contents of table "public.ml_models_modelinterface_associated_projects"
pg_dump: processing data for table "public.ml_models_modelrun"
pg_dump: dumping contents of table "public.ml_models_modelrun"
ion_name, s3_endpoint, presign, presign_ttl, project_id, last_sync, last_sync_count, recursive_scan, last_sync_job, meta, status, traceback, synchronizable, aws_sse_kms_key_id) FROM stdin;
2	WOPR - Source - S3	\N	2026-01-06 22:11:43.787868+00	wopr-ls-source-bucket			f	8CDZT21FB40O26TOL7LK	vuPidN6OWAAYuyCgPBI6V9bYAJrx7PLJh0nVhzm4			http://rook-ceph-rgw-objectstore.rook-ceph.svc	t	15	1	2026-01-06 22:25:01.518129+00	0	f	\N	{"attempts": 1, "duration": 0.035427, "time_queued": "2026-01-06 22:25:01.476967+00:00", "tasks_existed": 0, "time_completed": "2026-01-06 22:25:01.518136+00:00", "time_last_ping": "2026-01-06 22:25:01.482709+00:00", "time_in_progress": "2026-01-06 22:25:01.482709+00:00"}	completed	\N	t	\N
\.


--
-- TOC entry 5352 (class 0 OID 25778)
-- Dependencies: 292
-- Data for Name: io_storages_s3importstoragelink; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.io_storages_s3importstoragelink (id, key, object_exists, created_at, storage_id, task_id, row_group, row_index) FROM stdin;
\.


--
-- TOC entry 5410 (class 0 OID 27445)
-- Dependencies: 350
-- Data for Name: jwt_auth_jwtsettings; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.jwt_auth_jwtsettings (organization_id, api_tokens_enabled, api_token_ttl_days, legacy_api_tokens_enabled, created_at, updated_at) FROM stdin;
1	t	73000	f	2026-01-06 06:33:34.655762+00	2026-01-06 06:33:34.65781+00
\.


--
-- TOC entry 5412 (class 0 OID 27462)
-- Dependencies: 352
-- Data for Name: labels_manager_label; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.labels_manager_label (id, created_at, updated_at, value, title, description, approved, approved_by_id, created_by_id, organization_id) FROM stdin;
\.


--
-- TOC entry 5414 (class 0 OID 27478)
-- Dependencies: 354
-- Data for Name: labels_manager_labellink; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.labels_manager_labellink (id, from_name, label_id, project_id) FROM stdin;
\.


--
-- TOC entry 5390 (class 0 OID 26970)
-- Dependencies: 330
-- Data for Name: ml_mlbackend; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.ml_mlbackend (id, state, url, error_message, title, description, model_version, created_at, updated_at, project_id, is_interactive, timeout, auto_update, auth_method, basic_auth_pass, basic_auth_user, extra_params) FROM stdin;
\.


--
-- TOC entry 5394 (class 0 OID 26997)
-- Dependencies: 334
-- Data for Name: ml_mlbackendpredictionjob; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.ml_mlbackendpredictionjob (id, job_id, model_version, batch_size, created_at, updated_at, ml_backend_id) FROM stdin;
\.


--
-- TOC entry 5392 (class 0 OID 26984)
-- Dependencies: 332
-- Data for Name: ml_mlbackendtrainjob; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.ml_mlbackendtrainjob (id, job_id, model_version, created_at, updated_at, ml_backend_id) FROM stdin;
\.


--
-- TOC entry 5416 (class 0 OID 27524)
-- Dependencies: 356
-- Data for Name: ml_model_providers_modelproviderconnection; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.ml_model_providers_modelproviderconnection (id, provider, api_key, scope, created_at, updated_at, created_by_id, organization_id, deployment_name, endpoint, cached_available_models, auth_token, budget_alert_threshold, budget_last_reset_date, budget_limit, budget_reset_period, budget_total_spent, is_internal, google_application_credentials, google_location, google_project_id) FROM stdin;
\.


--
-- TOC entry 5382 (class 0 OID 26840)
-- Dependencies: 322
-- Data for Name: ml_models_modelinterface; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.ml_models_modelinterface (id, title, description, created_at, updated_at, created_by_id, organization_id, input_fields, output_classes, skill_name) FROM stdin;
\.


--
-- TOC entry 5388 (class 0 OID 26937)
-- Dependencies: 328
-- Data for Name: ml_mpg_dump: processing data for table "public.ml_models_thirdpartymodelversion"
pg_dump: dumping contents of table "public.ml_models_thirdpartymodelversion"
pg_dump: processing data for table "public.organization"
pg_dump: dumping contents of table "public.organization"
pg_dump: processing data for table "public.organizations_organizationmember"
pg_dump: dumping contents of table "public.organizations_organizationmember"
pg_dump: processing data for table "public.prediction"
pg_dump: dumping contents of table "public.prediction"
pg_dump: processing data for table "public.prediction_meta"
pg_dump: dumping contents of table "public.prediction_meta"
pg_dump: processing data for table "public.project"
pg_dump: dumping contents of table "public.project"
pg_dump: processing data for table "public.projects_labelstreamhistory"
pg_dump: dumping contents of table "public.projects_labelstreamhistory"
odels_modelinterface_associated_projects; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.ml_models_modelinterface_associated_projects (id, modelinterface_id, project_id) FROM stdin;
\.


--
-- TOC entry 5386 (class 0 OID 26898)
-- Dependencies: 326
-- Data for Name: ml_models_modelrun; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.ml_models_modelrun (id, project_subset, status, created_at, triggered_at, completed_at, created_by_id, model_version_id, organization_id, project_id, job_id, predictions_updated_at, total_correct_predictions, total_predictions, total_tasks) FROM stdin;
\.


--
-- TOC entry 5384 (class 0 OID 26852)
-- Dependencies: 324
-- Data for Name: ml_models_thirdpartymodelversion; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.ml_models_thirdpartymodelversion (id, title, prompt, provider, provider_model_id, created_at, updated_at, created_by_id, organization_id, parent_model_id, model_provider_connection_id) FROM stdin;
\.


--
-- TOC entry 5301 (class 0 OID 24966)
-- Dependencies: 241
-- Data for Name: organization; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.organization (id, title, created_at, updated_at, created_by_id, token, contact_info) FROM stdin;
1	Label Studio	2026-01-06 06:33:34.651496+00	2026-01-06 06:33:34.651505+00	1	Codb5RBhztvKjNKtpMN50k1XeolLApvN3fuPTJRU	\N
\.


--
-- TOC entry 5303 (class 0 OID 24980)
-- Dependencies: 243
-- Data for Name: organizations_organizationmember; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.organizations_organizationmember (id, created_at, updated_at, organization_id, user_id, deleted_at) FROM stdin;
1	2026-01-06 06:33:34.652648+00	2026-01-06 06:33:34.652666+00	1	1	\N
\.


--
-- TOC entry 5328 (class 0 OID 25498)
-- Dependencies: 268
-- Data for Name: prediction; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.prediction (id, result, score, model_version, created_at, updated_at, task_id, cluster, neighbors, mislabeling, project_id, model_run_id, model_id) FROM stdin;
\.


--
-- TOC entry 5398 (class 0 OID 27087)
-- Dependencies: 338
-- Data for Name: prediction_meta; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.prediction_meta (id, inference_time, prompt_tokens_count, completion_tokens_count, total_tokens_count, prompt_cost, completion_cost, total_cost, extra, failed_prediction_id, prediction_id) FROM stdin;
\.


--
-- TOC entry 5305 (class 0 OID 25026)
-- Dependencies: 245
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.project (id, title, label_config, expert_instruction, show_instruction, maximum_annotations, model_version, data_types, is_published, created_at, updated_at, created_by_id, show_skip_button, enable_empty_annotation, min_annotations_to_start_training, show_annotation_history, show_collab_predictions, show_ground_truth_first, sampling, task_data_login, task_data_password, overlap_cohort_percentage, show_overlap_first, control_weights, token, result_count, organization_id, is_draft, description, color, evaluate_predictions_automatically, reveal_preannotations_interactively, skip_queue, parsed_label_config, pinned_at, label_config_hash, custom_task_lock_ttl, deleted_at, deleted_by_id, purge_at) FROM stdin;
1	WOPR - Dune - Piece Detection v0.1	<View>\n  <Image name="image" value="$image" zoom="false"/>\n  <RectangleLabels name="label" toName="image">\n    <Label value="mainboard" background="#FF0000"/>\n    <Label value="1_solari" background="#FFD700"/>\n    <Label value="5_solari" background="#FFA500"/>\n    <Label value="1_spice" background="#D2691E"/>\n    <Label value="5_spice" background="#8B4513"/>\n    <Label value="1_water" background="#1E90FF"/>\n    <Label value="blue_troopCube" background="#0000FF"/>\n    <Label value="red_troopCube" background="#FF0000"/>\n    <Label value="green_troopCube" background="#00FF00"/>\n    <Label value="yellow_troopCube" background="#FFFF00"/>\n    <Label value="blue_agentMeeple" background="#4169E1"/>\n    <Label value="red_agentMeeple" background="#DC143C"/>\n    <Label value="green_agentMeeple" background="#32CD32"/>\n    <Label value="yellow_agentMeeple" background="#FFD700"/>\n    <Label value="blue_swordMaster" background="#000080"/>\n    <Label value="red_swordMaster" background="#8B0000"/>\n    <Label value="green_swordMaster" background="#006400"/>\n    <Label value="yellow_swordMaster" background="#DAA520"/>\n    <Label value="blue_combatMarker" background="#4682B4"/>\n    <Label value="red_combatMarker" background="#B22222"/>\n    <Label value="green_combatMarker" background="#228B22"/>\n    <Label value="yellow_combatMarker" background="#F0E68C"/>\n    <Label value="blue_spy" background="#191970"/>\n    <Label value="red_spy" background="#A52A2A"/>\n    <Label value="green_spy" background="#2F4F2F"/>\n    <Label value="yellow_spy" background="#BDB76B"/>\n    <Label value="wood_sandWorm" background="#8B4513"/>\n    <Label value="makerHook" background="#696969"/>\n    <Label value="shieldWall" background="#708090"/>\n    <Label value="firstPlayerToken" background="#FFD700"/>\n    <Label value="emperor_allianceToken" background="#4B0082"/>\n    <Label value="spacingGuild_allianceToken" background="#FF6347"/>\n    <Label value="beneGesserit_allianceToken" background="#9370DB"/>\n    <Label value="freemen_allianceToken" background="#F4A460"/>\n    <Label value="table_marker" background="#808080"/>\n  </RectangleLabels>\n</View>		f	1		{"image": "Image"}	f	2026-01-06 06:33:40.469482+00	2026-01-06 22:54:04.648871+00	1	t	t	0	f	t	f	Sequential sampling	\N	\N	100	f	{"label": {"type": "RectangleLabels", "labels": {"1_spice": 1.0, "1_water": 1.0, "5_spice": 1.0, "red_spy": 1.0, "1_solari": 1.0, "5_solari": 1.0, "blue_spy": 1.0, "green_spy": 1.0, "mainboard": 1.0, "makerHook": 1.0, "shieldWall": 1.0, "yellow_spy": 1.0, "table_marker": 1.0, "red_troopCube": 1.0, "wood_sandWorm": 1.0, "blue_troopCube": 1.0, "green_troopCube": 1.0, "red_agentMeeple": 1.0, "red_swordMaster": 1.0, "blue_agentMeeple": 1.0, "blue_swordMaster": 1.0, "firstPlayerToken": 1.0, "red_combatMarker": 1.0, "yellow_troopCube": 1.0, "blue_combatMarker": 1.0, "green_agentMeeple": 1.0, "green_swordMaster": 1.0, "green_combatMarker": 1.0, "yellow_agentMeeple": 1.0, "yellow_swordMaster": 1.0, "yellow_combatMarker": 1.0, "emperor_allianceToken": 1.0, "freemen_allianceToken": 1.0, "beneGesserit_allianceToken": 1.0, "spacingGuild_allianceToken": 1.0}, "overall": 1.0}}	STD52sg8PX8nT4wthsEo4zaz5h61lbooKkyHWN0q	0	1	f	The piece detection for WOPR - Dune Imperium Uprising edition.	#FFFFFF	f	f	REQUEUE_FOR_OTHERS	{"label": {"type": "RectangleLabels", "inputs": [{"type": "Image", "value": "image", "valueType": null}], "labels": ["mainboard", "1_solari", "5_solari", "1_spice", "5_spice", "1_water", "blue_troopCube", "red_troopCube", "green_troopCube", "yellow_troopCube", "blue_agentMeeple", "red_agentMeeple", "green_agentMeeple", "yellow_agentMeeple", "blue_swordMaster", "red_swordMaster", "green_swordMaster", "yellow_swordMaster", "blue_combatMarker", "red_combatMarker", "green_combatMarker", "yellow_combatMarker", "blue_spy", "red_spy", "green_spy", "yellow_spy", "wood_sandWorm", "makerHook", "shieldWall", "firstPlayerToken", "emperor_allianceToken", "spacingGuild_allianceToken", "beneGesserit_allianceToken", "freemen_allianceToken", "table_marker"], "to_name": ["image"], "labels_attrs": {"1_spice": {"value": "1_spice", "background": "#D2691E"}, "1_water": {"value": "1_water", "background": "#1E90FF"}, "5_spice": {"value": "5_spice", "background": "#8B4513"}, "red_spy": {"value": "red_spy", "background": "#A52A2A"}, "1_solari": {"value": "1_solari", "background": "#FFD700"}, "5_solari": {"value": "5_solari", "background": "#FFA500"}, "blue_spy": {"value": "blue_spy", "background": "#191970"}, "green_spy": {"value": "green_spy", "background": "#2F4F2F"}, "mainboard": {"value": "mainboard", "background": "#FF0000"}, "makerHook": {"value": "makerHook", "background": "#6969pg_dump: processing data for table "public.projects_projectimport"
pg_dump: dumping contents of table "public.projects_projectimport"
pg_dump: processing data for table "public.projects_projectmember"
pg_dump: dumping contents of table "public.projects_projectmember"
pg_dump: processing data for table "public.projects_projectonboarding"
pg_dump: dumping contents of table "public.projects_projectonboarding"
pg_dump:69"}, "shieldWall": {"value": "shieldWall", "background": "#708090"}, "yellow_spy": {"value": "yellow_spy", "background": "#BDB76B"}, "table_marker": {"value": "table_marker", "background": "#808080"}, "red_troopCube": {"value": "red_troopCube", "background": "#FF0000"}, "wood_sandWorm": {"value": "wood_sandWorm", "background": "#8B4513"}, "blue_troopCube": {"value": "blue_troopCube", "background": "#0000FF"}, "green_troopCube": {"value": "green_troopCube", "background": "#00FF00"}, "red_agentMeeple": {"value": "red_agentMeeple", "background": "#DC143C"}, "red_swordMaster": {"value": "red_swordMaster", "background": "#8B0000"}, "blue_agentMeeple": {"value": "blue_agentMeeple", "background": "#4169E1"}, "blue_swordMaster": {"value": "blue_swordMaster", "background": "#000080"}, "firstPlayerToken": {"value": "firstPlayerToken", "background": "#FFD700"}, "red_combatMarker": {"value": "red_combatMarker", "background": "#B22222"}, "yellow_troopCube": {"value": "yellow_troopCube", "background": "#FFFF00"}, "blue_combatMarker": {"value": "blue_combatMarker", "background": "#4682B4"}, "green_agentMeeple": {"value": "green_agentMeeple", "background": "#32CD32"}, "green_swordMaster": {"value": "green_swordMaster", "background": "#006400"}, "green_combatMarker": {"value": "green_combatMarker", "background": "#228B22"}, "yellow_agentMeeple": {"value": "yellow_agentMeeple", "background": "#FFD700"}, "yellow_swordMaster": {"value": "yellow_swordMaster", "background": "#DAA520"}, "yellow_combatMarker": {"value": "yellow_combatMarker", "background": "#F0E68C"}, "emperor_allianceToken": {"value": "emperor_allianceToken", "background": "#4B0082"}, "freemen_allianceToken": {"value": "freemen_allianceToken", "background": "#F4A460"}, "beneGesserit_allianceToken": {"value": "beneGesserit_allianceToken", "background": "#9370DB"}, "spacingGuild_allianceToken": {"value": "spacingGuild_allianceToken", "background": "#FF6347"}}}}	\N	6403845639796841579	\N	\N	\N	\N
\.


--
-- TOC entry 5318 (class 0 OID 25367)
-- Dependencies: 258
-- Data for Name: projects_labelstreamhistory; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.projects_labelstreamhistory (id, data, project_id, user_id) FROM stdin;
1	[{"taskId": 6, "annotationId": 6}, {"taskId": 7, "annotationId": 7}, {"taskId": 8, "annotationId": 8}, {"taskId": 9, "annotationId": 9}, {"taskId": 10, "annotationId": 10}, {"taskId": 11, "annotationId": 11}, {"taskId": 12, "annotationId": 12}, {"taskId": 13, "annotationId": 13}, {"taskId": 14, "annotationId": 14}, {"taskId": 15, "annotationId": 15}]	1	1
\.


--
-- TOC entry 5378 (class 0 OID 26777)
-- Dependencies: 318
-- Data for Name: projects_projectimport; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.projects_projectimport (id, preannotated_from_fields, commit_to_project, return_task_ids, status, url, traceback, error, created_at, updated_at, finished_at, task_count, annotation_count, prediction_count, duration, file_upload_ids, could_be_tasks_list, found_formats, data_columns, tasks, task_ids, project_id) FROM stdin;
\.


--
-- TOC entry 5311 (class 0 OID 25246)
-- Dependencies: 251
-- Data for Name: projects_projectmember; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.projects_projectmember (id, enabled, created_at, updated_at, project_id, user_id) FROM stdin;
\.


--
-- TOC entry 5309 (class 0 OID 25102)
-- Dependencies: 249
-- Data for Name: projects_projectonboarding; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.projects_projectonboarding (id, finished, created_at, updated_at, project_id, step_id) FROM stdin;
\.


--
-- TOC entry 5307 (class 0 OID 25044)
-- Dependencies: 247
-- Data for Name: projects_projectonboardingsteps; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.projects_projectonboardingsteps (id, code, title, description, "order", created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5380 (class 0 OID 26804)
-- Dependencies: 320
-- Data for Name: projects_ processing data for table "public.projects_projectonboardingsteps"
pg_dump: dumping contents of table "public.projects_projectonboardingsteps"
pg_dump: processing data for table "public.projects_projectreimport"
pg_dump: dumping contents of table "public.projects_projectreimport"
pg_dump: processing data for table "public.projects_projectsummary"
pg_dump: dumping contents of table "public.projects_projectsummary"
pg_dump: processing data for table "public.session_policy_sessiontimeoutpolicy"
pg_dump: dumping contents of table "public.session_policy_sessiontimeoutpolicy"
pg_dump: processing data for table "public.task"
pg_dump: dumping contents of table "public.task"
pg_dump: processing data for table "public.task_comment_authors"
pg_dump: dumping contents of table "public.task_comment_authors"
pg_dump: processing data for table "public.task_completion"
pg_dump: dumping contents of table "public.task_completion"
projectreimport; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.projects_projectreimport (id, status, error, task_count, annotation_count, prediction_count, duration, file_upload_ids, files_as_tasks_list, found_formats, data_columns, traceback, project_id) FROM stdin;
\.


--
-- TOC entry 5312 (class 0 OID 25288)
-- Dependencies: 252
-- Data for Name: projects_projectsummary; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.projects_projectsummary (project_id, created_at, all_data_columns, common_data_columns, created_annotations, created_labels, created_labels_drafts) FROM stdin;
1	2026-01-06 06:33:40.483761+00	{"image": 29, "$undefined$": 31}	[]	{"label|image|rectanglelabels": 99}	{"label": {"mainboard": 28, "table_marker": 39, "yellow_agentMeeple": 26}}	{}
\.


--
-- TOC entry 5417 (class 0 OID 27563)
-- Dependencies: 357
-- Data for Name: session_policy_sessiontimeoutpolicy; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.session_policy_sessiontimeoutpolicy (organization_id, max_session_age, max_time_between_activity, created_at, updated_at) FROM stdin;
1	11520	4320	2026-01-06 06:33:34.720988+00	2026-01-06 06:33:34.721019+00
\.


--
-- TOC entry 5326 (class 0 OID 25485)
-- Dependencies: 266
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.task (id, data, created_at, updated_at, is_labeled, project_id, meta, overlap, file_upload_id, updated_by_id, inner_id, total_annotations, cancelled_annotations, total_predictions, comment_count, last_comment_updated_at, unresolved_comment_count, precomputed_agreement, allow_skip) FROM stdin;
2	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-1156042f-713d-471b-82bf-b9ff670e8b5d.jpg"}	2026-01-06 22:30:38.948891+00	2026-01-06 22:57:36.061414+00	t	1	{}	1	\N	1	2	1	0	0	0	\N	0	\N	t
3	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-138922bb-4039-4418-a0d2-60599b7a5831.jpg"}	2026-01-06 22:30:38.960351+00	2026-01-06 23:10:28.514195+00	t	1	{}	1	\N	1	3	1	0	0	0	\N	0	\N	t
4	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-2c5a5b3b-3edc-4a63-97bf-a8ca611e6359.jpg"}	2026-01-06 22:30:38.973773+00	2026-01-06 23:11:03.497383+00	t	1	{}	1	\N	1	4	1	0	0	0	\N	0	\N	t
5	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-352d8816-1adb-44e6-8d30-f00bf1e7c692.jpg"}	2026-01-06 22:30:38.987568+00	2026-01-06 23:11:32.218876+00	t	1	{}	1	\N	1	5	1	0	0	0	\N	0	\N	t
6	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-3e11cf06-0251-47dd-8df1-f5fbbcdd3939.jpg"}	2026-01-06 22:30:39.000553+00	2026-01-06 23:12:24.278001+00	t	1	{}	1	\N	1	6	1	0	0	0	\N	0	\N	t
7	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-429c948e-1446-4c6c-823b-f53af50ac9b6.jpg"}	2026-01-06 22:30:39.013053+00	2026-01-06 23:14:07.871358+00	t	1	{}	1	\N	1	7	1	0	0	0	\N	0	\N	t
8	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-4782053a-a4ca-4cc1-8d83-8d79017864be.jpg"}	2026-01-06 22:30:39.025661+00	2026-01-06 23:14:38.344047+00	t	1	{}	1	\N	1	8	1	0	0	0	\N	0	\N	t
9	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-49d7b98a-e5fa-4507-bde4-7a7c4ac78fb9.jpg"}	2026-01-06 22:30:39.040593+00	2026-01-06 23:15:04.691607+00	t	1	{}	1	\N	1	9	1	0	0	0	\N	0	\N	t
10	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-4eb32dd4-4d36-44c2-930a-5e985ba18ba3.jpg"}	2026-01-06 22:30:39.053105+00	2026-01-06 23:15:56.350639+00	t	1	{}	1	\N	1	10	1	0	0	0	\N	0	\N	t
11	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-502c252b-425a-4512-96aa-19ca4be391d4.jpg"}	2026-01-06 22:30:39.066921+00	2026-01-06 23:16:06.561819+00	t	1	{}	1	\N	1	11	1	0	0	0	\N	0	\N	t
12	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-5337b2bd-8a71-46a4-b053-59742ea6bca3.jpg"}	2026-01-06 22:30:39.080063+00	2026-01-06 23:16:16.478138+00	t	1	{}	1	\N	1	12	1	0	0	0	\N	0	\N	t
13	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-58d50d89-0d8d-4e5c-978d-aac2fc45841d.jpg"}	2026-01-06 22:30:39.092112+00	2026-01-06 23:16:44.934766+00	t	1	{}	1	\N	1	13	1	0	0	0	\N	0	\N	t
14	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-64cb597f-639a-4b30-86a3-ceb190c00074.jpg"}	2026-01-06 22:30:39.104147+00	2026-01-06 23:16:54.397299+00	t	1	{}	1	\N	1	14	1	0	0	0	\N	0	\N	t
15	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-72ed6794-3aef-4d1b-bc1d-e041d79a6898.jpg"}	2026-01-06 22:30:39.116138+00	2026-01-06 23:27:55.260398+00	t	1	{}	1	\N	1	15	1	0	0	0	\N	0	\N	t
16	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-7944784e-bdf5-4182-8acc-9b9a229b89e5.jpg"}	2026-01-06 22:30:39.128453+00	2026-01-06 23:28:06.646435+00	t	1	{}	1	\N	1	16	1	0	0	0	\N	0	\N	t
17	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-7d73aee6-da44-4cc3-8859-68d3dfc1936c.jpg"}	2026-01-06 22:30:39.14069+00	2026-01-06 23:28:17.17534+00	t	1	{}	1	\N	1	17	1	0	0	0	\N	0	\N	t
18	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-86731d17-875d-41b6-a9aa-fd3963e04013.jpg"}	2026-01-06 22:30:39.153302+00	2026-01-06 23:28:26.537515+00	t	1	{}	1	\N	1	18	1	0	0	0	\N	0	\N	t
19	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-88f00ad9-cf00-422b-bac8-a3b1eab78782.jpg"}	2026-01-06 22:30:39.165602+00	2026-01-06 23:28:36.226294+00	t	1	{}	1	\N	1	19	1	0	0	0	\N	0	\N	t
20	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-8b91290f-fe26-4029-82ea-826b691e445b.jpg"}	2026-01-06 22:30:39.177705+00	2026-01-06 23:28:46.587161+00	t	1	{}	1	\N	1	20	1	0	0	0	\N	0	\N	t
21	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-a5188272-78e3-46e8-b888-c4ae1bb66abc.jpg"}	2026-01-06 22:30:39.190966+00	2026-01-06 23:29:10.133894+00	t	1	{}	1	\N	1	21	1	0	0	0	\N	0	\N	t
23	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-cce57477-652d-4607-9f75-57d37ce23819.jpg"}	2026-01-06 22:30:39.214957+00	2026-01-06 23:29:28.486376+00	t	1	{}	1	\N	1	23	1	0	0	0	\N	0	\N	t
24	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-cfff75f1-b31a-4b32-9844-65227345c259.jpg"}	2026-01-06 22:30:39.226742+00	2026-01-06 23:29:39.045709+00	t	1	{}	1	\N	1	24	1	0	0	0	\N	0	\N	t
25	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-d055a31b-8127-4b9d-a525-0d096a755e80.jpg"}	2026-01-06 22:30:39.238101+00	2026-01-06 23:29:49.181368+00	t	1	{}	1	\N	1	25	1	0	0	0	\N	0	\N	t
26	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-d11f1f02-f198-44b7-9c06-cfd06f4634d8.jpg"}	2026-01-06 22:30:39.250691+00	2026-01-06 23:29:57.93933+00	t	1	{}	1	\N	1	26	1	0	0	0	\N	0	\N	t
27	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-d9acd417-c548-4b3c-9c16-f84f364d9cb9.jpg"}	2026-01-06 22:30:39.262517+00	2026-01-06 23:30:06.721579+00	t	1	{}	1	\N	1	27	1	0	0	0	\N	0	\N	t
28	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-de0748da-acd4-4831-9c2e-90fb08dfa314.jpg"}	2026-01-06 22:30:39.274489+00	2026-01-06 23:30:14.663454+00	t	1	{}	1	\N	1	28	1	0	0	0	\N	0	\N	t
29	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-e41381c8-4de9-4bf8-a423-87080f2ccb7e.jpg"}	2026-01-06 22:30:39.286344+00	2026-01-06 23:30:23.085692+00	t	1	{}	1	\N	1	29	1	0	0	0	\N	0	\N	t
30	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-ff526d40-0dc1-4928-9cec-32c7c029ad0d.jpg"}	2026-01-06 22:30:39.297607+00	2026-01-06 22:30:39.297617+00	f	1	{}	1	\N	\N	30	0	0	0	0	\N	0	\N	t
1	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-082b0b5c-c2d4-4d23-8f80-76570bd292e3.jpg"}	2026-01-06 22:30:38.932421+00	2026-01-06 22:56:49.902962+00	t	1	{}	1	\N	1	1	1	0	0	0	\N	0	\N	t
22	{"$undefined$": "https://labelstudio.wopr.tailandtraillabs.org/data/local-files/?d=labelstudio/source/15-4-cb263722-f788-414a-a57c-acfbf5f32f39.jpg"}	2026-01-06 22:30:39.202467+00	2026-01-06 23:29:19.384664+00	t	1	{}	1	\N	1	22	1	0	0	0	\N	0	\N	t
\.


--
-- TOC entry 5376 (class 0 OID 26287)
-- Dependencies: 316
-- Data for Name: task_comment_authors; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.task_comment_authors (id, task_id, user_id) FROM stdin;
\.


--
-- TOC entry 5330 (class 0 OID 25511)
-- Dependencies: 270
-- Data for Name: task_completion; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.task_completion (id, result, was_cancelled, ground_truth, created_at, updated_at, task_id, prediction, lead_time, result_count, completed_by_id, parent_prediction_id, parent_annotation_id, last_action, last_created_by_id, project_id, updated_by_id, unique_id, draft_created_at, import_id, bulk_created) FROM stdin;
1	[{"id": "KJOGY23Fij", "type": "rectanglelabels", "value": {"x": 56.71874999999999, "y": 23.88888888888889, "width": 24.843750000000007, "height": 43.05555555555556, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "L3W7S0_gzi", "type": "rectanglelabels", "value": {"x": 45.625, "y": 45.55555555555556, "width": 7.34375, "height": 13.888888888888886, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "pcILRTqevm", "type": "rectanglelabels", "value": {"x": 87.8125, "y": 86.11111111111111, "width": 7.03125, "height": 13.333333333333329, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "GF0ElfYlvP", "type": "rectanglelabels", "value": {"x": 87.1875, "y": 0.8333333333333334, "width": 6.71875, "height": 12.5, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "lk6-_oB5gm", "type": "rectanglelabels", "value": {"x": 7.03125, "y": 0.2777777777777778, "width": 6.25, "height": 12.222222222222221, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "5qXqfi_kQk", "type": "rectanglelabels", "value": {"x": 2.8125, "y": 89.72222222222223, "width": 6.5625, "height": 10, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "5J3BNFsbcq", "type": "rectanglelabels", "value": {"x": 42.75453629032258, "y": 53.0241935483871, "width": 1.0206653225806477, "height": 2.016129032258057, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 22:56:49.666917+00	2026-01-06 22:56:49.66693+00	1	{}	123.263	7	1	\N	\N	\N	\N	1	1	610d79e0-e37b-439e-85d0-a7db94bad5c5	2026-01-06 22:55:13.168367+00	\N	f
2	[{"id": "yOIimq5jrg", "type": "rectanglelabels", "value": {"x": 56.36340725806451, "y": 22.379032258064516, "width": 26.65070564516128, "height": 45.766129032258064, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "89ZIJjQZDq", "type": "rectanglelabels", "value": {"x": 45.92993951612903, "y": 47.17741935483871, "width": 6.691028225806441, "height": 10.887096774193552, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "Zu91uXvPUr", "type": "rectanglelabels", "value": {"x": 87.55040322580645, "y": 0.4032258064516129, "width": 6.464213709677409, "height": 12.298387096774194, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "YavQ-WH4mN", "type": "rectanglelabels", "value": {"x": 88.45766129032258, "y": 86.08870967741935, "width": 6.577620967741936, "height": 12.701612903225822, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "rgKqD6xUF5", "type": "rectanglelabels", "value": {"x": 3.061995967741935, "y": 90.12096774193549, "width": 6.237399193548387, "height": 9.274193548387089, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "UtnqWw4-Wx", "type": "rectanglelabels", "value": {"x": 7.825100806451612, "y": 1.411290322580645, "width": 5.216733870967742, "height": 10.483870967741936, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "KSi5ot_I9V", "type": "rectanglelabels", "value": {"x": 42.30090725806451, "y": 54.233870967741936, "width": 1.8145161290322562, "height": 1.6129032258064484, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 22:57:35.818029+00	2026-01-06 22:57:35.818039+00	2	{}	38.435	7	1	\N	\N	\N	\N	1	1	36c82b8b-c579-4f48-941f-26d17eccb827	2026-01-06 22:57:11.512577+00	\N	f
3	[{"id": "12LaEq25pQ", "type": "rectanglelabels", "value": {"x": 88.23084677419354, "y": 85.88709677419355, "width": 7.144657258064527, "height": 13.306451612903217, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "LVGUZ_QhuT", "type": "rectanglelabels", "value": {"x": 88.00403225806451, "y": 1.6129032258064515, "width": 5.670362903225808, "height": 9.274193548387096, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "cQe3LGqy_4", "type": "rectanglelabels", "value": {"x": 46.156754032258064, "y": 46.774193548387096, "width": 6.464213709677409, "height": 11.088709677419352, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "OP8mZ6Ngt7", "type": "rectanglelabels", "value": {"x": 3.061995967741935, "y": 89.71774193548387, "width": 6.123991935483871, "height": 9.677419354838705, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "kBcnsFnPrb", "type": "rectanglelabels", "value": {"x": 7.144657258064516, "y": 1.2096774193548387, "width": 6.010584677419352, "height": 10.685483870967744, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "J42aoGhzpw", "type": "rectanglelabels", "value": {"x": 56.59022177419355, "y": 21.975806451612904, "width": 28.124999999999986, "height": 48.387096774193544, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:09:58.733865+00	2026-01-06 23:10:28.405226+00	3	{}	44.001000000000005	6	1	\N	\N	\N	\N	1	1	48163599-6184-4ba6-b4ff-51b339558490	2026-01-06 23:09:58.378351+00	\N	f
4	[{"id": "Dm6_fdXojk", "type": "rectanglelabels", "value": {"x": 56.13659274193547, "y": 22.983870967741936, "width": 25.630040322580655, "height": 44.95967741935483, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "DxKcty1Qzf", "type": "rectanglelabels", "value": {"x": 88.34425403225806, "y": 85.68548387096774, "width": 6.691028225806448, "height": 12.096774193548384, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "kAzx8qRXkA", "type": "rectanglelabels", "value": {"x": 42.75453629032258, "y": 52.62096774193549, "width": 1.5877016129032313, "height": 2.6209677419354733, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "x7xti6xQxQ", "type": "rectanglelabels", "value": {"x": 46.156754032258064, "y": 46.57258064516129, "width": 6.010584677419352, "height": 10.887096774193552, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "QZkPZCc1BI", "type": "rectanglelabels", "value": {"x": 3.288810483870967, "y": 88.91129032258065, "width": 6.010584677419355, "height": 10.887096774193537, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "gGH6dQ6h_Y", "type": "rectanglelabels", "value": {"x": 7.03125, "y": 0.6048387096774194, "width": 6.123991935483868, "height": 12.096774193548386, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:11:03.256844+00	2026-01-06 23:11:03.256859+00	4	{}	30.368	6	1	\N	\N	\N	\N	1	1	7147d8ab-de51-48c3-9295-7af7e5a1386c	2026-01-06 23:10:44.315573+00	\N	f
5	[{"id": "A0AjAgO6rm", "type": "rectanglelabels", "value": {"x": 56.13659274193547, "y": 22.983870967741936, "width": 25.970262096774206, "height": 44.55645161290323, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "ptxdAQEdTt", "type": "rectanglelabels", "value": {"x": 88.23084677419354, "y": 85.88709677419355, "width": 6.577620967741936, "height": 12.903225806451616, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "WMSKtpw2ad", "type": "rectanglelabels", "value": {"x": 87.43699596774192, "y": 0.4032258064516129, "width": 6.010584677419359, "height": 11.49193548387097, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manpg_dump: processing data for table "public.tasks_annotationdraft"
pg_dump: dumping contents of table "public.tasks_annotationdraft"
ual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "7HqCokZ-CN", "type": "rectanglelabels", "value": {"x": 2.721774193548387, "y": 89.71774193548387, "width": 6.464213709677419, "height": 9.475806451612897, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "9EvFkOZsYn", "type": "rectanglelabels", "value": {"x": 7.711693548387097, "y": 1.411290322580645, "width": 4.876512096774193, "height": 9.274193548387096, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "ivP4KD6W3i", "type": "rectanglelabels", "value": {"x": 45.81653225806451, "y": 45.766129032258064, "width": 6.577620967741936, "height": 12.5, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:11:31.99099+00	2026-01-06 23:11:31.991001+00	5	{}	26.736	6	1	\N	\N	\N	\N	1	1	c1a13010-2e51-437d-b5a0-d4ab609865a7	2026-01-06 23:11:15.130252+00	\N	f
6	[{"id": "y_kgvOykbh", "type": "rectanglelabels", "value": {"x": 56.094398340248965, "y": 22.68326417704011, "width": 25.907676348547717, "height": 44.39834024896264, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "pDSfAZD85V", "type": "rectanglelabels", "value": {"x": 88.07053941908714, "y": 86.44536652835409, "width": 7.235477178423238, "height": 12.171507607192254, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "OupVEAiVFi", "type": "rectanglelabels", "value": {"x": 45.90248962655602, "y": 46.47302904564315, "width": 6.613070539419084, "height": 11.618257261410797, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "HysSfj_eKw", "type": "rectanglelabels", "value": {"x": 3.112033195020747, "y": 90.17980636237898, "width": 5.8350622406639, "height": 9.266943291839553, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "j_88qX1sI6", "type": "rectanglelabels", "value": {"x": 87.99273858921163, "y": 1.3831258644536653, "width": 5.290456431535262, "height": 10.096818810511756, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "XyPBYamoDd", "type": "rectanglelabels", "value": {"x": 7.330246913580248, "y": 1.3717421124828533, "width": 5.401234567901235, "height": 10.699588477366255, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "w8J4b_eZcf", "type": "rectanglelabels", "value": {"x": 42.66975308641975, "y": 52.94924554183813, "width": 1.1574074074074048, "height": 2.194787379972574, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:12:24.188153+00	2026-01-06 23:12:24.188166+00	6	{}	40.73	7	1	\N	\N	\N	\N	1	1	a29319fb-b3c9-4ab9-8dc0-1a65bc275827	2026-01-06 23:11:56.003698+00	\N	f
7	[{"id": "ixtO05KGrX", "type": "rectanglelabels", "value": {"x": 56.09567901234568, "y": 22.90809327846365, "width": 25.69444444444445, "height": 44.718792866941016, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "5F6SAsG8j5", "type": "rectanglelabels", "value": {"x": 88.11728395061729, "y": 86.28257887517147, "width": 6.790123456790113, "height": 12.345679012345684, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "2W-aPbKr38", "type": "rectanglelabels", "value": {"x": 87.42283950617285, "y": 0.5486968449931412, "width": 5.864197530864189, "height": 10.83676268861454, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "-rwVbPCmLe", "type": "rectanglelabels", "value": {"x": 46.21913580246913, "y": 46.63923182441701, "width": 6.095679012345684, "height": 10.699588477366255, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "wSzvS0c1G_", "type": "rectanglelabels", "value": {"x": 7.253086419753087, "y": 0.1371742112482853, "width": 5.478395061728396, "height": 12.208504801097394, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "KEmLGfFShd", "type": "rectanglelabels", "value": {"x": 3.2407407407407405, "y": 89.98628257887518, "width": 5.632716049382717, "height": 9.053497942386826, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "TAlAc4PONa", "type": "rectanglelabels", "value": {"x": 42.66975308641975, "y": 52.81207133058985, "width": 1.2345679012345698, "height": 2.0576131687242807, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:14:07.787101+00	2026-01-06 23:14:07.787114+00	7	{}	102.959	7	1	\N	\N	\N	\N	1	1	a981ee62-b87a-449d-9325-e0e6b47da574	2026-01-06 23:13:47.098075+00	\N	f
8	[{"id": "Iw3Jwp6OYl", "type": "rectanglelabels", "value": {"x": 56.018518518518526, "y": 22.90809327846365, "width": 26.080246913580233, "height": 44.855967078189295, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "J6ueVKPgZG", "type": "rectanglelabels", "value": {"x": 88.42592592592592, "y": 86.55692729766804, "width": 6.481481481481481, "height": 12.071330589849111, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "4d9p9ZUBmd", "type": "rectanglelabels", "value": {"x": 87.73148148148148, "y": 1.3717421124828533, "width": 5.478395061728392, "height": 9.876543209876544, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "ULYA5nMdpB", "type": "rectanglelabels", "value": {"x": 3.1635802469135803, "y": 89.16323731138546, "width": 6.018518518518519, "height": 10.288065843621396, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "iuUkL5uiMd", "type": "rectanglelabels", "value": {"x": 7.638888888888889, "y": 0.6858710562414266, "width": 5.0925925925925934, "height": 11.248285322359397, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "KsxL01TRgl", "type": "rectanglelabels", "value": {"x": 46.141975308641975, "y": 47.05075445816186, "width": 6.635802469135804, "height": 11.111111111111114, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "0rG13TtFee", "type": "rectanglelabels", "value": {"x": 42.74691358024691, "y": 53.086419753086425, "width": 1.1574074074074119, "height": 1.371742112482849, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:14:38.096852+00	2026-01-06 23:14:38.096864+00	8	{}	29.689	7	1	\N	\N	\N	\N	1	1	8623ad0d-c2aa-4064-b366-fe321709e5da	2026-01-06 23:14:19.772815+00	\N	f
9	[{"id": "SVcl-SmiMU", "type": "rectanglelabels", "value": {"x": 55.47839506172839, "y": 22.90809327846365, "width": 26.69753086419753, "height": 44.44444444444444, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "la-ir318yS", "type": "rectanglelabels", "value": {"x": 88.27160493827161, "y": 86.69410150891632, "width": 6.867283950617278, "height": 11.522633744855966, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "faZJOb6MVV", "type": "rectanglelabels", "value": {"x": 87.34567901234568, "y": 0.5486968449931412, "width": 6.404320987654316, "height": 10.699588477366255, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "DKiQQQkbce", "type": "rectanglelabels", "value": {"x": 46.06481481481482, "y": 45.953360768175585, "width": 6.635802469135797, "height": 12.071330589849111, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "_r8w4x5hNd", "type": "rectanglelabels", "value": {"x": 3.1635802469135803, "y": 89.30041152263375, "width": 5.864197530864196, "height": 10.425240054869676, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "gSTePjoNnl", "type": "rectanglelabels", "value": {"x": 7.4074074074074066, "y": 0.9602194787379973, "width": 5.709876543209877, "height": 10.973936899862826, "rotation": 0, "rectanglelabels": ["table_marker"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "2tHOyGHf0U", "type": "rectanglelabels", "value": {"x": 42.824074074074076, "y": 52.81207133058985, "width": 1.1574074074074048, "height": 2.0576131687242807, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:15:04.608088+00	2026-01-06 23:15:04.6081+00	9	{}	25.806	7	1	\N	\N	\N	\N	1	1	ff43946e-e723-4a38-b94d-c82bcfe85d28	2026-01-06 23:14:48.39335+00	\N	f
10	[{"id": "1hBhU01zyc", "type": "rectanglelabels", "value": {"x": 56.17283950617284, "y": 23.045267489711936, "width": 25.925925925925917, "height": 44.44444444444446, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "dm4CPpuR0c", "type": "rectanglelabels", "value": {"x": 42.51543209876543, "y": 52.94924554183813, "width": 1.5432098765432158, "height": 1.783264746227708, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:15:56.263021+00	2026-01-06 23:15:56.263036+00	10	{}	51.104	2	1	\N	\N	\N	\N	1	1	aa2570a9-f968-48fa-acc3-1dd148c2dc54	2026-01-06 23:15:49.737044+00	\N	f
11	[{"id": "Ey-U6fI_P7", "type": "rectanglelabels", "value": {"x": 56.018518518518526, "y": 23.045267489711936, "width": 26.157407407407398, "height": 44.85596707818931, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "YxWlkt6ZjT", "type": "rectanglelabels", "value": {"x": 42.36111111111111, "y": 52.81207133058985, "width": 1.5432098765432158, "height": 2.0576131687242807, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:16:06.476621+00	2026-01-06 23:16:06.476632+00	11	{}	9.598	2	1	\N	\N	\N	\N	1	1	d0005280-06b1-4f34-a7bf-823b02f463e9	\N	\N	f
12	[{"id": "iEGr6Dva7z", "type": "rectanglelabels", "value": {"x": 56.09567901234568, "y": 22.22222222222222, "width": 26.00308641975308, "height": 45.130315500685874, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "WEMnz5OBtm", "type": "rectanglelabels", "value": {"x": 42.592592592592595, "y": 52.81207133058985, "width": 1.3888888888888857, "height": 1.9204389574759873, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:16:16.395961+00	2026-01-06 23:16:16.395971+00	12	{}	9.323	2	1	\N	\N	\N	\N	1	1	834c2ac6-6c98-43cf-a482-253594a6d9af	\N	\N	f
13	[{"id": "8KpjaSm2Co", "type": "rectanglelabels", "value": {"x": 56.09567901234568, "y": 23.045267489711936, "width": 26.157407407407412, "height": 44.581618655692736, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "yg38_ncKa5", "type": "rectanglelabels", "value": {"x": 42.74691358024691, "y": 53.086419753086425, "width": 1.0802469135802468, "height": 1.9204389574759873, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:16:44.852574+00	2026-01-06 23:16:44.852588+00	13	{}	27.945	2	1	\N	\N	\N	\N	1	1	d4ca9c9b-ab8e-4986-9e8d-ee32a46570de	\N	\N	f
14	[{"id": "GJ9l1IcyHq", "type": "rectanglelabels", "value": {"x": 56.17283950617284, "y": 22.90809327846365, "width": 25.69444444444445, "height": 44.718792866941016, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "u0xuc6wmEL", "type": "rectanglelabels", "value": {"x": 42.592592592592595, "y": 51.98902606310014, "width": 1.2345679012345627, "height": 2.8806584362139915, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:16:54.285876+00	2026-01-06 23:16:54.285889+00	14	{}	8.837	2	1	\N	\N	\N	\N	1	1	ac9c91bc-a48c-4e4b-8802-b958aadeec83	\N	\N	f
15	[{"id": "QqZm_uzSVp", "type": "rectanglelabels", "value": {"x": 55.90977822580645, "y": 22.782258064516128, "width": 26.310483870967744, "height": 44.75806451612904, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "dNXy0lHtaH", "type": "rectanglelabels", "value": {"x": 42.41431451612903, "y": 51.81451612903226, "width": 1.5877016129032242, "height": 3.4274193548386975, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:27:55.176107+00	2026-01-06 23:27:55.17612+00	15	{}	15.542	2	1	\N	\N	\N	\N	1	1	a53c7a45-52b9-4e46-9c08-a0d46fcc704d	2026-01-06 23:27:52.827947+00	\N	f
16	[{"id": "ubjEVrefF5", "type": "rectanglelabels", "value": {"x": 56.02318548387096, "y": 23.18548387096774, "width": 26.310483870967744, "height": 44.55645161290322, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "xGlQVcxZU_", "type": "rectanglelabels", "value": {"x": 42.41431451612903, "y": 52.41935483870967, "width": 1.9279233870967758, "height": 3.024193548387103, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:28:06.421005+00	2026-01-06 23:28:06.421016+00	16	{}	8.97	2	1	\N	\N	\N	\N	1	1	3df50763-b749-4798-bc96-f88b69c95a74	\N	\N	f
17	[{"id": "Jf8jqqEeJj", "type": "rectanglelabels", "value": {"x": 42.41431451612903, "y": 52.41935483870967, "width": 1.5877016129032242, "height": 2.6209677419354875, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "unR6_W1Ydz", "type": "rectanglelabels", "value": {"x": 55.5695564516129, "y": 22.983870967741936, "width": 26.877520161290334, "height": 45.564516129032256, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:28:17.084983+00	2026-01-06 23:28:17.084998+00	17	{}	8.699	2	1	\N	\N	\N	\N	1	1	feea3cf3-a4ea-4915-9ca5-68fd27f2717e	\N	\N	f
18	[{"id": "k6fDNLEZRj", "type": "rectanglelabels", "value": {"x": 42.41431451612903, "y": 52.41935483870967, "width": 1.3608870967741922, "height": 2.8225806451612883, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "ntA14ETmBo", "type": "rectanglelabels", "value": {"x": 55.682963709677416, "y": 23.18548387096774, "width": 26.877520161290327, "height": 44.758064516129025, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:28:26.457026+00	2026-01-06 23:28:26.457036+00	18	{}	7.5	2	1	\N	\N	\N	\N	1	1	7535d6e9-1ece-4512-99db-4c0d8314b083	\N	\N	f
19	[{"id": "z76eb3X2p4", "type": "rectanglelabels", "value": {"x": 55.90977822580645, "y": 22.379032258064516, "width": 26.423891129032256, "height": 45.564516129032256, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "_X9FJjm7bw", "type": "rectanglelabels", "value": {"x": 42.07409274193548, "y": 52.41935483870967, "width": 2.2681451612903274, "height": 3.024193548387103, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:28:35.972467+00	2026-01-06 23:28:35.972481+00	19	{}	8.014	2	1	\N	\N	\N	\N	1	1	75396779-1181-43f3-a379-d141e3464138	\N	\N	f
20	[{"id": "tMmJTTQLpR", "type": "rectanglelabels", "value": {"x": 55.5695564516129, "y": 22.58064516129032, "width": 26.990927419354847, "height": 45.564516129032256, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "wam4da1w7-", "type": "rectanglelabels", "value": {"x": 42.1875, "y": 53.2258064516129, "width": 1.7011088709677367, "height": 1.6129032258064555, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:28:46.507834+00	2026-01-06 23:28:46.507845+00	20	{}	7.535	2	1	\N	\N	\N	\N	1	1	74972810-bb1e-48c0-9ca5-bbe15da4704c	\N	\N	f
21	[{"id": "0rcYWOg8YW", "type": "rectanglelabels", "value": {"x": 55.456149193548384, "y": 21.572580645161292, "width": 26.764112903225808, "height": 46.77419354838709, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "UJAnfk0qXd", "type": "rectanglelabels", "value": {"x": 42.41431451612903, "y": 52.82258064516129, "width": 1.7011088709677367, "height": 3.225806451612897, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:29:10.048931+00	2026-01-06 23:29:10.048942+00	21	{}	7.175	2	1	\N	\N	\N	\N	1	1	bf421ce7-d88a-4381-ba56-a4e4ee0455d3	\N	\N	f
22	[{"id": "o4hryWoYx7", "type": "rectanglelabels", "value": {"x": 55.5695564516129, "y": 22.58064516129032, "width": 26.310483870967744, "height": 45.564516129032256, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "SVkhva1vhK", "type": "rectanglelabels", "value": {"x": 42.867943548387096, "y": 52.82258064516129, "width": 1.1340725806451601, "height": 2.016129032258064, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:29:19.306143+00	2026-01-06 23:29:19.306153+00	22	{}	7.42	2	1	\N	\N	\N	\N	1	1	6a8bfdd5-eac5-4bba-ada9-6d81016715f9	\N	\N	f
23	[{"id": "i41SwXR64B", "type": "rectanglelabels", "value": {"x": 41.96068548387096, "y": 53.0241935483871, "width": 2.4949596774193594, "height": 2.2177419354838577, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "AS1MLSR2bA", "type": "rectanglelabels", "value": {"x": 55.456149193548384, "y": 21.975806451612904, "width": 27.10433467741936, "height": 46.57258064516129, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:29:28.402798+00	2026-01-06 23:29:28.40281+00	23	{}	7.394	2	1	\N	\N	\N	\N	1	1	652bcf60-3bf5-4c00-84c1-e87f75cbae69	2026-01-06 23:29:28.20637+00	\N	f
24	[{"id": "gu5p5hGmfk", "type": "rectanglelabels", "value": {"x": 55.5695564516129, "y": 22.379032258064516, "width": 27.10433467741936, "height": 42.741935483870975, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "fiJLfNUkSF", "type": "rectanglelabels", "value": {"x": 42.30090725806451, "y": 52.41935483870967, "width": 1.8145161290322562, "height": 3.024193548387103, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:29:38.958368+00	2026-01-06 23:29:38.958378+00	24	{}	8.857	2	1	\N	\N	\N	\N	1	1	073ab41b-7873-4f87-b8b4-e124b489dd98	2026-01-06 23:29:38.856977+00	\N	f
25	[{"id": "RWbrq9bGsc", "type": "rectanglelabels", "value": {"x": 55.682963709677416, "y": 21.975806451612904, "width": 26.65070564516129, "height": 46.16935483870967, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "FEwY7JcKPN", "type": "rectanglelabels", "value": {"x": 41.84727822580645, "y": 52.62096774193549, "width": 2.4949596774193594, "height": 3.024193548387089, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:29:49.098498+00	2026-01-06 23:29:49.09851+00	25	{}	8.1	2	1	\N	\N	\N	\N	1	1	4ef799bb-8f22-49de-b038-8ae4f5018ba3	\N	\N	f
26	[{"id": "_LSt7CxRtq", "type": "rectanglelabels", "value": {"x": 54.8891129032258, "y": 22.782258064516128, "width": 28.692036290322584, "height": 47.78225806451613, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:29:57.854889+00	2026-01-06 23:29:57.854899+00	26	{}	7.206	1	1	\N	\N	\N	\N	1	1	ea556ad8-9bc1-4e92-98b5-4040c15b9f85	\N	\N	f
27	[{"id": "y_rh0KMbbf", "type": "rectanglelabels", "value": {"x": 55.342741935483865, "y": 21.572580645161292, "width": 27.67137096774193, "height": 47.177419354838705, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "gSIvqJpmlO", "type": "rectanglelabels", "value": {"x": 42.41431451612903, "y": 52.21774193548387, "width": 1.9279233870967758, "height": 2.8225806451612883, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:30:06.641699+00	2026-01-06 23:30:06.641714+00	27	{}	7.129	2	1	\N	\N	\N	\N	1	1	5cdf960c-96d1-4feb-babd-ba8b4579e7a9	\N	\N	f
28	[{"id": "TebBUoTBab", "type": "rectanglelabels", "value": {"x": 55.456149193548384, "y": 20.967741935483872, "width": 26.764112903225808, "height": 46.77419354838709, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "V-_wO_X0Ch", "type": "rectanglelabels", "value": {"x": 42.30090725806451, "y": 53.0241935483871, "width": 1.8145161290322562, "height": 2.016129032258057, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:30:14.582243+00	2026-01-06 23:30:14.582254+00	28	{}	6.531	2	1	\N	\N	\N	\N	1	1	1a70ee41-2ffa-4354-a4a8-29899d2a871c	\N	\N	f
29	[{"id": "HG7mrMwdkX", "type": "rectanglelabels", "value": {"x": 55.456149193548384, "y": 20.967741935483872, "width": 27.10433467741936, "height": 47.37903225806451, "rotation": 0, "rectanglelabels": ["mainboard"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}, {"id": "w7zLadUDFc", "type": "rectanglelabels", "value": {"x": 42.1875, "y": 52.62096774193549, "width": 1.8145161290322562, "height": 2.4193548387096726, "rotation": 0, "rectanglelabels": ["yellow_agentMeeple"]}, "origin": "manual", "to_name": "image", "from_name": "label", "image_rotation": 0, "original_width": 3840, "original_height": 2160}]	f	f	2026-01-06 23:30:23.008989+00	2026-01-06 23:30:23.009001+00	29	{}	7.013	2	1	\N	\N	\N	\N	1	1	6c19545c-b1d4-4281-9e39-63c1af1f90b1	\N	\N	f
\.


--
-- TOC entry 5332 (class 0 OID 25555)
-- Dependencies: 272
-- Data for Name: tasks_annotationdraft; Type: TABLE DATA; pg_dump: processing data for table "public.tasks_failedprediction"
pg_dump: dumping contents of table "public.tasks_failedprediction"
Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.tasks_annotationdraft (id, result, lead_time, created_at, updated_at, annotation_id, task_id, user_id, was_postponed, import_id) FROM stdin;
\.


--
-- TOC entry 5396 (class 0 OID 27052)
-- Dependencies: 336
-- Data for Name: tasks_failedprediction; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.tasks_failedprediction (id, message, error_type, model_version, created_at, ml_backend_model_id, model_run_id, project_id, task_id) FROM stdin;
\.


--
-- TOC entry 5334 (class 0 OID 25599)
-- Dependencies: 274
-- Data for Name: tasks_tasklock; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.tasks_tasklock (id, expire_at, task_id, user_id, unique_id, created_at) FROM stdin;
\.


--
-- TOC entry 5420 (class 0 OID 27593)
-- Dependencies: 360
-- Data for Name: token_blacklist_blacklistedtoken; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.token_blacklist_blacklistedtoken (id, blacklisted_at, token_id) FROM stdin;
\.


--
-- TOC entry 5422 (class 0 OID 27601)
-- Dependencies: 362
-- Data for Name: token_blacklist_outstandingtoken; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.token_blacklist_outstandingtoken (id, token, created_at, expires_at, user_id, jti) FROM stdin;
\.


--
-- TOC entry 5424 (class 0 OID 27691)
-- Dependencies: 364
-- Data for Name: users_userproducttour; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.users_userproducttour (id, name, state, interaction_data, created_at, updated_at, user_id) FROM stdin;
\.


--
-- TOC entry 5426 (class 0 OID 27713)
-- Dependencies: 366
-- Data for Name: webhook; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.webhook (id, url, send_payload, send_for_all_actions, headers, is_active, created_at, updated_at, organization_id, project_id) FROM stdin;
\.


--
-- TOC entry 5428 (class 0 OID 27730)
-- Dependencies: 368
-- Data for Name: webhook_action; Type: TABLE DATA; Schema: public; Owner: wopr-labelstudio-db-user
--

COPY public.webhook_action (id, action, webhook_id) FROM stdin;
\.


--
-- TOC entry 5437 (class 0 OID 0)
-- Dependencies: 227
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- TOC entry 5438 (class 0 OID 0)
-- Dependencies: 229
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- TOC entry 5439 (class 0 OID 0)
-- Dependencies: 225
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 305, true);


--
-- TOC entry 5440 (class 0 OID 0)
-- Dependencies: 253
-- Name: core_asyncmigrationstatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.core_asyncmigrationstatus_id_seq', 13, true);


--
-- TOC entry 5441 (class 0 OID 0)
-- Dependencies: 255
-- Name: core_deletedrow_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.core_deletedrow_id_seq', 1, false);


--
-- TOC entry 5442 (class 0 OID 0)
-- Dependencies: 261
-- Name: data_export_convertedformat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.data_export_convertedformat_id_seq', 1, false);


--
-- TOC entry 5443 (class 0 OID 0)
-- Dependencies: 259
-- Name: data_export_export_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.data_export_export_id_seq', 1, false);


--
-- TOC entry 5444 (class 0 OID 0)
-- Dependencies: 263
-- Name: data_import_fileupload_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.data_import_fileupload_id_seq', 1, false);


--
-- TOC entry 5445 (class 0 OID 0)
-- Dependencies: 307
-- Name: data_manager_filter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.data_manager_filter_id_seq', 1, false);


--
-- TOC entry 5446 (class 0 OID 0)
-- Dependencies: 311
-- Name: data_manager_filtergroup_filters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.data_manager_filtergroup_filters_id_seq', 1, false);


--
-- TOC entry 5447 (class 0 OID 0)
-- Dependencies: 309
-- Name: data_manager_filtergroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.data_manager_filtergroup_id_seq', 1, true);


--
-- TOC entry 5448 (class 0 OID 0)
-- Dependencies: 313
-- Name: data_manager_view_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.data_manager_view_id_seq', 1, true);


--
-- TOC entry 5449 (class 0 OID 0)
-- Dependencies: 237
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- TOC entry 5450 (class 0 OID 0)
-- Dependencies: 223
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 77, true);


--
-- TOC entry 5451 (class 0 OID 0)
-- Dependencies: 221
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 392, true);


--
-- TOC entry 5452 (class 0 OID 0)
-- Dependencies: 233
-- Name: htx_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.htx_user_groups_id_seq', 1, false);


--
-- TOC entry 5453 (class 0 OID 0)
-- Dependencies: 231
-- Name: htx_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.htx_user_id_seq', 1, true);


--
-- TOC entry 5454 (class 0 OID 0)
-- Dependencies: 235
-- Name: htx_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.htx_user_user_permissions_id_seq', 1, false);


--
-- TOC entry 5455 (class 0 OID 0)
-- Dependencies: 305
-- Name: io_storages_azureblobexportstoragelink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_azureblobexportstoragelink_id_seq', 1, false);


--
-- TOC entry 5456 (class 0 OID 0)
-- Dependencies: 303
-- Name: io_storages_azureblobimportstoragelink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_azureblobimportstoragelink_id_seq', 1, false);


--
-- TOC entry 5457 (class 0 OID 0)
-- Dependencies: 275
-- Name: io_storages_azureblobstoragemixin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_azureblobstoragemixin_id_seq', 1, false);


--
-- TOC entry 5458 (class 0 OID 0)
-- Dependencies: 301
-- Name: io_storages_gcsexportstoragelink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_gcsexportstoragelink_id_seq', 1, false);


--
-- TOC entry 5459 (class 0 OID 0)
-- Dependencies: 299
-- Name: io_storages_gcsimportstoragelink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_gcsimportstoragelink_id_seq', 1, false);


--
-- TOC entry 5460 (class 0 OID 0)
-- Dependencies: 277
-- Name: io_storages_gcsstoragemixin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_gcsstoragemixin_id_seq', 1, false);


--
-- TOC entry 5461 (class 0 OID 0)
-- Dependencies: 348
-- Name: io_storages_localfilesexportstoragelink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_localfilesexportstoragelink_id_seq', 29, true);


--
-- TOC entry 5462 (class 0 OID 0)
-- Dependencies: 346
-- Name: io_storages_localfilesimportstoragelink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_localfilesimportstoragelink_id_seq', 30, true);


--
-- TOC entry 5463 (class 0 OID 0)
-- Dependencies: 342
-- Name: io_storages_localfilesmixin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_localfilesmixin_id_seq', 2, true);


--
-- TOC entry 5464 (class 0 OID 0)
-- Dependencies: 297
-- Name: io_storages_redisexportstoragelink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_redisexportstoragelink_id_seq', 1, false);


--
-- TOC entry 5465 (class 0 OID 0)
-- Dependencies: 295
-- Name: io_storages_redisimportstoragelink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_redisimportstoragelink_id_seq', 1, false);


--
-- TOC entry 5466 (class 0 OID 0)
-- Dependencies: 279
-- Name: io_storages_redisstoragemixin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_redisstoragemixin_id_seq', 1, false);


--
-- TOC entry 5467 (class 0 OID 0)
-- Dependencies: 281
-- Name: io_storages_s3exportstorage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_s3exportstorage_id_seq', 1, true);


--
-- TOC entry 5468 (class 0 OID 0)
-- Dependencies: 293
-- Name: io_storages_s3exportstoragelink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_s3exportstoragelink_id_seq', 29, true);


--
-- TOC entry 5469 (class 0 OID 0)
-- Dependencies: 283
-- Name: io_storages_s3importstorage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_s3importstorage_id_seq', 2, true);


--
-- TOC entry 5470 (class 0 OID 0)
-- Dependencies: 291
-- Name: io_storages_s3importstoragelink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.io_storages_s3importstoragelink_id_seq', 1, false);


--
-- TOC entry 5471 (class 0 OID 0)
-- Dependencies: 351
-- Name: labels_manager_label_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.labels_manager_label_id_seq', 1, false);


--
-- TOC entry 5472 (class 0 OID 0)
-- Dependencies: 353
-- Name: labels_manager_labellink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.labels_manager_labellink_id_seq', 1, false);


--
-- TOC entry 5473 (class 0 OID 0)
-- Dependencies: 329
-- Name: ml_mlbackend_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.ml_mlbackend_id_seq', 1, false);


--
-- TOC entry 5474 (class 0 OID 0)
-- Dependencies: 333
-- Name: ml_mlbackendpredictionjob_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.ml_mlbackendpredictionjob_id_seq', 1, false);


--
-- TOC entry 5475 (class 0 OID 0)
-- Dependencies: 331
-- Name: ml_mlbackendtrainjob_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.ml_mlbackendtrainjob_id_seq', 1, false);


--
-- TOC entry 5476 (class 0 OID 0)
-- Dependencies: 355
-- Name: ml_model_providers_modelproviderconnection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.ml_model_providers_modelproviderconnection_id_seq', 1, false);


--
-- TOC entry 5477 (class 0 OID 0)
-- Dependencies: 327
-- Name: ml_models_modelinterface_associated_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.ml_models_modelinterface_associated_projects_id_seq', 1, false);


--
-- TOC entry 5478 (class 0 OID 0)
-- Dependencies: 321
-- Name: ml_models_modelinterface_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.ml_models_modelinterface_id_seq', 1, false);


--
-- TOC entry 5479 (class 0 OID 0)
-- Dependencies: 325
-- Name: ml_models_modelrun_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.ml_models_modelrun_id_seq', 1, false);


--
-- TOC entry 5480 (class 0 OID 0)
-- Dependencies: 323
-- Name: ml_models_thirdpartymodelversion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.ml_models_thirdpartymodelversion_id_seq', 1, false);


--
-- TOC entry 5481 (class 0 OID 0)
-- Dependencies: 240
-- Name: organization_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.organization_id_seq', 1, true);


--
-- TOC entry 5482 (class 0 OID 0)
-- Dependencies: 242
-- Name: organizations_organizationmember_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.organizations_organizationmember_id_seq', 1, true);


--
-- TOC entry 5483 (class 0 OID 0)
-- Dependencies: 267
-- Name: prediction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.prediction_id_seq', 1, false);


--
-- TOC entry 5484 (class 0 OID 0)
-- Dependencies: 337
-- Name: prediction_meta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.prediction_meta_id_seq', 1, false);


--
-- TOC entry 5485 (class 0 OID 0)
-- Dependencies: 244
-- Name: project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.project_id_seq', 1, true);


--
-- TOC entry 5486 (class 0 OID 0)
-- Dependencies: 257
-- Name: projects_labelstreamhistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.projects_labelstreamhistory_id_seq', 1, true);


--
-- TOC entry 5487 (class 0 OID 0)
-- Dependencies: 317
-- Name: projects_projectimport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.projects_projectimport_id_seq', 1, false);


--
-- TOC entry 5488 (class 0 OID 0)
-- Dependencies: 250
-- Name: projects_projectmember_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.projects_projectmember_id_seq', 1, false);


--
-- TOC entry 5489 (class 0 OID 0)
-- Dependencies: 248
-- Name: projects_projectonboarding_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.projects_projectonboarding_id_seq', 1, false);


--
-- TOC entry 5490 (class 0 OID 0)
-- Dependencies: 246
-- Name: projects_projectonboardingsteps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.projects_projectonboardingsteps_id_seq', 1, false);


--
-- TOC entry 5491 (class 0 OID 0)
-- Dependencies: 319
-- Name: projects_projectreimport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.projects_projectreimport_id_seq', 1, false);


--
-- TOC entry 5492 (class 0 OID 0)
-- Dependencies: 315
-- Name: task_comment_authors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.task_comment_authors_id_seq', 1, false);


--
-- TOC entry 5493 (class 0 OID 0)
-- Dependencies: 269
-- Name: task_completion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.task_completion_id_seq', 29, true);


--
-- TOC entry 5494 (class 0 OID 0)
-- Dependencies: 265
-- Name: task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.task_id_seq', 30, true);


--
-- TOC entry 5495 (class 0 OID 0)
-- Dependencies: 335
-- Name: tasks_failedprediction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.tasks_failedprediction_id_seq', 1, false);


--
-- TOC entry 5496 (class 0 OID 0)
-- Dependencies: 271
-- Name: tasks_taskcompletiondraft_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.tasks_taskcompletiondraft_id_seq', 14, true);


--
-- TOC entry 5497 (class 0 OID 0)
-- Dependencies: 273
-- Name: tasks_tasklock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.tasks_tasklock_id_seq', 10, true);


--
-- TOC entry 5498 (class 0 OID 0)
-- Dependencies: 359
-- Name: token_blacklist_blacklistedtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.token_blacklist_blacklistedtoken_id_seq', 1, false);


--
-- TOC entry 5499 (class 0 OID 0)
-- Dependencies: 361
-- Name: token_blacklist_outstandingtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.token_blacklist_outstandingtoken_id_seq', 1, false);


--
-- TOC entry 5500 (class 0 OID 0)
-- Dependencies: 363
-- Name: users_userproducttour_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.users_userproducttour_id_seq', 1, false);


--
-- TOC entry 5501 (class 0 OID 0)
-- Dependencies: 367
-- Name: webhook_action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.webhook_action_id_seq', 1, false);


--
-- TOC entry 5502 (class 0 OID 0)
-- Dependencies: 365
-- Name: webhook_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wopr-labelstudio-db-user
--

SELECT pg_catalog.setval('public.webhook_id_seq', 1, false);


--
-- TOC entry 4572 (class 2606 OID 24946)
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- TOC entry 4577 (class 2606 OID 24826)
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- TOC entry 4580 (class 2606 OID 24815)
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 4574 (class 2606 OID 24804)
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- TOC entry 4567 (class 2606 OID 24817)
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- TOC entry 4569 (class 2606 OID 24796)
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- TOC entry 4610 (class 2606 OID 24956)
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- TOC entry 4612 (class 2606 OID 24958)
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- TOC entry 4647 (class 2606 OID 25347)
-- Name: core_asyncmigrationstatus core_asyncmigrationstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.core_asyncmigrationstatus
    ADD CONSTRAINT core_asyncmigrationstatus_pkey PRIMARY KEY (id);


--
-- TOC entry 4650 (class 2606 OID 25365)
-- Name: core_deletedrow core_deletedrow_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.core_deletedrow
    ADD CONSTRAINT core_deletedrow_pkey PRIMARY KEY (id);


--
-- TOC entry 4665 (class 2606 OID 25433)
-- Name: data_export_convertedformat data_export_convertedformat_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_export_convertedformat
    ADD CONSTRAINT data_export_convertedformat_pkey PRIMARY KEY (id);


--
-- TOC entry 4659 (class 2606 OID 25408)
-- Name: data_export_export data_export_export_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_export_export
    ADD CONSTRAINT data_export_export_pkey PRIMARY KEY (id);


--
-- TOC entry 4668 (class 2606 OID 25471)
-- Name: data_import_fileupload data_import_fileupload_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_import_fileupload
    ADD CONSTRAINT data_import_fileupload_pkey PRIMARY KEY (id);


--
-- TOC entry 4815 (class 2606 OID 26215)
-- Name: data_manager_filter data_manager_filter_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_manager_filter
    ADD CONSTRAINT data_manager_filter_pkey PRIMARY KEY (id);


--
-- TOC entry 4819 (class 2606 OID 26246)
-- Name: data_manager_filtergroup_filters data_manager_filtergroup_filtergroup_id_filter_id_196c3e22_uniq; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_manager_filtergroup_filters
    ADD CONSTRAINT data_manager_filtergroup_filtergroup_id_filter_id_196c3e22_uniq UNIQUE (filtergroup_id, filter_id);


--
-- TOC entry 4823 (class 2606 OID 26234)
-- Name: data_manager_filtergroup_filters data_manager_filtergroup_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_manager_filtergroup_filters
    ADD CONSTRAINT data_manager_filtergroup_filters_pkey PRIMARY KEY (id);


--
-- TOC entry 4817 (class 2606 OID 26225)
-- Name: data_manager_filtergroup data_manager_filtergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_manager_filtergroup
    ADD CONSTRAINT data_manager_filtergroup_pkey PRIMARY KEY (id);


--
-- TOC entry 4827 (class 2606 OID 26244)
-- Name: data_manager_view data_manager_view_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_manager_view
    ADD CONSTRAINT data_manager_view_pkey PRIMARY KEY (id);


--
-- TOC entry 4606 (class 2606 OID 24932)
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4562 (class 2606 OID 24786)
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY publpg_dump: processing data for table "public.tasks_tasklock"
pg_dump: dumping contents of table "public.tasks_tasklock"
pg_dump: processing data for table "public.token_blacklist_blacklistedtoken"
pg_dump: dumping contents of table "public.token_blacklist_blacklistedtoken"
pg_dump: processing data for table "public.token_blacklist_outstandingtoken"
pg_dump: dumping contents of table "public.token_blacklist_outstandingtoken"
pg_dump: processing data for table "public.users_userproducttour"
pg_dump: dumping contents of table "public.users_userproducttour"
pg_dump: processing data for table "public.webhook"
pg_dump: dumping contents of table "public.webhook"
pg_dump: processing data for table "public.webhook_action"
pg_dump: dumping contents of table "public.webhook_action"
pg_dump: executing SEQUENCE SET auth_group_id_seq
pg_dump: executing SEQUENCE SET auth_group_permissions_id_seq
pg_dump: executing SEQUENCE SET auth_permission_id_seq
pg_dump: executing SEQUENCE SET core_asyncmigrationstatus_id_seq
pg_dump: executing SEQUENCE SET core_deletedrow_id_seq
pg_dump: executing SEQUENCE SET data_export_convertedformat_id_seq
pg_dump: executing SEQUENCE SET data_export_export_id_seq
pg_dump: executing SEQUENCE SET data_import_fileupload_id_seq
pg_dump: executing SEQUENCE SET data_manager_filter_id_seq
pg_dump: executing SEQUENCE SET data_manager_filtergroup_filters_id_seq
pg_dump: executing SEQUENCE SET data_manager_filtergroup_id_seq
pg_dump: executing SEQUENCE SET data_manager_view_id_seq
pg_dump: executing SEQUENCE SET django_admin_log_id_seq
pg_dump: executing SEQUENCE SET django_content_type_id_seq
pg_dump: executing SEQUENCE SET django_migrations_id_seq
pg_dump: executing SEQUENCE SET htx_user_groups_id_seq
pg_dump: executing SEQUENCE SET htx_user_id_seq
pg_dump: executing SEQUENCE SET htx_user_user_permissions_id_seq
pg_dump: executing SEQUENCE SET io_storages_azureblobexportstoragelink_id_seq
pg_dump: executing SEQUENCE SET io_storages_azureblobimportstoragelink_id_seq
pg_dump: executing SEQUENCE SET io_storages_azureblobstoragemixin_id_seq
pg_dump: executing SEQUENCE SET io_storages_gcsexportstoragelink_id_seq
pg_dump: executing SEQUENCE SET io_storages_gcsimportstoragelink_id_seq
pg_dump: executing SEQUENCE SET io_storages_gcsstoragemixin_id_seq
pg_dump: executing SEQUENCE SET io_storages_localfilesexportstoragelink_id_seq
pg_dump: executing SEQUENCE SET io_storages_localfilesimportstoragelink_id_seq
pg_dump: executing SEQUENCE SET io_storages_localfilesmixin_id_seq
pg_dump: executing SEQUENCE SET io_storages_redisexportstoragelink_id_seq
pg_dump: executing SEQUENCE SET io_storages_redisimportstoragelink_id_seq
pg_dump: executing SEQUENCE SET io_storages_redisstoragemixin_id_seq
pg_dump: executing SEQUENCE SET io_storages_s3exportstorage_id_seq
pg_dump: executing SEQUENCE SET io_storages_s3exportstoragelink_id_seq
pg_dump: executing SEQUENCE SET io_storages_s3importstorage_id_seq
pg_dump: executing SEQUENCE SET io_storages_s3importstoragelink_id_seq
pg_dump: executing SEQUENCE SET labels_manager_label_id_seq
pg_dump: executing SEQUENCE SET labels_manager_labellink_id_seq
pg_dump: executing SEQUENCE SET ml_mlbackend_id_seq
pg_dump: executing SEQUENCE SET ml_mlbackendpredictionjob_id_seq
pg_dump: executing SEQUENCE SET ml_mlbackendtrainjob_id_seq
pg_dump: executing SEQUENCE SET ml_model_providers_modelproviderconnection_id_seq
pg_dump: executing SEQUENCE SET ml_models_modelinterface_associated_projects_id_seq
pg_dump: executing SEQUENCE SET ml_models_modelinterface_id_seq
pg_dump: executing SEQUENCE SET ml_models_modelrun_id_seq
pg_dump: executing SEQUENCE SET ml_models_thirdpartymodelversion_id_seq
pg_dump: executing SEQUENCE SET organization_id_seq
pg_dump: executing SEQUENCE SET organizations_organizationmember_id_seq
pg_dump: executing SEQUENCE SET prediction_id_seq
pg_dump: executing SEQUENCE SET prediction_meta_id_seq
pg_dump: executing SEQUENCE SET project_id_seq
pg_dump: executing SEQUENCE SET projects_labelstreamhistory_id_seq
pg_dump: executing SEQUENCE SET projects_projectimport_id_seq
pg_dump: executing SEQUENCE SET projects_projectmember_id_seq
pg_dump: executing SEQUENCE SET projects_projectonboarding_id_seq
pg_dump: executing SEQUENCE SET projects_projectonboardingsteps_id_seq
pg_dump: executing SEQUENCE SET projects_projectreimport_id_seq
pg_dump: executing SEQUENCE SET task_comment_authors_id_seq
pg_dump: executing SEQUENCE SET task_completion_id_seq
pg_dump: executing SEQUENCE SET task_id_seq
pg_dump: executing SEQUENCE SET tasks_failedprediction_id_seq
pg_dump: executing SEQUENCE SET tasks_taskcompletiondraft_id_seq
pg_dump: executing SEQUENCE SET tasks_tasklock_id_seq
pg_dump: executing SEQUENCE SET token_blacklist_blacklistedtoken_id_seq
pg_dump: executing SEQUENCE SET token_blacklist_outstandingtoken_id_seq
pg_dump: executing SEQUENCE SET users_userproducttour_id_seq
pg_dump: executing SEQUENCE SET webhook_action_id_seq
pg_dump: executing SEQUENCE SET webhook_id_seq
pg_dump: creating CONSTRAINT "public.auth_group auth_group_name_key"
pg_dump: creating CONSTRAINT "public.auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq"
pg_dump: creating CONSTRAINT "public.auth_group_permissions auth_group_permissions_pkey"
pg_dump: creating CONSTRAINT "public.auth_group auth_group_pkey"
pg_dump: creating CONSTRAINT "public.auth_permission auth_permission_content_type_id_codename_01ab375a_uniq"
pg_dump: creating CONSTRAINT "public.auth_permission auth_permission_pkey"
pg_dump: creating CONSTRAINT "public.authtoken_token authtoken_token_pkey"
pg_dump: creating CONSTRAINT "public.authtoken_token authtoken_token_user_id_key"
pg_dump: creating CONSTRAINT "public.core_asyncmigrationstatus core_asyncmigrationstatus_pkey"
pg_dump: creating CONSTRAINT "public.core_deletedrow core_deletedrow_pkey"
pg_dump: creating CONSTRAINT "public.data_export_convertedformat data_export_convertedformat_pkey"
pg_dump: creating CONSTRAINT "public.data_export_export data_export_export_pkey"
pg_dump: creating CONSTRAINT "public.data_import_fileupload data_import_fileupload_pkey"
pg_dump: creating CONSTRAINT "public.data_manager_filter data_manager_filter_pkey"
pg_dump: creating CONSTRAINT "public.data_manager_filtergroup_filters data_manager_filtergroup_filtergroup_id_filter_id_196c3e22_uniq"
pg_dump: creating CONSTRAINT "public.data_manager_filtergroup_filters data_manager_filtergroup_filters_pkey"
pg_dump: creating CONSTRAINT "public.data_manager_filtergroup data_manager_filtergroup_pkey"
pg_dump: creating CONSTRAINT "public.data_manager_view data_manager_view_pkey"
pg_dump: creating CONSTRAINT "public.django_admin_log django_admin_log_pkey"
pg_dump: creating CONSTRAINT "public.django_content_type django_content_type_app_label_model_76bd3d3b_uniq"
pg_dump: creating CONSTRAINT "public.django_content_type django_content_type_pkey"
pg_dump: creating CONSTRAINT "public.django_migrations django_migrations_pkey"
pg_dump: creating CONSTRAINT "public.django_session django_session_pkey"
pg_dump: creating CONSTRAINT "public.fsm_annotationstate fsm_annotationstate_pkey"
pg_dump: creating CONSTRAINT "public.fsm_projectstate fsm_projectstate_pkey"
pg_dump: creating CONSTRAINT "public.fsm_taskstate fsm_taskstate_pkey"
pg_dump: creating CONSTRAINT "public.htx_user htx_user_email_key"
pg_dump: creating CONSTRAINT "public.htx_user_groups htx_user_groups_pkey"
pg_dump: creating CONSTRAINT "public.htx_user_groups htx_user_groups_user_id_group_id_34da071d_uniq"
pg_dump: creating CONSTRAINT "public.htx_user htx_user_pkey"
pg_dump: creating CONSTRAINT "public.htx_user_user_permissions htx_user_user_permissions_pkey"
pg_dump: creating CONSTRAINT "public.htx_user_user_permissions htx_user_user_permissions_user_id_permission_id_12eb87f0_uniq"
pg_dump: creating CONSTRAINT "public.io_storages_azureblobexportstorage io_storages_azureblobexportstorage_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_azureblobexportstoragelink io_storages_azureblobexportstoragelink_annotation_id_key"
pg_dump: creating CONSTRAINT "public.io_storages_azureblobexportstoragelink io_storages_azureblobexportstoragelink_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_azureblobimportstorage io_storages_azureblobimportstorage_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_azureblobimportstoragelink io_storages_azureblobimportstoragelink_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_azureblobimportstoragelink io_storages_azureblobimportstoragelink_task_id_key"
pg_dump: creating CONSTRAINT "public.io_storages_azureblobstoragemixin io_storages_azureblobstoragemixin_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_gcsexportstorage io_storages_gcsexportstorage_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_gcsexportstoragelink io_storages_gcsexportstoragelink_annotation_id_key"
pg_dump: creating CONSTRAINT "public.io_storages_gcsexportstoragelink io_storages_gcsexportstoragelink_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_gcsimportstorage io_storages_gcsimportstorage_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_gcsimportstoragelink io_storages_gcsimportstoragelink_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_gcsimportstoragelink io_storages_gcsimportstoragelink_task_id_key"
pg_dump: creating CONSTRAINT "public.io_storages_gcsstoragemixin io_storages_gcsstoragemixin_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_localfilesexportstorage io_storages_localfilesexportstorage_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_localfilesexportstoragelink io_storages_localfilesexportstoragelink_annotation_id_key"
pg_dump: creating CONSTRAINT "public.io_storages_localfilesexportstoragelink io_storages_localfilesexportstoragelink_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_localfilesimportstorage io_storages_localfilesimportstorage_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_localfilesimportstoragelink io_storages_localfilesimportstoragelink_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_localfilesimportstoragelink io_storages_localfilesimportstoragelink_task_id_key"
pg_dump: creating CONSTRAINT "public.io_storages_localfilesmixin io_storages_localfilesmixin_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_redisexportstorage io_storages_redisexportstorage_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_redisexportstoragelink io_storages_redisexportstoragelink_annotation_id_key"
pg_dump: creating CONSTRAINT "public.io_storages_redisexportstoragelink io_storages_redisexportstoragelink_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_redisimportstorage io_storages_redisimportstorage_pkey"
ic.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- TOC entry 4564 (class 2606 OID 24784)
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- TOC entry 4560 (class 2606 OID 24774)
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 4964 (class 2606 OID 27587)
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- TOC entry 4893 (class 2606 OID 27144)
-- Name: fsm_annotationstate fsm_annotationstate_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.fsm_annotationstate
    ADD CONSTRAINT fsm_annotationstate_pkey PRIMARY KEY (id);


--
-- TOC entry 4902 (class 2606 OID 27159)
-- Name: fsm_projectstate fsm_projectstate_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.fsm_projectstate
    ADD CONSTRAINT fsm_projectstate_pkey PRIMARY KEY (id);


--
-- TOC entry 4912 (class 2606 OID 27175)
-- Name: fsm_taskstate fsm_taskstate_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.fsm_taskstate
    ADD CONSTRAINT fsm_taskstate_pkey PRIMARY KEY (id);


--
-- TOC entry 4586 (class 2606 OID 24860)
-- Name: htx_user htx_user_email_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.htx_user
    ADD CONSTRAINT htx_user_email_key UNIQUE (email);


--
-- TOC entry 4594 (class 2606 OID 24869)
-- Name: htx_user_groups htx_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.htx_user_groups
    ADD CONSTRAINT htx_user_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 4597 (class 2606 OID 24891)
-- Name: htx_user_groups htx_user_groups_user_id_group_id_34da071d_uniq; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.htx_user_groups
    ADD CONSTRAINT htx_user_groups_user_id_group_id_34da071d_uniq UNIQUE (user_id, group_id);


--
-- TOC entry 4590 (class 2606 OID 24858)
-- Name: htx_user htx_user_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.htx_user
    ADD CONSTRAINT htx_user_pkey PRIMARY KEY (id);


--
-- TOC entry 4600 (class 2606 OID 24878)
-- Name: htx_user_user_permissions htx_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.htx_user_user_permissions
    ADD CONSTRAINT htx_user_user_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 4603 (class 2606 OID 24905)
-- Name: htx_user_user_permissions htx_user_user_permissions_user_id_permission_id_12eb87f0_uniq; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.htx_user_user_permissions
    ADD CONSTRAINT htx_user_user_permissions_user_id_permission_id_12eb87f0_uniq UNIQUE (user_id, permission_id);


--
-- TOC entry 4752 (class 2606 OID 25716)
-- Name: io_storages_azureblobexportstorage io_storages_azureblobexportstorage_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_azureblobexportstorage
    ADD CONSTRAINT io_storages_azureblobexportstorage_pkey PRIMARY KEY (azureblobstoragemixin_ptr_id);


--
-- TOC entry 4809 (class 2606 OID 25892)
-- Name: io_storages_azureblobexportstoragelink io_storages_azureblobexportstoragelink_annotation_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_azureblobexportstoragelink
    ADD CONSTRAINT io_storages_azureblobexportstoragelink_annotation_id_key UNIQUE (annotation_id);


--
-- TOC entry 4811 (class 2606 OID 25890)
-- Name: io_storages_azureblobexportstoragelink io_storages_azureblobexportstoragelink_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_azureblobexportstoragelink
    ADD CONSTRAINT io_storages_azureblobexportstoragelink_pkey PRIMARY KEY (id);


--
-- TOC entry 4755 (class 2606 OID 25729)
-- Name: io_storages_azureblobimportstorage io_storages_azureblobimportstorage_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_azureblobimportstorage
    ADD CONSTRAINT io_storages_azureblobimportstorage_pkey PRIMARY KEY (azureblobstoragemixin_ptr_id);


--
-- TOC entry 4803 (class 2606 OID 25877)
-- Name: io_storages_azureblobimportstoragelink io_storages_azureblobimportstoragelink_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_azureblobimportstoragelink
    ADD CONSTRAINT io_storages_azureblobimportstoragelink_pkey PRIMARY KEY (id);


--
-- TOC entry 4806 (class 2606 OID 25879)
-- Name: io_storages_azureblobimportstoragelink io_storages_azureblobimportstoragelink_task_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_azureblobimportstoragelink
    ADD CONSTRAINT io_storages_azureblobimportstoragelink_task_id_key UNIQUE (task_id);


--
-- TOC entry 4740 (class 2606 OID 25659)
-- Name: io_storages_azureblobstoragemixin io_storages_azureblobstoragemixin_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_azureblobstoragemixin
    ADD CONSTRAINT io_storages_azureblobstoragemixin_pkey PRIMARY KEY (id);


--
-- TOC entry 4758 (class 2606 OID 25739)
-- Name: io_storages_gcsexportstorage io_storages_gcsexportstorage_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_gcsexportstorage
    ADD CONSTRAINT io_storages_gcsexportstorage_pkey PRIMARY KEY (gcsstoragemixin_ptr_id);


--
-- TOC entry 4798 (class 2606 OID 25863)
-- Name: io_storages_gcsexportstoragelink io_storages_gcsexportstoragelink_annotation_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_gcsexportstoragelink
    ADD CONSTRAINT io_storages_gcsexportstoragelink_annotation_id_key UNIQUE (annotation_id);


--
-- TOC entry 4800 (class 2606 OID 25861)
-- Name: io_storages_gcsexportstoragelink io_storages_gcsexportstoragelink_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_gcsexportstoragelink
    ADD CONSTRAINT io_storages_gcsexportstoragelink_pkey PRIMARY KEY (id);


--
-- TOC entry 4761 (class 2606 OID 25752)
-- Name: io_storages_gcsimportstorage io_storages_gcsimportstorage_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_gcsimportstorage
    ADD CONSTRAINT io_storages_gcsimportstorage_pkey PRIMARY KEY (gcsstoragemixin_ptr_id);


--
-- TOC entry 4792 (class 2606 OID 25848)
-- Name: io_storages_gcsimportstoragelink io_storages_gcsimportstoragelink_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_gcsimportstoragelink
    ADD CONSTRAINT io_storages_gcsimportstoragelink_pkey PRIMARY KEY (id);


--
-- TOC entry 4795 (class 2606 OID 25850)
-- Name: io_storages_gcsimportstoragelink io_storages_gcsimportstoragelink_task_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_gcsimportstoragelink
    ADD CONSTRAINT io_storages_gcsimportstoragelink_task_id_key UNIQUE (task_id);


--
-- TOC entry 4742 (class 2606 OID 25669)
-- Name: io_storages_gcsstoragemixin io_storages_gcsstoragemixin_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_gcsstoragemixin
    ADD CONSTRAINT io_storages_gcsstoragemixin_pkey PRIMARY KEY (id);


--
-- TOC entry 4925 (class 2606 OID 27265)
-- Name: io_storages_localfilesexportstorage io_storages_localfilesexportstorage_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_localfilesexportstorage
    ADD CONSTRAINT io_storages_localfilesexportstorage_pkey PRIMARY KEY (localfilesmixin_ptr_id);


--
-- TOC entry 4937 (class 2606 OID 27305)
-- Name: io_storages_localfilesexportstoragelink io_storages_localfilesexportstoragelink_annotation_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_localfilesexportstoragelink
    ADD CONSTRAINT io_storages_localfilesexportstoragelink_annotation_id_key UNIQUE (annotation_id);


--
-- TOC entry 4939 (class 2606 OID 27303)
-- Name: io_storages_localfilesexportstoragelink io_storages_localfilesexportstoragelink_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_localfilesexportstoragelink
    ADD CONSTRAINT io_storages_localfilesexportstoragelink_pkey PRIMARY KEY (id);


--
-- TOC entry 4928 (class 2606 OID 27276)
-- Name: io_storages_localfilesimportstorage io_storages_localfilesimportstorage_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_localfilesimportstorage
    ADD CONSTRAINT io_storages_localfilesimportstorage_pkey PRIMARY KEY (localfilesmixin_ptr_id);


--
-- TOC entry 4931 (class 2606 OID 27290)
-- Name: io_storages_localfilesimportstoragelink io_storages_localfilesimportstoragelink_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_localfilesimportstoragelink
    ADD CONSTRAINT io_storages_localfilesimportstoragelink_pkey PRIMARY KEY (id);


--
-- TOC entry 4934 (class 2606 OID 27292)
-- Name: io_storages_localfilesimportstoragelink io_storages_localfilesimportstoragelink_task_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_localfilesimportstoragelink
    ADD CONSTRAINT io_storages_localfilesimportstoragelink_task_id_key UNIQUE (task_id);


--
-- TOC entry 4923 (class 2606 OID 27254)
-- Name: io_storages_localfilesmixin io_storages_localfilesmixin_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_localfilesmixin
    ADD CONSTRAINT io_storages_localfilesmixin_pkey PRIMARY KEY (id);


--
-- TOC entry 4764 (class 2606 OID 25764)
-- Name: io_storages_redisexportstorage io_storages_redisexportstorage_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_redisexportstorage
    ADD CONSTRAINT io_storages_redisexportstorage_pkey PRIMARY KEY (redisstoragemixin_ptr_id);


--
-- TOC entry 4787 (class 2606 OID 25834)
-- Name: io_storages_redisexportstoragelink io_storages_redisexportstoragelink_annotation_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_redisexportstoragelink
    ADD CONSTRAINT io_storages_redisexportstoragelink_annotation_id_key UNIQUE (annotation_id);


--
-- TOC entry 4789 (class 2606 OID 25832)
-- Name: io_storages_redisexportstoragelink io_storages_redisexportstoragelink_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_redisexportstoragelink
    ADD CONSTRAINT io_storages_redisexportstoragelink_pkey PRIMARY KEY (id);


--
-- TOC entry 4767 (class 2606 OID 25776)
-- Name: io_storages_redisimportstorage io_storages_redisimportstorage_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_redisimportstorage
    ADD CONSTRAINT io_storages_redisimportstorage_pkey PRIMARY KEY (redisstoragemixin_ptr_id);


--
-- TOC entry 4781 (class 2606 OID 25819)
-- Name: io_storages_redisimportstoragelink io_storages_redisimportstoragelink_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_redisimportstoragelink
    ADD CONSTRAINT io_storages_redisimportstoragelink_pkey PRIMARY KEY (id);


--
-- TOC entry 4784 (class 2606 OID 25821)
-- Name: io_storages_redisimportstoragelink io_storages_redisimportstoragelink_task_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_redisimportstoragelink
    ADD CONSTRAINT io_storages_redisimportstoragelink_task_id_key UNIQUE (task_id);


--
-- TOC entry 4744 (class 2606 OID 25679)
-- Name: io_storages_redisstoragemixin io_storages_redisstoragemixin_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_redisstoragemixin
    ADD CONSTRAINT io_storages_redisstoragemixin_pkey PRIMARY KEY (id);


--
-- TOC entry 4746 (class 2606 OID 25691)
-- Name: io_storages_s3exportstorage io_storages_s3exportstorage_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_s3exportstorage
    ADD CONSTRAINT io_storages_s3exportstorage_pkey PRIMARY KEY (id);


--
-- TOC entry 4776 (class 2606 OID 25805)
-- Name: io_storages_s3exportstoragelink io_storages_s3exportstoragelink_annotation_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_s3exportstoragelink
    ADD CONSTRAINT io_storages_s3exportstoragelink_annotation_id_key UNIQUE (annotation_id);


--
-- TOC entry 4778 (class 2606 OID 25803)
-- Name: io_storages_s3exportstoragelink io_storages_s3exportstoragelink_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_s3exportstoragelink
    ADD CONSTRAINT io_storages_s3exportstoragelink_pkey PRIMARY KEY (id);


--
-- TOC entry 4749 (class 2606 OID 25706)
-- Name: io_storages_s3importstorage io_storages_s3importstorage_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_s3importstorage
    ADD CONSTRAINT io_storages_s3importstorage_pkey PRIMARY KEY (id);


--
-- TOC entry 4770 (class 2606 OID 25790)
-- Name: io_storages_s3importstoragelink io_storages_s3importstoragelink_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_s3importstoragelink
    ADD CONSTRAINT io_storages_s3importstoragelink_pkey PRIMARY KEY (id);


--
-- TOC entry 4773 (class 2606 OID 25792)
-- Name: io_storages_s3importstoragelink io_storages_s3importstoragelink_task_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_s3importstoragelink
    ADD CONSTRAINT io_storages_s3importstoragelink_task_id_key UNIQUE (task_id);


--
-- TOC entry 4942 (class 2606 OID 27455)
-- Name: jwt_auth_jwtsettings jwt_auth_jwtsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.jwt_auth_jwtsettings
    ADD CONSTRAINT jwt_auth_jwtsettings_pkey PRIMARY KEY (organization_id);


--
-- TOC entry 4947 (class 2606 OID 27476)
-- Name: labels_manager_label labels_manager_label_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.labels_manager_label
    ADD CONSTRAINT labels_manager_label_pkey PRIMARY KEY (id);


--
-- TOC entry 4952 (class 2606 OID 27488)
-- Name: labels_manager_labellink labels_manager_labellink_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.labels_manager_labellink
    ADD CONSTRAINT labels_manager_labellink_pkey PRIMARY KEY (id);


--
-- TOC entry 4865 (class 2606 OID 26982)
-- Name: ml_mlbackend ml_mlbackend_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_mlbackend
    ADD CONSTRAINT ml_mlbackend_pkey PRIMARY KEY (id);


--
-- TOC entry 4872 (class 2606 OID 27010)
-- Name: ml_mlbackendpredictionjob ml_mlbackendpredictionjob_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_mlbackendpredictionjob
    ADD CONSTRAINT ml_mlbackendpredictionjob_pkey PRIMARY KEY (id);


--
-- TOC entry 4869 (class 2606 OID 26995)
-- Name: ml_mlbackendtrainjob ml_mlbackendtrainjob_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_mlbackendtrainjob
    ADD CONSTRAINT ml_mlbackendtrainjob_pkey PRIMARY KEY (id);


--
-- TOC entry 4959 (class 2606 OID 27535)
-- Name: ml_model_providers_modelproviderconnection ml_model_providers_modelproviderconnection_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_model_providers_modelproviderconnection
    ADD CONSTRAINT ml_model_providers_modelproviderconnection_pkey PRIMARY KEY (id);


--
-- TOC entry 4861 (class 2606 OID 26944)
-- Name: ml_models_modelinterface_associated_projects ml_models_modelinterface_associated_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_modelinterface_associated_projects
    ADD CONSTRAINT ml_models_modelinterface_associated_projects_pkey PRIMARY KEY (id);


--
-- TOC entry 4863 (class 2606 OID 26950)
-- Name: ml_models_modelinterface_associated_projects ml_models_modelinterface_modelinterface_id_projec_4278f3da_uniq; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_modelinterface_associated_projects
    ADD CONSTRAINT ml_models_modelinterface_modelinterface_id_projec_4278f3da_uniq UNIQUE (modelinterface_id, project_id);


--
-- TOC entry 4845 (class 2606 OID 26850)
-- Name: ml_models_modelinterface ml_models_modelinterface_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_modelinterface
    ADD CONSTRAINT ml_models_modelinterface_pkey PRIMARY KEY (id);


--
-- TOC entry 4856 (class 2606 OID 26911)
-- Name: ml_models_modelrun ml_models_modelrun_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_modelrun
    ADD CONSTRAINT ml_models_modelrun_pkey PRIMARY KEY (id);


--
-- TOC entry 4851 (class 2606 OID 26866)
-- Name: ml_models_thirdpartymodelversion ml_models_thirdpartymodelversion_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_thirdpartymodelversion
    ADD CONSTRAINT ml_models_thirdpartymodelversion_pkey PRIMARY KEY (id);


--
-- TOC entry 4614 (class 2606 OID 24978)
-- Name: organization organization_created_by_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_created_by_id_key UNIQUE (created_by_id);


--
-- TOC entry 4616 (class 2606 OID 24976)
-- Name: organization organization_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_pkey PRIMARY KEY (id);


--
-- TOC entry 4619 (class 2606 OID 24993)
-- Name: organization organization_token_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_token_key UNIQUE (token);


--
-- TOC entry 4623 (class 2606 OID 24990)
-- Name: organizations_organizationmember organizations_organizationmember_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.organizations_organizationmember
    ADD CONSTRAINT organizations_organizationmember_pkey PRIMARY KEY (id);


--
-- TOC entry 4880 (class 2606 OID 27096)
-- Name: prediction_meta prediction_meta_failed_prediction_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.prediction_meta
    ADD CONSTRAINT prediction_meta_failed_prediction_id_key UNIQUE (failed_prediction_id);


--
-- TOC entry 4882 (class 2606 OID 27094)
-- Name: prediction_meta prediction_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.prediction_meta
    ADD CONSTRAINT prediction_meta_pkey PRIMARY KEY (id);


--
-- TOC entry 4884 (class 2606 OID 27098)
-- Name: prediction_meta prediction_meta_prediction_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.prediction_meta
    ADD CONSTRAINT prediction_meta_prediction_id_key UNIQUE (prediction_id);


--
-- TOC entry 4694 (class 2606 OID 25509)
-- Name: prediction prediction_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.prediction
    ADD CONSTRAINT prediction_pkey PRIMARY KEY (id);


--
-- TOC entry 4631 (class 2606 OID 25042)
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- TOC entry 4652 (class 2606 OID 25377)
-- Name: projects_labelstreamhistory projects_labelstreamhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_labelstreamhistory
    ADD CONSTRAINT projects_labelstreamhistory_pkey PRIMARY KEY (id);


--
-- TOC entry 4837 (class 2606 OID 26796)
-- Name: projects_projectimport projects_projectimport_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_projectimport
    ADD CONSTRAINT projects_projectimport_pkey PRIMARY KEY (id);


--
-- TOC entry 4641 (class 2606 OID 25254)
-- Name: projects_projectmember projects_projectmember_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_projectmember
    ADD CONSTRAINT projects_projectmember_pkey PRIMARY KEY (id);


--
-- TOC entry 4637 (class 2606 OID 25112)
-- Name: projects_projectonboarding projects_projectonboarding_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_projectonboarding
    ADD CONSTRAINT projects_projectonboarding_pkey PRIMARY KEY (id);


--
-- TOC entry 4635 (class 2606 OID 25056)
-- Name: projects_projectonboardingsteps projects_projectonboardingsteps_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_projectonboardingsteps
    ADD CONSTRAINT projects_projectonboardingsteps_pkey PRIMARY KEY (id);


--
-- TOC entry 4840 (class 2606 OID 26820)
-- Name: projects_projectreimport projects_projectreimport_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_projectreimport
    ADD CONSTRAINT projects_projectreimport_pkey PRIMARY KEY (id);


--
-- TOC entry 4645 (class 2606 OID 25296)
-- Name: projects_projectsummary projects_projectsummary_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_projectsummary
    ADD CONSTRAINT projects_projectsummary_pkey PRIMARY KEY (project_id);


--
-- TOC entry 4961 (class 2606 OID 27572)
-- Name: session_policy_sessiontimeoutpolicy session_policy_sessiontimeoutpolicy_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.session_policy_sessiontimeoutpolicy
    ADD CONSTRAINT session_policy_sessiontimeoutpolicy_pkey PRIMARY KEY (organization_id);


--
-- TOC entry 4831 (class 2606 OID 26294)
-- Name: task_comment_authors task_comment_authors_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task_comment_authors
    ADD CONSTRAINT task_comment_authors_pkey PRIMARY KEY (id);


--
-- TOC entry 4834 (class 2606 OID 26300)
-- Name: task_comment_authors task_comment_authors_task_id_user_id_f6f772c9_uniq; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task_comment_authors
    ADD CONSTRAINT task_comment_authors_task_id_user_id_f6f772c9_uniq UNIQUE (task_id, user_id);


--
-- TOC entry 4719 (class 2606 OID 25523)
-- Name: task_completion task_completion_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task_completion
    ADD CONSTRAINT task_completion_pkey PRIMARY KEY (id);


--
-- TOC entry 4723 (class 2606 OID 26332)
-- Name: task_completion task_completion_unique_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task_completion
    ADD CONSTRAINT task_completion_unique_id_key UNIQUE (unique_id);


--
-- TOC entry 4680 (class 2606 OID 25496)
-- Name: task task_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- TOC entry 4876 (class 2606 OID 27061)
-- Name: tasks_failedprediction tasks_failedprediction_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.tasks_failedprediction
    ADD CONSTRAINT tasks_failedprediction_pkey PRIMARY KEY (id);


--
-- TOC entry 4730 (class 2606 OID 25566)
-- Name: tasks_annotationdraft tasks_taskcompletiondraft_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.tasks_annotationdraft
    ADD CONSTRAINT tasks_taskcompletiondraft_pkey PRIMARY KEY (id);


--
-- TOC entry 4734 (class 2606 OID 25607)
-- Name: tasks_tasklock tasks_tasklock_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.tasks_tasklock
    ADD CONSTRAINT tasks_tasklock_pkey PRIMARY KEY (id);


--
-- TOC entry 4737 (class 2606 OID 26334)
-- Name: tasks_tasklock tasks_tasklock_unique_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.tasks_tasklock
    ADD CONSTRAINT tasks_tasklock_unique_id_key UNIQUE (unique_id);


--
-- TOC entry 4967 (class 2606 OID 27641)
-- Name: token_blacklist_blacklistedtoken token_blacklist_blacklistedtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.token_blacklist_blacklistedtoken
    ADD CONSTRAINT token_blacklist_blacklistedtoken_pkey PRIMARY KEY (id);


--
-- TOC entry 4969 (class 2606 OID 27664)
-- Name: token_blacklist_blacklistedtoken token_blacklist_blacklistedtoken_token_id_key; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.token_blacklist_blacklistedtoken
    ADD CONSTRAINT token_blacklist_blacklistedtoken_token_id_key UNIQUE (token_id);


--
-- TOC entry 4972 (class 2606 OID 27632)
-- Name: token_blacklist_outstandingtoken token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_uniq; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.token_blacklist_outstandingtoken
    ADD CONSTRAINT token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_uniq UNIQUE (jti);


--
-- TOC entry 4974 (class 2606 OID 27651)
-- Name: token_blacklist_outstandingtoken token_blacklist_outstandingtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.token_blacklist_outstandingtoken
    ADD CONSTRAINT token_blacklist_outstandingtoken_pkey PRIMARY KEY (id);


--
-- TOC entry 4656 (class 2606 OID 25391)
-- Name: projects_labelstreamhistory unique_history; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_labelstreamhistory
    ADD CONSTRAINT unique_history UNIQUE (user_id, project_id);


--
-- TOC entry 4955 (class 2606 OID 27522)
-- Name: labels_manager_labellink unique_label_project; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.labels_manager_labellink
    ADD CONSTRAINT unique_label_project UNIQUE (project_id, label_id);


--
-- TOC entry 4949 (class 2606 OID 27490)
-- Name: labels_manager_label unique_title; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.labels_manager_label
    ADD CONSTRAINT unique_title UNIQUE (title, organization_id);


--
-- TOC entry 4977 (class 2606 OID 27704)
-- Name: users_userproducttour users_uspg_dump: creating CONSTRAINT "public.io_storages_redisimportstoragelink io_storages_redisimportstoragelink_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_redisimportstoragelink io_storages_redisimportstoragelink_task_id_key"
pg_dump: creating CONSTRAINT "public.io_storages_redisstoragemixin io_storages_redisstoragemixin_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_s3exportstorage io_storages_s3exportstorage_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_s3exportstoragelink io_storages_s3exportstoragelink_annotation_id_key"
pg_dump: creating CONSTRAINT "public.io_storages_s3exportstoragelink io_storages_s3exportstoragelink_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_s3importstorage io_storages_s3importstorage_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_s3importstoragelink io_storages_s3importstoragelink_pkey"
pg_dump: creating CONSTRAINT "public.io_storages_s3importstoragelink io_storages_s3importstoragelink_task_id_key"
pg_dump: creating CONSTRAINT "public.jwt_auth_jwtsettings jwt_auth_jwtsettings_pkey"
pg_dump: creating CONSTRAINT "public.labels_manager_label labels_manager_label_pkey"
pg_dump: creating CONSTRAINT "public.labels_manager_labellink labels_manager_labellink_pkey"
erproducttour_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.users_userproducttour
    ADD CONSTRAINT users_userproducttour_pkey PRIMARY KEY (id);


--
-- TOC entry 4988 (class 2606 OID 27737)
-- Name: webhook_action webhook_action_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.webhook_action
    ADD CONSTRAINT webhook_action_pkey PRIMARY KEY (id);


--
-- TOC entry 4991 (class 2606 OID 27751)
-- Name: webhook_action webhook_action_webhook_id_action_11842b15_uniq; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.webhook_action
    ADD CONSTRAINT webhook_action_webhook_id_action_11842b15_uniq UNIQUE (webhook_id, action);


--
-- TOC entry 4982 (class 2606 OID 27728)
-- Name: webhook webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.webhook
    ADD CONSTRAINT webhook_pkey PRIMARY KEY (id);


--
-- TOC entry 4885 (class 1259 OID 27194)
-- Name: anno_current_state_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX anno_current_state_idx ON public.fsm_annotationstate USING btree (annotation_id, id DESC);


--
-- TOC entry 4886 (class 1259 OID 27197)
-- Name: anno_project_report_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX anno_project_report_idx ON public.fsm_annotationstate USING btree (project_id, state, id DESC);


--
-- TOC entry 4887 (class 1259 OID 27195)
-- Name: anno_task_state_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX anno_task_state_idx ON public.fsm_annotationstate USING btree (task_id, state, id DESC);


--
-- TOC entry 4888 (class 1259 OID 27196)
-- Name: anno_user_report_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX anno_user_report_idx ON public.fsm_annotationstate USING btree (completed_by_id, state, id DESC);


--
-- TOC entry 4698 (class 1259 OID 27114)
-- Name: annotation_proj_result_octlen_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX annotation_proj_result_octlen_idx ON public.task_completion USING btree (project_id, octet_length((result)::text) DESC) INCLUDE (id);


--
-- TOC entry 4570 (class 1259 OID 24947)
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- TOC entry 4575 (class 1259 OID 24837)
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- TOC entry 4578 (class 1259 OID 24838)
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- TOC entry 4565 (class 1259 OID 24823)
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- TOC entry 4608 (class 1259 OID 24964)
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- TOC entry 4648 (class 1259 OID 25353)
-- Name: core_asyncmigrationstatus_project_id_c78fbf75; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX core_asyncmigrationstatus_project_id_c78fbf75 ON public.core_asyncmigrationstatus USING btree (project_id);


--
-- TOC entry 4661 (class 1259 OID 25457)
-- Name: data_export_convertedformat_created_by_id_a765f2cd; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX data_export_convertedformat_created_by_id_a765f2cd ON public.data_export_convertedformat USING btree (created_by_id);


--
-- TOC entry 4662 (class 1259 OID 25439)
-- Name: data_export_convertedformat_export_id_3305f028; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX data_export_convertedformat_export_id_3305f028 ON public.data_export_convertedformat USING btree (export_id);


--
-- TOC entry 4663 (class 1259 OID 25458)
-- Name: data_export_convertedformat_organization_id_d0e9d7c8; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX data_export_convertedformat_organization_id_d0e9d7c8 ON public.data_export_convertedformat USING btree (organization_id);


--
-- TOC entry 4666 (class 1259 OID 25459)
-- Name: data_export_convertedformat_project_id_3cda1a1c; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX data_export_convertedformat_project_id_3cda1a1c ON public.data_export_convertedformat USING btree (project_id);


--
-- TOC entry 4657 (class 1259 OID 25419)
-- Name: data_export_export_created_by_id_ae0b7af3; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX data_export_export_created_by_id_ae0b7af3 ON public.data_export_export USING btree (created_by_id);


--
-- TOC entry 4660 (class 1259 OID 25420)
-- Name: data_export_export_project_id_dc05487f; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX data_export_export_project_id_dc05487f ON public.data_export_export USING btree (project_id);


--
-- TOC entry 4669 (class 1259 OID 25482)
-- Name: data_import_fileupload_project_id_1f511810; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX data_import_fileupload_project_id_1f511810 ON public.data_import_fileupload USING btree (project_id);


--
-- TOC entry 4670 (class 1259 OID 25483)
-- Name: data_import_fileupload_user_id_a3e1f065; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX data_import_fileupload_user_id_a3e1f065 ON public.data_import_fileupload USING btree (user_id);


--
-- TOC entry 4824 (class 1259 OID 26278)
-- Name: data_manage_project_69b96e_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX data_manage_project_69b96e_idx ON public.data_manager_view USING btree (project_id, "order");


--
-- TOC entry 4813 (class 1259 OID 26285)
-- Name: data_manager_filter_parent_id_b5dd2a37; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX data_manager_filter_parent_id_b5dd2a37 ON public.data_manager_filter USING btree (parent_id);


--
-- TOC entry 4820 (class 1259 OID 26258)
-- Name: data_manager_filtergroup_filters_filter_id_954bc394; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX data_manager_filtergroup_filters_filter_id_954bc394 ON public.data_manager_filtergroup_filters USING btree (filter_id);


--
-- TOC entry 4821 (class 1259 OID 26257)
-- Name: data_manager_filtergroup_filters_filtergroup_id_85d9bb16; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX data_manager_filtergroup_filters_filtergroup_id_85d9bb16 ON public.data_manager_filtergroup_filters USING btree (filtergroup_id);


--
-- TOC entry 4825 (class 1259 OID 26275)
-- Name: data_manager_view_filter_group_id_39a9ec2b; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX data_manager_view_filter_group_id_39a9ec2b ON public.data_manager_view USING btree (filter_group_id);


--
-- TOC entry 4828 (class 1259 OID 26274)
-- Name: data_manager_view_project_id_59f5a002; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX data_manager_view_project_id_59f5a002 ON public.data_manager_view USING btree (project_id);


--
-- TOC entry 4829 (class 1259 OID 26276)
-- Name: data_manager_view_user_id_e71e14cd; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX data_manager_view_user_id_e71e14cd ON public.data_manager_view USING btree (user_id);


--
-- TOC entry 4604 (class 1259 OID 24943)
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- TOC entry 4607 (class 1259 OID 24944)
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- TOC entry 4962 (class 1259 OID 27589)
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- TOC entry 4965 (class 1259 OID 27588)
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- TOC entry 4889 (class 1259 OID 27192)
-- Name: fsm_annotationstate_annotation_id_a73ea2ec; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_annotationstate_annotation_id_a73ea2ec ON public.fsm_annotationstate USING btree (annotation_id);


--
-- TOC entry 4890 (class 1259 OID 27191)
-- Name: fsm_annotationstate_completed_by_id_3f46eae0; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_annotationstate_completed_by_id_3f46eae0 ON public.fsm_annotationstate USING btree (completed_by_id);


--
-- TOC entry 4891 (class 1259 OID 27186)
-- Name: fsm_annotationstate_organization_id_a5163275; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_annotationstate_organization_id_a5163275 ON public.fsm_annotationstate USING btree (organization_id);


--
-- TOC entry 4894 (class 1259 OID 27190)
-- Name: fsm_annotationstate_project_id_bf5279de; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_annotationstate_project_id_bf5279de ON public.fsm_annotationstate USING btree (project_id);


--
-- TOC entry 4895 (class 1259 OID 27187)
-- Name: fsm_annotationstate_state_84d28d51; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_annotationstate_state_84d28d51 ON public.fsm_annotationstate USING btree (state);


--
-- TOC entry 4896 (class 1259 OID 27188)
-- Name: fsm_annotationstate_state_84d28d51_like; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_annotationstate_state_84d28d51_like ON public.fsm_annotationstate USING btree (state varchar_pattern_ops);


--
-- TOC entry 4897 (class 1259 OID 27189)
-- Name: fsm_annotationstate_task_id_e50e54d5; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_annotationstate_task_id_e50e54d5 ON public.fsm_annotationstate USING btree (task_id);


--
-- TOC entry 4898 (class 1259 OID 27193)
-- Name: fsm_annotationstate_triggered_by_id_1e47eb15; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_annotationstate_triggered_by_id_1e47eb15 ON public.fsm_annotationstate USING btree (triggered_by_id);


--
-- TOC entry 4899 (class 1259 OID 27211)
-- Name: fsm_projectstate_created_by_id_4d716749; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_projectstate_created_by_id_4d716749 ON public.fsm_projectstate USING btree (created_by_id);


--
-- TOC entry 4900 (class 1259 OID 27208)
-- Name: fsm_projectstate_organization_id_3889ce76; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_projectstate_organization_id_3889ce76 ON public.fsm_projectstate USING btree (organization_id);


--
-- TOC entry 4903 (class 1259 OID 27212)
-- Name: fsm_projectstate_project_id_590cf19b; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_projectstate_project_id_590cf19b ON public.fsm_projectstate USING btree (project_id);


--
-- TOC entry 4904 (class 1259 OID 27209)
-- Name: fsm_projectstate_state_4ee8839f; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_projectstate_state_4ee8839f ON public.fsm_projectstate USING btree (state);


--
-- TOC entry 4905 (class 1259 OID 27210)
-- Name: fsm_projectstate_state_4ee8839f_like; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_projectstate_state_4ee8839f_like ON public.fsm_projectstate USING btree (state varchar_pattern_ops);


--
-- TOC entry 4906 (class 1259 OID 27213)
-- Name: fsm_projectstate_triggered_by_id_345c19fc; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_projectstate_triggered_by_id_345c19fc ON public.fsm_projectstate USING btree (triggered_by_id);


--
-- TOC entry 4910 (class 1259 OID 27227)
-- Name: fsm_taskstate_organization_id_192d4ce3; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_taskstate_organization_id_192d4ce3 ON public.fsm_taskstate USING btree (organization_id);


--
-- TOC entry 4913 (class 1259 OID 27230)
-- Name: fsm_taskstate_project_id_4e135c45; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_taskstate_project_id_4e135c45 ON public.fsm_taskstate USING btree (project_id);


--
-- TOC entry 4914 (class 1259 OID 27228)
-- Name: fsm_taskstate_state_d158253a; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_taskstate_state_d158253a ON public.fsm_taskstate USING btree (state);


--
-- TOC entry 4915 (class 1259 OID 27229)
-- Name: fsm_taskstate_state_d158253a_like; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_taskstate_state_d158253a_like ON public.fsm_taskstate USING btree (state varchar_pattern_ops);


--
-- TOC entry 4916 (class 1259 OID 27231)
-- Name: fsm_taskstate_task_id_94042c41; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_taskstate_task_id_94042c41 ON public.fsm_taskstate USING btree (task_id);


--
-- TOC entry 4917 (class 1259 OID 27232)
-- Name: fsm_taskstate_triggered_by_id_1f1dfd8f; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX fsm_taskstate_triggered_by_id_1f1dfd8f ON public.fsm_taskstate USING btree (triggered_by_id);


--
-- TOC entry 4581 (class 1259 OID 27681)
-- Name: htx_user_active_organization_id_2e1bb565; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX htx_user_active_organization_id_2e1bb565 ON public.htx_user USING btree (active_organization_id);


--
-- TOC entry 4582 (class 1259 OID 27686)
-- Name: htx_user_date_jo_3bd95e_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX htx_user_date_jo_3bd95e_idx ON public.htx_user USING btree (date_joined);


--
-- TOC entry 4583 (class 1259 OID 27683)
-- Name: htx_user_email_051c68_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX htx_user_email_051c68_idx ON public.htx_user USING btree (email);


--
-- TOC entry 4584 (class 1259 OID 24889)
-- Name: htx_user_email_9375607c_like; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX htx_user_email_9375607c_like ON public.htx_user USING btree (email varchar_pattern_ops);


--
-- TOC entry 4587 (class 1259 OID 27684)
-- Name: htx_user_first_n_93c5de_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX htx_user_first_n_93c5de_idx ON public.htx_user USING btree (first_name);


--
-- TOC entry 4592 (class 1259 OID 24903)
-- Name: htx_user_groups_group_id_d0fee99a; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX htx_user_groups_group_id_d0fee99a ON public.htx_user_groups USING btree (group_id);


--
-- TOC entry 4595 (class 1259 OID 24902)
-- Name: htx_user_groups_user_id_620c9163; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX htx_user_groups_user_id_620c9163 ON public.htx_user_groups USING btree (user_id);


--
-- TOC entry 4588 (class 1259 OID 27685)
-- Name: htx_user_last_na_2ace53_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX htx_user_last_na_2ace53_idx ON public.htx_user USING btree (last_name);


--
-- TOC entry 4598 (class 1259 OID 24917)
-- Name: htx_user_user_permissions_permission_id_edaf5db1; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX htx_user_user_permissions_permission_id_edaf5db1 ON public.htx_user_user_permissions USING btree (permission_id);


--
-- TOC entry 4601 (class 1259 OID 24916)
-- Name: htx_user_user_permissions_user_id_a71f59ac; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX htx_user_user_permissions_user_id_a71f59ac ON public.htx_user_user_permissions USING btree (user_id);


--
-- TOC entry 4591 (class 1259 OID 27682)
-- Name: htx_user_usernam_a41619_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX htx_user_usernam_a41619_idx ON public.htx_user USING btree (username);


--
-- TOC entry 4753 (class 1259 OID 25915)
-- Name: io_storages_azureblobexportstorage_project_id_43222df5; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_azureblobexportstorage_project_id_43222df5 ON public.io_storages_azureblobexportstorage USING btree (project_id);


--
-- TOC entry 4807 (class 1259 OID 27412)
-- Name: io_storages_azureblobexportstoragelink_annotation_id_6cc15c83; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_azureblobexportstoragelink_annotation_id_6cc15c83 ON public.io_storages_azureblobexportstoragelink USING btree (annotation_id);


--
-- TOC entry 4812 (class 1259 OID 26058)
-- Name: io_storages_azureblobexportstoragelink_storage_id_1b260b1e; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_azureblobexportstoragelink_storage_id_1b260b1e ON public.io_storages_azureblobexportstoragelink USING btree (storage_id);


--
-- TOC entry 4756 (class 1259 OID 25926)
-- Name: io_storages_azureblobimportstorage_project_id_67a67313; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_azureblobimportstorage_project_id_67a67313 ON public.io_storages_azureblobimportstorage USING btree (project_id);


--
-- TOC entry 4804 (class 1259 OID 26047)
-- Name: io_storages_azureblobimportstoragelink_storage_id_a08c3173; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_azureblobimportstoragelink_storage_id_a08c3173 ON public.io_storages_azureblobimportstoragelink USING btree (storage_id);


--
-- TOC entry 4759 (class 1259 OID 25937)
-- Name: io_storages_gcsexportstorage_project_id_c3141a14; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_gcsexportstorage_project_id_c3141a14 ON public.io_storages_gcsexportstorage USING btree (project_id);


--
-- TOC entry 4796 (class 1259 OID 27418)
-- Name: io_storages_gcsexportstoragelink_annotation_id_2df715a6; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_gcsexportstoragelink_annotation_id_2df715a6 ON public.io_storages_gcsexportstoragelink USING btree (annotation_id);


--
-- TOC entry 4801 (class 1259 OID 26036)
-- Name: io_storages_gcsexportstoragelink_storage_id_e940a32d; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_gcsexportstoragelink_storage_id_e940a32d ON public.io_storages_gcsexportstoragelink USING btree (storage_id);


--
-- TOC entry 4762 (class 1259 OID 25948)
-- Name: io_storages_gcsimportstorage_project_id_dfb68296; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_gcsimportstorage_project_id_dfb68296 ON public.io_storages_gcsimportstorage USING btree (project_id);


--
-- TOC entry 4793 (class 1259 OID 26025)
-- Name: io_storages_gcsimportstoragelink_storage_id_f3037a96; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_gcsimportstoragelink_storage_id_f3037a96 ON public.io_storages_gcpg_dump: creating CONSTRAINT "public.ml_mlbackend ml_mlbackend_pkey"
pg_dump: creating CONSTRAINT "public.ml_mlbackendpredictionjob ml_mlbackendpredictionjob_pkey"
pg_dump: creating CONSTRAINT "public.ml_mlbackendtrainjob ml_mlbackendtrainjob_pkey"
pg_dump: creating CONSTRAINT "public.ml_model_providers_modelproviderconnection ml_model_providers_modelproviderconnection_pkey"
pg_dump: creating CONSTRAINT "public.ml_models_modelinterface_associated_projects ml_models_modelinterface_associated_projects_pkey"
pg_dump: creating CONSTRAINT "public.ml_models_modelinterface_associated_projects ml_models_modelinterface_modelinterface_id_projec_4278f3da_uniq"
pg_dump: creating CONSTRAINT "public.ml_models_modelinterface ml_models_modelinterface_pkey"
pg_dump: creating CONSTRAINT "public.ml_models_modelrun ml_models_modelrun_pkey"
pg_dump: creating CONSTRAINT "public.ml_models_thirdpartymodelversion ml_models_thirdpartymodelversion_pkey"
pg_dump: creating CONSTRAINT "public.organization organization_created_by_id_key"
pg_dump: creating CONSTRAINT "public.organization organization_pkey"
pg_dump: creating CONSTRAINT "public.organization organization_token_key"
pg_dump: creating CONSTRAINT "public.organizations_organizationmember organizations_organizationmember_pkey"
pg_dump: creating CONSTRAINT "public.prediction_meta prediction_meta_failed_prediction_id_key"
pg_dump: creating CONSTRAINT "public.prediction_meta prediction_meta_pkey"
pg_dump: creating CONSTRAINT "public.prediction_meta prediction_meta_prediction_id_key"
pg_dump: creating CONSTRAINT "public.prediction prediction_pkey"
simportstoragelink USING btree (storage_id);


--
-- TOC entry 4926 (class 1259 OID 27316)
-- Name: io_storages_localfilesexportstorage_project_id_35dd9dc7; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_localfilesexportstorage_project_id_35dd9dc7 ON public.io_storages_localfilesexportstorage USING btree (project_id);


--
-- TOC entry 4935 (class 1259 OID 27424)
-- Name: io_storages_localfilesexportstoragelink_annotation_id_fc4f9825; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_localfilesexportstoragelink_annotation_id_fc4f9825 ON public.io_storages_localfilesexportstoragelink USING btree (annotation_id);


--
-- TOC entry 4940 (class 1259 OID 27349)
-- Name: io_storages_localfilesexportstoragelink_storage_id_87392e7a; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_localfilesexportstoragelink_storage_id_87392e7a ON public.io_storages_localfilesexportstoragelink USING btree (storage_id);


--
-- TOC entry 4929 (class 1259 OID 27327)
-- Name: io_storages_localfilesimportstorage_project_id_9ae1d2c5; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_localfilesimportstorage_project_id_9ae1d2c5 ON public.io_storages_localfilesimportstorage USING btree (project_id);


--
-- TOC entry 4932 (class 1259 OID 27338)
-- Name: io_storages_localfilesimportstoragelink_storage_id_59a5663c; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_localfilesimportstoragelink_storage_id_59a5663c ON public.io_storages_localfilesimportstoragelink USING btree (storage_id);


--
-- TOC entry 4765 (class 1259 OID 25959)
-- Name: io_storages_redisexportstorage_project_id_12a2546c; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_redisexportstorage_project_id_12a2546c ON public.io_storages_redisexportstorage USING btree (project_id);


--
-- TOC entry 4785 (class 1259 OID 27430)
-- Name: io_storages_redisexportstoragelink_annotation_id_8547e508; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_redisexportstoragelink_annotation_id_8547e508 ON public.io_storages_redisexportstoragelink USING btree (annotation_id);


--
-- TOC entry 4790 (class 1259 OID 26014)
-- Name: io_storages_redisexportstoragelink_storage_id_807898d8; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_redisexportstoragelink_storage_id_807898d8 ON public.io_storages_redisexportstoragelink USING btree (storage_id);


--
-- TOC entry 4768 (class 1259 OID 25970)
-- Name: io_storages_redisimportstorage_project_id_c7b9adc0; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_redisimportstorage_project_id_c7b9adc0 ON public.io_storages_redisimportstorage USING btree (project_id);


--
-- TOC entry 4782 (class 1259 OID 26003)
-- Name: io_storages_redisimportstoragelink_storage_id_17124de8; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_redisimportstoragelink_storage_id_17124de8 ON public.io_storages_redisimportstoragelink USING btree (storage_id);


--
-- TOC entry 4747 (class 1259 OID 25898)
-- Name: io_storages_s3exportstorage_project_id_5e76add6; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_s3exportstorage_project_id_5e76add6 ON public.io_storages_s3exportstorage USING btree (project_id);


--
-- TOC entry 4774 (class 1259 OID 27436)
-- Name: io_storages_s3exportstoragelink_annotation_id_729994fe; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_s3exportstoragelink_annotation_id_729994fe ON public.io_storages_s3exportstoragelink USING btree (annotation_id);


--
-- TOC entry 4779 (class 1259 OID 25992)
-- Name: io_storages_s3exportstoragelink_storage_id_a4563d13; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_s3exportstoragelink_storage_id_a4563d13 ON public.io_storages_s3exportstoragelink USING btree (storage_id);


--
-- TOC entry 4750 (class 1259 OID 25904)
-- Name: io_storages_s3importstorage_project_id_dee63a8d; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_s3importstorage_project_id_dee63a8d ON public.io_storages_s3importstorage USING btree (project_id);


--
-- TOC entry 4771 (class 1259 OID 25981)
-- Name: io_storages_s3importstoragelink_storage_id_50ca5bd8; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX io_storages_s3importstoragelink_storage_id_50ca5bd8 ON public.io_storages_s3importstoragelink USING btree (storage_id);


--
-- TOC entry 4943 (class 1259 OID 27506)
-- Name: labels_manager_label_approved_by_id_4b6a871f; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX labels_manager_label_approved_by_id_4b6a871f ON public.labels_manager_label USING btree (approved_by_id);


--
-- TOC entry 4944 (class 1259 OID 27507)
-- Name: labels_manager_label_created_by_id_e3b3e785; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX labels_manager_label_created_by_id_e3b3e785 ON public.labels_manager_label USING btree (created_by_id);


--
-- TOC entry 4945 (class 1259 OID 27508)
-- Name: labels_manager_label_organization_id_5f714874; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX labels_manager_label_organization_id_5f714874 ON public.labels_manager_label USING btree (organization_id);


--
-- TOC entry 4950 (class 1259 OID 27519)
-- Name: labels_manager_labellink_label_id_c8afbfa4; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX labels_manager_labellink_label_id_c8afbfa4 ON public.labels_manager_labellink USING btree (label_id);


--
-- TOC entry 4953 (class 1259 OID 27520)
-- Name: labels_manager_labellink_project_id_e3d33738; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX labels_manager_labellink_project_id_e3d33738 ON public.labels_manager_labellink USING btree (project_id);


--
-- TOC entry 4866 (class 1259 OID 27016)
-- Name: ml_mlbackend_project_id_ca08142d; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_mlbackend_project_id_ca08142d ON public.ml_mlbackend USING btree (project_id);


--
-- TOC entry 4870 (class 1259 OID 27028)
-- Name: ml_mlbackendpredictionjob_ml_backend_id_c1aea4f1; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_mlbackendpredictionjob_ml_backend_id_c1aea4f1 ON public.ml_mlbackendpredictionjob USING btree (ml_backend_id);


--
-- TOC entry 4867 (class 1259 OID 27022)
-- Name: ml_mlbackendtrainjob_ml_backend_id_3d40686e; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_mlbackendtrainjob_ml_backend_id_3d40686e ON public.ml_mlbackendtrainjob USING btree (ml_backend_id);


--
-- TOC entry 4956 (class 1259 OID 27546)
-- Name: ml_model_providers_modelpr_created_by_id_2e24aab7; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_model_providers_modelpr_created_by_id_2e24aab7 ON public.ml_model_providers_modelproviderconnection USING btree (created_by_id);


--
-- TOC entry 4957 (class 1259 OID 27547)
-- Name: ml_model_providers_modelpr_organization_id_ef7f6136; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_model_providers_modelpr_organization_id_ef7f6136 ON public.ml_model_providers_modelproviderconnection USING btree (organization_id);


--
-- TOC entry 4858 (class 1259 OID 26961)
-- Name: ml_models_modelinterface_a_modelinterface_id_035df3df; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_models_modelinterface_a_modelinterface_id_035df3df ON public.ml_models_modelinterface_associated_projects USING btree (modelinterface_id);


--
-- TOC entry 4859 (class 1259 OID 26962)
-- Name: ml_models_modelinterface_a_project_id_76a17855; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_models_modelinterface_a_project_id_76a17855 ON public.ml_models_modelinterface_associated_projects USING btree (project_id);


--
-- TOC entry 4842 (class 1259 OID 26877)
-- Name: ml_models_modelinterface_created_by_id_8ba717c0; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_models_modelinterface_created_by_id_8ba717c0 ON public.ml_models_modelinterface USING btree (created_by_id);


--
-- TOC entry 4843 (class 1259 OID 26878)
-- Name: ml_models_modelinterface_organization_id_d5688149; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_models_modelinterface_organization_id_d5688149 ON public.ml_models_modelinterface USING btree (organization_id);


--
-- TOC entry 4852 (class 1259 OID 26932)
-- Name: ml_models_modelrun_created_by_id_1a302218; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_models_modelrun_created_by_id_1a302218 ON public.ml_models_modelrun USING btree (created_by_id);


--
-- TOC entry 4853 (class 1259 OID 26933)
-- Name: ml_models_modelrun_model_version_id_e15572eb; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_models_modelrun_model_version_id_e15572eb ON public.ml_models_modelrun USING btree (model_version_id);


--
-- TOC entry 4854 (class 1259 OID 26934)
-- Name: ml_models_modelrun_organization_id_1f7f8243; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_models_modelrun_organization_id_1f7f8243 ON public.ml_models_modelrun USING btree (organization_id);


--
-- TOC entry 4857 (class 1259 OID 26935)
-- Name: ml_models_modelrun_project_id_1b76ea76; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_models_modelrun_project_id_1b76ea76 ON public.ml_models_modelrun USING btree (project_id);


--
-- TOC entry 4846 (class 1259 OID 27554)
-- Name: ml_models_thirdpartymodelv_model_provider_connection__b98c173f; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_models_thirdpartymodelv_model_provider_connection__b98c173f ON public.ml_models_thirdpartymodelversion USING btree (model_provider_connection_id);


--
-- TOC entry 4847 (class 1259 OID 26894)
-- Name: ml_models_thirdpartymodelversion_created_by_id_b1fb2c2f; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_models_thirdpartymodelversion_created_by_id_b1fb2c2f ON public.ml_models_thirdpartymodelversion USING btree (created_by_id);


--
-- TOC entry 4848 (class 1259 OID 26895)
-- Name: ml_models_thirdpartymodelversion_organization_id_a4a5df4d; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_models_thirdpartymodelversion_organization_id_a4a5df4d ON public.ml_models_thirdpartymodelversion USING btree (organization_id);


--
-- TOC entry 4849 (class 1259 OID 26896)
-- Name: ml_models_thirdpartymodelversion_parent_model_id_599e1869; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX ml_models_thirdpartymodelversion_parent_model_id_599e1869 ON public.ml_models_thirdpartymodelversion USING btree (parent_model_id);


--
-- TOC entry 4617 (class 1259 OID 25013)
-- Name: organization_token_5bd2529a_like; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX organization_token_5bd2529a_like ON public.organization USING btree (token varchar_pattern_ops);


--
-- TOC entry 4620 (class 1259 OID 26838)
-- Name: organizations_organizationmember_deleted_at_af2d5523; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX organizations_organizationmember_deleted_at_af2d5523 ON public.organizations_organizationmember USING btree (deleted_at);


--
-- TOC entry 4621 (class 1259 OID 25011)
-- Name: organizations_organizationmember_organization_id_f26cf71b; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX organizations_organizationmember_organization_id_f26cf71b ON public.organizations_organizationmember USING btree (organization_id);


--
-- TOC entry 4624 (class 1259 OID 25012)
-- Name: organizations_organizationmember_user_id_f3845ee5; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX organizations_organizationmember_user_id_f3845ee5 ON public.organizations_organizationmember USING btree (user_id);


--
-- TOC entry 4691 (class 1259 OID 27044)
-- Name: prediction_model_id_f9d54ad0; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX prediction_model_id_f9d54ad0 ON public.prediction USING btree (model_id);


--
-- TOC entry 4692 (class 1259 OID 26968)
-- Name: prediction_model_run_id_9d95621b; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX prediction_model_run_id_9d95621b ON public.prediction USING btree (model_run_id);


--
-- TOC entry 4695 (class 1259 OID 26833)
-- Name: prediction_project_id_ec1ad819; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX prediction_project_id_ec1ad819 ON public.prediction USING btree (project_id);


--
-- TOC entry 4696 (class 1259 OID 25619)
-- Name: prediction_task_id_4e4fb4d3; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX prediction_task_id_4e4fb4d3 ON public.prediction USING btree (task_id);


--
-- TOC entry 4625 (class 1259 OID 25305)
-- Name: project_created_by_id_6cc13408; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX project_created_by_id_6cc13408 ON public.project USING btree (created_by_id);


--
-- TOC entry 4907 (class 1259 OID 27214)
-- Name: project_current_state_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX project_current_state_idx ON public.fsm_projectstate USING btree (project_id, id DESC);


--
-- TOC entry 4626 (class 1259 OID 27561)
-- Name: project_deleted_at_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX project_deleted_at_idx ON public.project USING btree (deleted_at);


--
-- TOC entry 4627 (class 1259 OID 27560)
-- Name: project_org_deleted_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX project_org_deleted_idx ON public.project USING btree (organization_id, deleted_at);


--
-- TOC entry 4908 (class 1259 OID 27216)
-- Name: project_org_reporting_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX project_org_reporting_idx ON public.fsm_projectstate USING btree (organization_id, id DESC);


--
-- TOC entry 4909 (class 1259 OID 27215)
-- Name: project_org_state_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX project_org_state_idx ON public.fsm_projectstate USING btree (organization_id, state, id DESC);


--
-- TOC entry 4628 (class 1259 OID 25323)
-- Name: project_organization_id_3c9f74fb; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX project_organization_id_3c9f74fb ON public.project USING btree (organization_id);


--
-- TOC entry 4629 (class 1259 OID 25392)
-- Name: project_pinned__a39ccb_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX project_pinned__a39ccb_idx ON public.project USING btree (pinned_at, created_at);


--
-- TOC entry 4632 (class 1259 OID 27562)
-- Name: project_purge_at_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX project_purge_at_idx ON public.project USING btree (purge_at);


--
-- TOC entry 4633 (class 1259 OID 27125)
-- Name: project_search_vector_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX project_search_vector_idx ON public.project USING gin (search_vector);


--
-- TOC entry 4653 (class 1259 OID 25388)
-- Name: projects_labelstreamhistory_project_id_906c91dd; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX projects_labelstreamhistory_project_id_906c91dd ON public.projects_labelstreamhistory USING btree (project_id);


--
-- TOC entry 4654 (class 1259 OID 25389)
-- Name: projects_labelstreamhistory_user_id_1b571ab9; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX projects_labelstreamhistory_user_id_1b571ab9 ON public.projects_labelstreamhistory USING btree (user_id);


--
-- TOC entry 4838 (class 1259 OID 26802)
-- Name: projects_projectimport_project_id_619e3461; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX projects_projectimport_project_id_619e3461 ON public.projects_projectimport USING btree (project_id);


--
-- TOC entry 4642 (class 1259 OID 25321)
-- Name: projects_projectmember_project_id_e589ddea; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX projects_projectmember_project_id_e589ddea ON public.projects_projectmember USING btree (project_id);


--
-- TOC entry 4643 (class 1259 OID 25322)
-- Name: projects_projectmember_user_id_a475bbd8; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX projects_projectmember_user_id_a475bbd8 ON public.projects_projectmember USING btree (user_id);


--
-- TOC entry 4638 (class 1259 OID 25316)
-- Name: projects_projectonboarding_project_id_120e4f53; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX projects_projectonboarding_project_id_120e4f53 ON public.projects_projectonboarding USING btree (project_id);


--
-- TOC entry 4639 (class 1259 OID 25317)
-- Name: projects_projectonboarding_step_id_c232d94b; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX projects_projectonboarding_step_id_c232d94b ON public.projects_projectonboarding USING btree (step_id);


--
-- TOC entry 4841 (class 1259 OID 26826)
-- Name: projects_projectreimport_project_id_6bcffbed; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX projects_projectreimport_project_id_6bcffbed ON public.projects_projectreimport USING btree (project_id);


--
-- TOC entry 4671 (class 1259 OID 26189)
-- Name: task_cancelled_annotations_60dfe3b9; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_cancelled_annotations_60dfe3b9 ON public.task USING btree (cancelled_annotations);


--
-- TOC entry 4832 (class 1259 OID 26311)
-- Name: task_comment_authors_task_id_80618a4a; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comment_authors_task_id_80618a4a ON public.task_comment_authors USING btree (task_id);


--
-- TOC entry 4835 (class 1259 OID 26312)
-- Name: task_comment_authors_user_id_ff0b1cf0; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comment_authors_user_id_ff0b1cf0 ON public.task_comment_authors USING btree (user_id);


--
-- TOC entry 4672 (class 1259 OID 26313)
-- Name: task_comment_count_049355cc; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comment_count_049355cc ON public.task USING btree (comment_count);


--
-- TOC entry 4699 (class 1259 OID 26075)
-- Name: task_comple_created_f55e6f_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comple_created_f55e6f_idx ON public.task_completion USING btree (created_at);


--
-- TOC entry 4700 (class 1259 OID 26074)
-- Name: task_comple_ground__088a1b_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comple_ground__088a1b_idx ON public.task_completion USING btree (ground_truth);


--
-- TOC entry 4701 (class 1259 OID 26200)
-- Name: task_comple_id_653858_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comple_id_653858_idx ON public.task_completion USING btree (id, task_id);


--
-- TOC entry 4702 (class 1259 OID 26197)
-- Name: task_comple_last_ac_777e69_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comple_last_ac_777e69_idx ON public.task_completion USING btree (last_action);


--
-- TOC entry 4703 (class 1259 OID 26836)
-- Name: task_comple_project_0bc0be_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comple_project_0bc0be_idx ON public.task_completion USING btree (project_id, completed_by_id);


--
-- TOC entry 4704 (class 1259 OID 26772)
-- Name: task_comple_project_2cbbfc_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comple_project_2cbbfc_idx ON public.task_completion USING btree (project_id, ground_truth);


--
-- TOC entry 4705 (class 1259 OID 26773)
-- Name: task_comple_project_5c60f3_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comple_project_5c60f3_idx ON public.task_completion USING btree (project_id, was_cancelled);


--
-- TOC entry 4706 (class 1259 OID 26834)
-- Name: task_comple_project_c7e507_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comple_project_c7e507_idx ON public.task_completion USING btree (project_id, id);


--
-- TOC entry 4707 (class 1259 OID 26201)
-- Name: task_comple_task_id_8072c3_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comple_task_id_8072c3_idx ON public.task_completion USING btree (task_id, was_cancelled);


--
-- TOC entry 4708 (class 1259 OID 26837)
-- Name: task_comple_task_id_a6bdec_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comple_task_id_a6bdec_idx ON public.task_completion USING btree (task_id, id);


--
-- TOC entry 4709 (class 1259 OID 26180)
-- Name: task_comple_task_id_d49cd7_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comple_task_id_d49cd7_idx ON public.task_completion USING btree (task_id, completed_by_id);


--
-- TOC entry 4710 (class 1259 OID 26069)
-- Name: task_comple_task_id_e82920_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comple_task_id_e82920_idx ON public.task_completion USING btree (task_id, ground_truth);


--
-- TOC entry 4711 (class 1259 OID 26073)
-- Name: task_comple_was_can_f87d4e_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_comple_was_can_f87d4e_idx ON public.task_completion USING btree (was_cancelled);


--
-- TOC entry 4712 (class 1259 OID 25636)
-- Name: task_completion_completed_by_id_3f3206b1; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_completion_completed_by_id_3f3206b1 ON public.task_completion USING btree (completed_by_id);


--
-- TOC entry 4713 (class 1259 OID 27590)
-- Name: task_completion_id_updated_at_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_completion_id_updated_at_idx ON public.task_completion USING btree (id, updated_at);


--
-- TOC entry 4714 (class 1259 OID 26774)
-- Name: task_completion_import_id_e434c5af; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_completion_import_id_e434c5af ON public.task_completion USING btree (import_id);


--
-- TOC entry 4715 (class 1259 OID 26199)
-- Name: task_completion_last_created_by_id_a04457d1; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_completion_last_created_by_id_a04457d1 ON public.task_completion USING btree (last_created_by_id);


--
-- TOC entry 4716 (class 1259 OID 26171)
-- Name: task_completion_parent_annotation_id_58398c37; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_completion_parent_annotation_id_58398c37 ON public.task_completion USING btree (parent_annotation_id);


--
-- TOC entry 4717 (class 1259 OID 26170)
-- Name: task_completion_parent_prediction_id_053d00d9; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_completion_parent_prediction_id_053d00d9 ON public.task_completion USING btree (parent_prediction_id);


--
-- TOC entry 4720 (class 1259 OID 26324)
-- Name: task_completion_project_id_94072c87; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_completion_project_id_94072c87 ON public.task_completion USING btree (project_id);


--
-- TOC entry 4721 (class 1259 OID 25625)
-- Name: task_completion_task_id_b9049fbc; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_completion_task_id_b9049fbc ON public.task_completion USING btree (task_id);


--
-- TOC entry 4724 (class 1259 OID 26330)
-- Name: task_completion_updated_by_id_1164a739; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_completion_updated_by_id_1164a739 ON public.task_completion USING btree (updated_by_id);


--
-- TOC entry 4918 (class 1259 OID 27233)
-- Name: task_current_state_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_current_state_idx ON public.fsm_taskstate USING btree (task_id, id DESC);


--
-- TOC entry 4673 (class 1259 OID 25637)
-- Name: task_file_upload_id_549188ed; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_file_upload_id_549188ed ON public.task USING btree (file_upload_id);


--
-- TOC entry 4919 (class 1259 OID 27236)
-- Name: task_history_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_history_idx ON public.fsm_taskstate USING btree (task_id, id);


--
-- TOC entry 4674 (class 1259 OID 25553)
-- Name: task_id_7a9aca_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_id_7a9aca_idx ON public.task USING btree (id, overlap);


--
-- TOC entry 4675 (class 1259 OID 26181)
-- Name: task_id_aef988_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_id_aef988_idx ON public.task USING btree (id, project_id);


--
-- TOC entry 4676 (class 1259 OID 26314)
-- Name: task_last_comment_updated_at_d1bc3403; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_last_comment_updated_at_d1bc3403 ON public.task USING btree (last_comment_updated_at);


--
-- TOC entry 4920 (class 1259 OID 27235)
-- Name: task_org_reporting_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_org_reporting_idx ON public.fsm_taskstate USING btree (organization_id, state, id DESC);


--
-- TOC entry 4677 (class 1259 OID 25552)
-- Name: task_overlap_455a13f0; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_overlap_455a13f0 ON public.task USING btree (overlap);


--
-- TOC entry 4678 (class 1259 OID 26076)
-- Name: task_overlap_6a196e_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_overlap_6a196e_idx ON public.task USING btree (overlap);


--
-- TOC entry 4681 (class 1259 OID 27112)
-- Name: task_proj_octlen_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_proj_octlen_idx ON public.task USING btree (project_id, octet_length((data)::text) DESC) INCLUDE (id);


--
-- TOC entry 4682 (class 1259 OID 26202)
-- Name: task_project_499b59_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_project_499b59_idx ON public.task USING btree (project_id, inner_id);


--
-- TOC entry 4683 (class 1259 OID 25550)
-- Name: task_project_6acf5f_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_project_6acf5f_idx ON public.task USING btree (project_id, is_labeled);


--
-- TOC entry 4684 (class 1259 OID 26835)
-- Name: task_project_7b1c80_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_project_7b1c80_idx ON public.task USING btree (project_id, id);


--
-- TOC entry 4685 (class 1259 OID 25613)
-- Name: task_project_id_963d6354; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_project_id_963d6354 ON public.task USING btree (project_id);


--
-- TOC entry 4921 (class 1259 OID 27234)
-- Name: task_project_state_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_project_state_idx ON public.fsm_taskstate USING btree (project_id, state, id DESC);


--
-- TOC entry 4686 (class 1259 OID 26188)
-- Name: task_total_annotations_e77e347b; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_total_annotations_e77e347b ON public.task USING btree (total_annotations);


--
-- TOC entry 4687 (class 1259 OID 26190)
-- Name: task_total_predictions_f1a6b218; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_total_predictions_f1a6b218 ON public.task USING btree (total_predictions);


--
-- TOC entry 4688 (class 1259 OID 26315)
-- Name: task_unresolved_comment_count_8707d0c7; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_unresolved_comment_count_8707d0c7 ON public.task USING btree (unresolved_comment_count);


--
-- TOC entry 4689 (class 1259 OID 27111)
-- Name: task_updated_at_brin_idx; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_updated_at_brin_idx ON public.task USING brin (updated_at);


--
-- TOC entry 4690 (class 1259 OID 26177)
-- Name: task_updated_by_id_c9d9ddfb; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX task_updated_by_id_c9d9ddfb ON public.task USING btree (updated_by_id);


--
-- TOC entry 4726 (class 1259 OID 26775)
-- Name: tasks_annotationdraft_import_id_29542ca8; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX tasks_annotationdraft_import_id_29542ca8 ON public.tasks_annotationdraft USING btree (import_id);


--
-- TOC entry 4727 (class 1259 OID 26318)
-- Name: tasks_annotationdraft_was_postponed_6a1ee000; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX tasks_annotationdraft_was_postponed_6a1ee000 ON public.tasks_annotationdraft USING btree (was_postponed);


--
-- TOC entry 4725 (class 1259 OID 26771)
-- Name: tasks_annotations_result_proj_gin; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX tasks_annotations_result_proj_gin ON public.task_completion USING gin (project_id, ((result)::text) public.gin_trgm_ops);


--
-- TOC entry 4873 (class 1259 OID 27082)
-- Name: tasks_failedprediction_ml_backend_model_id_5813a377; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX tasks_failedprediction_ml_backend_model_id_5813a377 ON public.tasks_failedprediction USING btree (ml_backend_model_id);


--
-- TOC entry 4874 (class 1259 OID 27083)
-- Name: tasks_failedprediction_model_run_id_eec73944; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX tasks_failedprediction_model_run_id_eec73944 ON public.tasks_failedprediction USING btree (model_run_id);


--
-- TOC entry 4877 (class 1259 OID 27084)
-- Name: tasks_failedprediction_project_id_6b803bbe; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX tasks_failedprediction_project_id_6b803bbe ON public.tasks_failedprediction USING btree (project_id);


--
-- TOC entry 4878 (class 1259 OID 27085)
-- Name: tasks_failedprediction_task_id_ed2f3848; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX tasks_failedprediction_task_id_ed2f3848 ON public.tasks_failedprediction USING btree (task_id);


--
-- TOC entry 4697 (class 1259 OID 27113)
-- Name: tasks_predictions_result_proj_gin; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX tasks_predictions_result_proj_gin ON public.prediction USING gin (project_id, ((result)::text) public.gin_trgm_ops);


--
-- TOC entry 4728 (class 1259 OID 25632)
-- Name: tasks_taskcompletiondraft_completion_id_dc5dea99; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX tasks_taskcompletiondraft_completion_id_dc5dea99 ON public.tasks_annotationdraft USING btree (annotation_id);


--
-- TOC entry 4731 (class 1259 OID 25633)
-- Name: tasks_taskcompletiondraft_task_id_e575af88; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX tasks_taskcompletiondraft_task_id_e575af88 ON public.tasks_annotationdraft USING btree (task_id);


--
-- TOC entry 4732 (class 1259 OID 25634)
-- Name: tasks_taskcompletiondraft_user_id_b4b84cef; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX tasks_taskcompletiondraft_user_id_b4b84cef ON public.tasks_annotationdraft USING btree (user_id);


--
-- TOC entry 4735 (class 1259 OID 25648)
-- Name: tasks_tasklock_task_id_6531a5ed; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX tasks_tasklock_task_id_6531a5ed ON public.tasks_tasklock USING btree (task_id);


--
-- TOC entry 4738 (class 1259 OID 25649)
-- Name: tasks_tasklock_user_id_748ae86f; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX tasks_tasklock_user_id_748ae86f ON public.tasks_tasklock USING btree (user_id);


--
-- TOC entry 4970 (class 1259 OID 27633)
-- Name: token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_like; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_like ON public.token_blacklist_outstandingtoken USING btree (jti varchar_pattern_ops);


--
-- TOC entry 4975 (class 1259 OID 27629)
-- Name: token_blacklist_outstandingtoken_user_id_83bc629a; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX token_blacklist_outstandingtoken_user_id_83bc629a ON public.token_blacklist_outstandingtoken USING btree (user_id);


--
-- TOC entry 4978 (class 1259 OID 27710)
-- Name: users_userproducttour_user_id_64e8adfc; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX users_userproducttour_user_id_64e8adfc ON public.users_userproducttour USING btree (user_id);


--
-- TOC entry 4985 (class 1259 OID 27757)
-- Name: webhook_action_action_4398909e; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX webhook_action_action_4398909e ON public.webhook_action USING btree (action);


--
-- TOC entry 4986 (class 1259 OID 27758)
-- Name: webhook_action_action_4398909e_like; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX webhook_action_action_4398909e_like ON public.webhook_action USING btree (action varchar_pattern_ops);


--
-- TOC entry 4989 (class 1259 OID 27759)
-- Name: webhook_action_webhook_id_4eb6213f; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX webhook_action_webhook_id_4eb6213f ON public.webhook_action USING btree (webhook_id);


--
-- TOC entry 4979 (class 1259 OID 27760)
-- Name: webhook_created_at_b2a71ea5; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX webhook_created_at_b2a71ea5 ON public.webhook USING btree (created_at);


--
-- TOC entry 4980 (class 1259 OID 27748)
-- Name: webhook_organization_id_b5440e9a; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX webhook_organization_id_b5440e9a ON public.webhook USING btree (organization_id);


--
-- TOC entry 4983 (class 1259 OID 27749)
-- Name: webhook_project_id_e686d00c; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX webhook_project_id_e686d00c ON public.webhook USING btree (project_id);


--
-- TOC entry 4984 (class 1259 OID 27764)
-- Name: webhook_updated_at_695b4e7f; Type: INDEX; Schema: public; Owner: wopr-labelstudio-db-user
--

CREATE INDEX webhook_updated_at_695b4e7f ON public.webhook USING btree (updated_at);


--
-- TOC entry 4993 (class 2606 OID 24832)
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 4994 (class 2606 OID 24827)
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 4992 (class 2606 OID 24818)
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5002 (class 2606 OID 24959)
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_htx_user_id FOREIGN KEY (user_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5014 (class 2606 OID 25348)
-- Name: core_asyncmigrationstatus core_asyncmigrationstatus_project_id_c78fbf75_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.core_asyncmigrationstatus
    ADD CONSTRAINT core_asyncmigrationstatus_project_id_c78fbf75_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5019 (class 2606 OID 25441)
-- Name: data_export_convertedformat data_export_converte_created_by_id_a765f2cd_fk_htx_user_; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_export_convertedformat
    ADD CONSTRAINT data_export_converte_created_by_id_a765f2cd_fk_htx_user_ FOREIGN KEY (created_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5020 (class 2606 OID 25434)
-- Name: data_export_convertedformat data_export_converte_export_id_3305f028_fk_data_expo; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_export_convertedformat
    ADD CONSTRAINT data_export_converte_export_id_3305f028_fk_data_expo FOREIGN KEY (export_id) REFERENCES public.data_export_export(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5021 (class 2606 OID 25446)
-- Name: data_export_convertedformat data_export_converte_organization_id_d0e9d7c8_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_export_convertedformat
    ADD CONSTRAINT data_export_converte_organization_id_d0e9d7c8_fk_organizat FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5022 (class 2606 OID 25451)
-- Name: data_export_convertedformat data_export_convertedformat_project_id_3cda1a1c_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_export_convertedformat
    ADD CONSTRAINT data_export_convertedformat_project_id_3cda1a1c_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5017 (class 2606 OID 25409)
-- Name: data_export_export data_export_export_created_by_id_ae0b7af3_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_export_export
    ADD CONSTRAINT data_export_export_created_by_id_ae0b7af3_fk_htx_user_id FOREIGN KEY (created_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5018 (class 2606 OID 25414)
-- Name: data_export_export data_export_export_project_id_dc05487f_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_export_export
    ADD CONSTRAINT data_export_export_project_id_dc05487f_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5023 (class 2606 OID 25472)
-- Name: data_import_fileupload data_import_fileupload_project_id_1f511810_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_import_fileupload
    ADD CONSTRAINT data_import_fileupload_project_id_1f511810_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5024 (class 2606 OID 25477)
-- Name: data_import_fileupload data_import_pg_dump: creating CONSTRAINT "public.project project_pkey"
pg_dump: creating CONSTRAINT "public.projects_labelstreamhistory projects_labelstreamhistory_pkey"
pg_dump: creating CONSTRAINT "public.projects_projectimport projects_projectimport_pkey"
pg_dump: creating CONSTRAINT "public.projects_projectmember projects_projectmember_pkey"
pg_dump: creating CONSTRAINT "public.projects_projectonboarding projects_projectonboarding_pkey"
pg_dump: creating CONSTRAINT "public.projects_projectonboardingsteps projects_projectonboardingsteps_pkey"
pg_dump: creating CONSTRAINT "public.projects_projectreimport projects_projectreimport_pkey"
pg_dump: creating CONSTRAINT "public.projects_projectsummary projects_projectsummary_pkey"
fileupload_user_id_a3e1f065_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_import_fileupload
    ADD CONSTRAINT data_import_fileupload_user_id_a3e1f065_fk_htx_user_id FOREIGN KEY (user_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5074 (class 2606 OID 26279)
-- Name: data_manager_filter data_manager_filter_parent_id_b5dd2a37_fk_data_mana; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_manager_filter
    ADD CONSTRAINT data_manager_filter_parent_id_b5dd2a37_fk_data_mana FOREIGN KEY (parent_id) REFERENCES public.data_manager_filter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5075 (class 2606 OID 26252)
-- Name: data_manager_filtergroup_filters data_manager_filterg_filter_id_954bc394_fk_data_mana; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_manager_filtergroup_filters
    ADD CONSTRAINT data_manager_filterg_filter_id_954bc394_fk_data_mana FOREIGN KEY (filter_id) REFERENCES public.data_manager_filter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5076 (class 2606 OID 26247)
-- Name: data_manager_filtergroup_filters data_manager_filterg_filtergroup_id_85d9bb16_fk_data_mana; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_manager_filtergroup_filters
    ADD CONSTRAINT data_manager_filterg_filtergroup_id_85d9bb16_fk_data_mana FOREIGN KEY (filtergroup_id) REFERENCES public.data_manager_filtergroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5077 (class 2606 OID 26264)
-- Name: data_manager_view data_manager_view_filter_group_id_39a9ec2b_fk_data_mana; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_manager_view
    ADD CONSTRAINT data_manager_view_filter_group_id_39a9ec2b_fk_data_mana FOREIGN KEY (filter_group_id) REFERENCES public.data_manager_filtergroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5078 (class 2606 OID 26259)
-- Name: data_manager_view data_manager_view_project_id_59f5a002_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_manager_view
    ADD CONSTRAINT data_manager_view_project_id_59f5a002_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5079 (class 2606 OID 26269)
-- Name: data_manager_view data_manager_view_user_id_e71e14cd_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.data_manager_view
    ADD CONSTRAINT data_manager_view_user_id_e71e14cd_fk_htx_user_id FOREIGN KEY (user_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5000 (class 2606 OID 24933)
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5001 (class 2606 OID 24938)
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_htx_user_id FOREIGN KEY (user_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5105 (class 2606 OID 27176)
-- Name: fsm_annotationstate fsm_annotationstate_annotation_id_a73ea2ec_fk_task_comp; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.fsm_annotationstate
    ADD CONSTRAINT fsm_annotationstate_annotation_id_a73ea2ec_fk_task_comp FOREIGN KEY (annotation_id) REFERENCES public.task_completion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5106 (class 2606 OID 27181)
-- Name: fsm_annotationstate fsm_annotationstate_triggered_by_id_1e47eb15_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.fsm_annotationstate
    ADD CONSTRAINT fsm_annotationstate_triggered_by_id_1e47eb15_fk_htx_user_id FOREIGN KEY (triggered_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5107 (class 2606 OID 27198)
-- Name: fsm_projectstate fsm_projectstate_project_id_590cf19b_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.fsm_projectstate
    ADD CONSTRAINT fsm_projectstate_project_id_590cf19b_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5108 (class 2606 OID 27203)
-- Name: fsm_projectstate fsm_projectstate_triggered_by_id_345c19fc_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.fsm_projectstate
    ADD CONSTRAINT fsm_projectstate_triggered_by_id_345c19fc_fk_htx_user_id FOREIGN KEY (triggered_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5109 (class 2606 OID 27217)
-- Name: fsm_taskstate fsm_taskstate_task_id_94042c41_fk_task_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.fsm_taskstate
    ADD CONSTRAINT fsm_taskstate_task_id_94042c41_fk_task_id FOREIGN KEY (task_id) REFERENCES public.task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5110 (class 2606 OID 27222)
-- Name: fsm_taskstate fsm_taskstate_triggered_by_id_1f1dfd8f_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.fsm_taskstate
    ADD CONSTRAINT fsm_taskstate_triggered_by_id_1f1dfd8f_fk_htx_user_id FOREIGN KEY (triggered_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 4995 (class 2606 OID 27676)
-- Name: htx_user htx_user_active_organization_id_2e1bb565_fk_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.htx_user
    ADD CONSTRAINT htx_user_active_organization_id_2e1bb565_fk_organization_id FOREIGN KEY (active_organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 4996 (class 2606 OID 24897)
-- Name: htx_user_groups htx_user_groups_group_id_d0fee99a_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.htx_user_groups
    ADD CONSTRAINT htx_user_groups_group_id_d0fee99a_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 4997 (class 2606 OID 24892)
-- Name: htx_user_groups htx_user_groups_user_id_620c9163_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.htx_user_groups
    ADD CONSTRAINT htx_user_groups_user_id_620c9163_fk_htx_user_id FOREIGN KEY (user_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 4998 (class 2606 OID 24911)
-- Name: htx_user_user_permissions htx_user_user_permis_permission_id_edaf5db1_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.htx_user_user_permissions
    ADD CONSTRAINT htx_user_user_permis_permission_id_edaf5db1_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 4999 (class 2606 OID 24906)
-- Name: htx_user_user_permissions htx_user_user_permissions_user_id_a71f59ac_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.htx_user_user_permissions
    ADD CONSTRAINT htx_user_user_permissions_user_id_a71f59ac_fk_htx_user_id FOREIGN KEY (user_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5072 (class 2606 OID 27413)
-- Name: io_storages_azureblobexportstoragelink io_storages_azureblo_annotation_id_6cc15c83_fk_task_comp; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_azureblobexportstoragelink
    ADD CONSTRAINT io_storages_azureblo_annotation_id_6cc15c83_fk_task_comp FOREIGN KEY (annotation_id) REFERENCES public.task_completion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5046 (class 2606 OID 25905)
-- Name: io_storages_azureblobexportstorage io_storages_azureblo_azureblobstoragemixi_54a8d52d_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_azureblobexportstorage
    ADD CONSTRAINT io_storages_azureblo_azureblobstoragemixi_54a8d52d_fk_io_storag FOREIGN KEY (azureblobstoragemixin_ptr_id) REFERENCES public.io_storages_azureblobstoragemixin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5048 (class 2606 OID 25916)
-- Name: io_storages_azureblobimportstorage io_storages_azureblo_azureblobstoragemixi_e6234dd9_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_azureblobimportstorage
    ADD CONSTRAINT io_storages_azureblo_azureblobstoragemixi_e6234dd9_fk_io_storag FOREIGN KEY (azureblobstoragemixin_ptr_id) REFERENCES public.io_storages_azureblobstoragemixin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5047 (class 2606 OID 25910)
-- Name: io_storages_azureblobexportstorage io_storages_azureblo_project_id_43222df5_fk_project_i; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_azureblobexportstorage
    ADD CONSTRAINT io_storages_azureblo_project_id_43222df5_fk_project_i FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5049 (class 2606 OID 25921)
-- Name: io_storages_azureblobimportstorage io_storages_azureblo_project_id_67a67313_fk_project_i; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_azureblobimportstorage
    ADD CONSTRAINT io_storages_azureblo_project_id_67a67313_fk_project_i FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5073 (class 2606 OID 26053)
-- Name: io_storages_azureblobexportstoragelink io_storages_azureblo_storage_id_1b260b1e_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_azureblobexportstoragelink
    ADD CONSTRAINT io_storages_azureblo_storage_id_1b260b1e_fk_io_storag FOREIGN KEY (storage_id) REFERENCES public.io_storages_azureblobexportstorage(azureblobstoragemixin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5070 (class 2606 OID 26042)
-- Name: io_storages_azureblobimportstoragelink io_storages_azureblo_storage_id_a08c3173_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_azureblobimportstoragelink
    ADD CONSTRAINT io_storages_azureblo_storage_id_a08c3173_fk_io_storag FOREIGN KEY (storage_id) REFERENCES public.io_storages_azureblobimportstorage(azureblobstoragemixin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5071 (class 2606 OID 26037)
-- Name: io_storages_azureblobimportstoragelink io_storages_azureblob_task_id_26c31809_fk_task_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_azureblobimportstoragelink
    ADD CONSTRAINT io_storages_azureblob_task_id_26c31809_fk_task_id FOREIGN KEY (task_id) REFERENCES public.task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5068 (class 2606 OID 27419)
-- Name: io_storages_gcsexportstoragelink io_storages_gcsexpor_annotation_id_2df715a6_fk_task_comp; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_gcsexportstoragelink
    ADD CONSTRAINT io_storages_gcsexpor_annotation_id_2df715a6_fk_task_comp FOREIGN KEY (annotation_id) REFERENCES public.task_completion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5050 (class 2606 OID 25927)
-- Name: io_storages_gcsexportstorage io_storages_gcsexpor_gcsstoragemixin_ptr__007e6803_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_gcsexportstorage
    ADD CONSTRAINT io_storages_gcsexpor_gcsstoragemixin_ptr__007e6803_fk_io_storag FOREIGN KEY (gcsstoragemixin_ptr_id) REFERENCES public.io_storages_gcsstoragemixin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5069 (class 2606 OID 26031)
-- Name: io_storages_gcsexportstoragelink io_storages_gcsexpor_storage_id_e940a32d_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_gcsexportstoragelink
    ADD CONSTRAINT io_storages_gcsexpor_storage_id_e940a32d_fk_io_storag FOREIGN KEY (storage_id) REFERENCES public.io_storages_gcsexportstorage(gcsstoragemixin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5051 (class 2606 OID 25932)
-- Name: io_storages_gcsexportstorage io_storages_gcsexportstorage_project_id_c3141a14_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_gcsexportstorage
    ADD CONSTRAINT io_storages_gcsexportstorage_project_id_c3141a14_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5052 (class 2606 OID 25938)
-- Name: io_storages_gcsimportstorage io_storages_gcsimpor_gcsstoragemixin_ptr__10604ed3_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_gcsimportstorage
    ADD CONSTRAINT io_storages_gcsimpor_gcsstoragemixin_ptr__10604ed3_fk_io_storag FOREIGN KEY (gcsstoragemixin_ptr_id) REFERENCES public.io_storages_gcsstoragemixin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5066 (class 2606 OID 26020)
-- Name: io_storages_gcsimportstoragelink io_storages_gcsimpor_storage_id_f3037a96_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_gcsimportstoragelink
    ADD CONSTRAINT io_storages_gcsimpor_storage_id_f3037a96_fk_io_storag FOREIGN KEY (storage_id) REFERENCES public.io_storages_gcsimportstorage(gcsstoragemixin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5053 (class 2606 OID 25943)
-- Name: io_storages_gcsimportstorage io_storages_gcsimportstorage_project_id_dfb68296_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_gcsimportstorage
    ADD CONSTRAINT io_storages_gcsimportstorage_project_id_dfb68296_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5067 (class 2606 OID 26015)
-- Name: io_storages_gcsimportstoragelink io_storages_gcsimportstoragelink_task_id_3bedcb9b_fk_task_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_gcsimportstoragelink
    ADD CONSTRAINT io_storages_gcsimportstoragelink_task_id_3bedcb9b_fk_task_id FOREIGN KEY (task_id) REFERENCES public.task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5117 (class 2606 OID 27425)
-- Name: io_storages_localfilesexportstoragelink io_storages_localfil_annotation_id_fc4f9825_fk_task_comp; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_localfilesexportstoragelink
    ADD CONSTRAINT io_storages_localfil_annotation_id_fc4f9825_fk_task_comp FOREIGN KEY (annotation_id) REFERENCES public.task_completion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5111 (class 2606 OID 27306)
-- Name: io_storages_localfilesexportstorage io_storages_localfil_localfilesmixin_ptr__f0b19499_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_localfilesexportstorage
    ADD CONSTRAINT io_storages_localfil_localfilesmixin_ptr__f0b19499_fk_io_storag FOREIGN KEY (localfilesmixin_ptr_id) REFERENCES public.io_storages_localfilesmixin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5113 (class 2606 OID 27317)
-- Name: io_storages_localfilesimportstorage io_storages_localfil_localfilesmixin_ptr__fb0a0be4_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_localfilesimportstorage
    ADD CONSTRAINT io_storages_localfil_localfilesmixin_ptr__fb0a0be4_fk_io_storag FOREIGN KEY (localfilesmixin_ptr_id) REFERENCES public.io_storages_localfilesmixin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5112 (class 2606 OID 27311)
-- Name: io_storages_localfilesexportstorage io_storages_localfil_project_id_35dd9dc7_fk_project_i; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_localfilesexportstorage
    ADD CONSTRAINT io_storages_localfil_project_id_35dd9dc7_fk_project_i FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5114 (class 2606 OID 27322)
-- Name: io_storages_localfilesimportstorage io_storages_localfil_project_id_9ae1d2c5_fk_project_i; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_localfilesimportstorage
    ADD CONSTRAINT io_storages_localfil_project_id_9ae1d2c5_fk_project_i FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5115 (class 2606 OID 27333)
-- Name: io_storages_localfilesimportstoragelink io_storages_localfil_storage_id_59a5663c_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_localfilesimportstoragelink
    ADD CONSTRAINT io_storages_localfil_storage_id_59a5663c_fk_io_storag FOREIGN KEY (storage_id) REFERENCES public.io_storages_localfilesimportstorage(localfilesmixin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5118 (class 2606 OID 27344)
-- Name: io_storages_localfilesexportstoragelink io_storages_localfil_storage_id_87392e7a_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_localfilesexportstoragelink
    ADD CONSTRAINT io_storages_localfil_storage_id_87392e7a_fk_io_storag FOREIGN KEY (storage_id) REFERENCES public.io_storages_localfilesexportstorage(localfilesmixin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5116 (class 2606 OID 27328)
-- Name: io_storages_localfilesimportstoragelink io_storages_localfile_task_id_d0e8315f_fk_task_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_localfilesimportstoragelink
    ADD CONSTRAINT io_storages_localfile_task_id_d0e8315f_fk_task_id FOREIGN KEY (task_id) REFERENCES public.task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5064 (class 2606 OID 27431)
-- Name: io_storages_redisexportstoragelink io_storages_redisexp_annotation_id_8547e508_fk_task_comp; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_redisexportstoragelink
    ADD CONSTRAINT io_storages_redisexp_annotation_id_8547e508_fk_task_comp FOREIGN KEY (annotation_id) REFERENCES public.task_completion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5054 (class 2606 OID 25954)
-- Name: io_storages_redisexportstorage io_storages_redisexp_project_id_12a2546c_fk_project_i; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_redisexportstorage
    ADD CONSTRAINT io_storages_redisexp_project_id_12a2546c_fk_project_i FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5055 (class 2606 OID 25949)
-- Name: io_storages_redisexportstorage io_storages_redisexp_redisstoragemixin_pt_d1c2d337_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_redisexportstorage
    ADD CONSTRAINT io_storages_redisexp_redisstoragemixin_pt_d1c2d337_fk_io_storag FOREIGN KEY (redisstoragemixin_ptr_id) REFERENCES public.io_storages_redisstoragemixin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5065 (class 2606 OID 26009)
-- Name: io_storages_redisexportstoragelink io_storages_redisexp_storage_id_807898d8_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_redisexportstoragelink
    ADD CONSTRAINT io_storages_redisexp_storage_id_807898d8_fk_io_storag FOREIGN KEY (storage_id) REFERENCES public.io_storages_redisexportstorage(redisstoragemixin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5056 (class 2606 OID 25965)
-- Name: io_storages_redisimportstorage io_storages_redisimp_project_id_c7b9adc0_fk_project_i; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_redisimportstorage
    ADD CONSTRAINT io_storages_redisimp_project_id_c7b9adc0_fk_project_i FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5057 (class 2606 OID 25960)
-- Name: io_storages_redisimportstorage io_storages_redisimp_redisstoragemixin_pt_73982db6_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_redisimportstorage
    ADD CONSTRAINT io_storages_redisimp_redisstoragemixin_pt_73982db6_fk_io_storag FOREIGN KEY (redisstoragemixin_ptr_id) REFERENCES public.io_storages_redisstoragemixin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5062 (class 2606 OID 25998)
-- Name: io_storages_redisimportstoragelink io_storages_redisimp_storage_id_17124de8_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_redisimportstoragelink
    ADD CONSTRAINT io_storages_redisimp_storage_id_17124de8_fk_io_storag FOREIGN KEY (storage_id) REFERENCES public.io_storages_redisimportstorage(redisstoragemixin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5063 (class 2606 OID 25993)
-- Name: io_storages_redisimportstoragelink io_storages_redisimportstoragelink_task_id_6730b8ad_fk_task_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_redisimportstoragelink
    ADD CONSTRAINT io_storages_redisimportstoragelink_task_id_6730b8ad_fk_task_id FOREIGN KEY (task_id) REFERENCES public.task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5060 (class 2606 OID 27437)
-- Name: io_storages_s3exportstoragelink io_storages_s3export_annotation_id_729994fe_fk_task_comp; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_s3exportstoragelink
    ADD CONSTRAINT io_storages_s3export_annotation_id_729994fe_fk_task_comp FOREIGN KEY (annotation_id) REFERENCES public.task_completion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5061 (class 2606 OID 25987)
-- Name: io_storages_s3exportstoragelink io_storages_s3export_storage_id_a4563d13_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_s3exportstoragelink
    ADD CONSTRAINT io_storages_s3export_storage_id_a4563d13_fk_io_storag FOREIGN KEY (storage_id) REFERENCES public.io_storages_s3exportstorage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5044 (class 2606 OID 25893)
-- Name: io_storages_s3exportstorage io_storages_s3exportstorage_project_id_5e76add6_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_s3exportstorage
    ADD CONSTRAINT io_storages_s3exportstorage_project_id_5e76add6_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5058 (class 2606 OID 25971)
-- Name: io_storages_s3importstoragelink io_storages_s3import_storage_id_50ca5bd8_fk_io_storag; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_s3importstpg_dump: creating CONSTRAINT "public.session_policy_sessiontimeoutpolicy session_policy_sessiontimeoutpolicy_pkey"
pg_dump: creating CONSTRAINT "public.task_comment_authors task_comment_authors_pkey"
pg_dump: creating CONSTRAINT "public.task_comment_authors task_comment_authors_task_id_user_id_f6f772c9_uniq"
pg_dump: creating CONSTRAINT "public.task_completion task_completion_pkey"
pg_dump: creating CONSTRAINT "public.task_completion task_completion_unique_id_key"
pg_dump: creating CONSTRAINT "public.task task_pkey"
pg_dump: creating CONSTRAINT "public.tasks_failedprediction tasks_failedprediction_pkey"
pg_dump: creating CONSTRAINT "public.tasks_annotationdraft tasks_taskcompletiondraft_pkey"
pg_dump: creating CONSTRAINT "public.tasks_tasklock tasks_tasklock_pkey"
pg_dump: creating CONSTRAINT "public.tasks_tasklock tasks_tasklock_unique_id_key"
pg_dump: creating CONSTRAINT "public.token_blacklist_blacklistedtoken token_blacklist_blacklistedtoken_pkey"
pg_dump: creating CONSTRAINT "public.token_blacklist_blacklistedtoken token_blacklist_blacklistedtoken_token_id_key"
pg_dump: creating CONSTRAINT "public.token_blacklist_outstandingtoken token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_uniq"
pg_dump: creating CONSTRAINT "public.token_blacklist_outstandingtoken token_blacklist_outstandingtoken_pkey"
pg_dump: creating CONSTRAINT "public.projects_labelstreamhistory unique_history"
pg_dump: creating CONSTRAINT "public.labels_manager_labellink unique_label_project"
pg_dump: creating CONSTRAINT "public.labels_manager_label unique_title"
pg_dump: creating CONSTRAINT "public.users_userproducttour users_userproducttour_pkey"
pg_dump: creating CONSTRAINT "public.webhook_action webhook_action_pkey"
pg_dump: creating CONSTRAINT "public.webhook_action webhook_action_webhook_id_action_11842b15_uniq"
pg_dump: creating CONSTRAINT "public.webhook webhook_pkey"
pg_dump: creating INDEX "public.anno_current_state_idx"
pg_dump: creating INDEX "public.anno_project_report_idx"
pg_dump: creating INDEX "public.anno_task_state_idx"
pg_dump: creating INDEX "public.anno_user_report_idx"
pg_dump: creating INDEX "public.annotation_proj_result_octlen_idx"
pg_dump: creating INDEX "public.auth_group_name_a6ea08ec_like"
pg_dump: creating INDEX "public.auth_group_permissions_group_id_b120cbf9"
pg_dump: creating INDEX "public.auth_group_permissions_permission_id_84c5c92e"
pg_dump: creating INDEX "public.auth_permission_content_type_id_2f476e4b"
pg_dump: creating INDEX "public.authtoken_token_key_10f0b77e_like"
pg_dump: creating INDEX "public.core_asyncmigrationstatus_project_id_c78fbf75"
pg_dump: creating INDEX "public.data_export_convertedformat_created_by_id_a765f2cd"
pg_dump: creating INDEX "public.data_export_convertedformat_export_id_3305f028"
pg_dump: creating INDEX "public.data_export_convertedformat_organization_id_d0e9d7c8"
pg_dump: creating INDEX "public.data_export_convertedformat_project_id_3cda1a1c"
pg_dump: creating INDEX "public.data_export_export_created_by_id_ae0b7af3"
pg_dump: creating INDEX "public.data_export_export_project_id_dc05487f"
pg_dump: creating INDEX "public.data_import_fileupload_project_id_1f511810"
pg_dump: creating INDEX "public.data_import_fileupload_user_id_a3e1f065"
pg_dump: creating INDEX "public.data_manage_project_69b96e_idx"
pg_dump: creating INDEX "public.data_manager_filter_parent_id_b5dd2a37"
pg_dump: creating INDEX "public.data_manager_filtergroup_filters_filter_id_954bc394"
pg_dump: creating INDEX "public.data_manager_filtergroup_filters_filtergroup_id_85d9bb16"
pg_dump: creating INDEX "public.data_manager_view_filter_group_id_39a9ec2b"
pg_dump: oragelink
    ADD CONSTRAINT io_storages_s3import_storage_id_50ca5bd8_fk_io_storag FOREIGN KEY (storage_id) REFERENCES public.io_storages_s3importstorage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5045 (class 2606 OID 25899)
-- Name: io_storages_s3importstorage io_storages_s3importstorage_project_id_dee63a8d_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_s3importstorage
    ADD CONSTRAINT io_storages_s3importstorage_project_id_dee63a8d_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5059 (class 2606 OID 25976)
-- Name: io_storages_s3importstoragelink io_storages_s3importstoragelink_task_id_126f4f82_fk_task_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.io_storages_s3importstoragelink
    ADD CONSTRAINT io_storages_s3importstoragelink_task_id_126f4f82_fk_task_id FOREIGN KEY (task_id) REFERENCES public.task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5119 (class 2606 OID 27456)
-- Name: jwt_auth_jwtsettings jwt_auth_jwtsettings_organization_id_1e76aa12_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.jwt_auth_jwtsettings
    ADD CONSTRAINT jwt_auth_jwtsettings_organization_id_1e76aa12_fk_organizat FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5120 (class 2606 OID 27491)
-- Name: labels_manager_label labels_manager_label_approved_by_id_4b6a871f_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.labels_manager_label
    ADD CONSTRAINT labels_manager_label_approved_by_id_4b6a871f_fk_htx_user_id FOREIGN KEY (approved_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5121 (class 2606 OID 27496)
-- Name: labels_manager_label labels_manager_label_created_by_id_e3b3e785_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.labels_manager_label
    ADD CONSTRAINT labels_manager_label_created_by_id_e3b3e785_fk_htx_user_id FOREIGN KEY (created_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5123 (class 2606 OID 27509)
-- Name: labels_manager_labellink labels_manager_label_label_id_c8afbfa4_fk_labels_ma; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.labels_manager_labellink
    ADD CONSTRAINT labels_manager_label_label_id_c8afbfa4_fk_labels_ma FOREIGN KEY (label_id) REFERENCES public.labels_manager_label(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5122 (class 2606 OID 27501)
-- Name: labels_manager_label labels_manager_label_organization_id_5f714874_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.labels_manager_label
    ADD CONSTRAINT labels_manager_label_organization_id_5f714874_fk_organizat FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5124 (class 2606 OID 27514)
-- Name: labels_manager_labellink labels_manager_labellink_project_id_e3d33738_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.labels_manager_labellink
    ADD CONSTRAINT labels_manager_labellink_project_id_e3d33738_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5096 (class 2606 OID 27011)
-- Name: ml_mlbackend ml_mlbackend_project_id_ca08142d_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_mlbackend
    ADD CONSTRAINT ml_mlbackend_project_id_ca08142d_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5098 (class 2606 OID 27023)
-- Name: ml_mlbackendpredictionjob ml_mlbackendpredicti_ml_backend_id_c1aea4f1_fk_ml_mlback; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_mlbackendpredictionjob
    ADD CONSTRAINT ml_mlbackendpredicti_ml_backend_id_c1aea4f1_fk_ml_mlback FOREIGN KEY (ml_backend_id) REFERENCES public.ml_mlbackend(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5097 (class 2606 OID 27017)
-- Name: ml_mlbackendtrainjob ml_mlbackendtrainjob_ml_backend_id_3d40686e_fk_ml_mlbackend_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_mlbackendtrainjob
    ADD CONSTRAINT ml_mlbackendtrainjob_ml_backend_id_3d40686e_fk_ml_mlbackend_id FOREIGN KEY (ml_backend_id) REFERENCES public.ml_mlbackend(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5125 (class 2606 OID 27536)
-- Name: ml_model_providers_modelproviderconnection ml_model_providers_m_created_by_id_2e24aab7_fk_htx_user_; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_model_providers_modelproviderconnection
    ADD CONSTRAINT ml_model_providers_m_created_by_id_2e24aab7_fk_htx_user_ FOREIGN KEY (created_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5126 (class 2606 OID 27541)
-- Name: ml_model_providers_modelproviderconnection ml_model_providers_m_organization_id_ef7f6136_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_model_providers_modelproviderconnection
    ADD CONSTRAINT ml_model_providers_m_organization_id_ef7f6136_fk_organizat FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5094 (class 2606 OID 26951)
-- Name: ml_models_modelinterface_associated_projects ml_models_modelinter_modelinterface_id_035df3df_fk_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_modelinterface_associated_projects
    ADD CONSTRAINT ml_models_modelinter_modelinterface_id_035df3df_fk_ml_models FOREIGN KEY (modelinterface_id) REFERENCES public.ml_models_modelinterface(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5084 (class 2606 OID 26872)
-- Name: ml_models_modelinterface ml_models_modelinter_organization_id_d5688149_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_modelinterface
    ADD CONSTRAINT ml_models_modelinter_organization_id_d5688149_fk_organizat FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5095 (class 2606 OID 26956)
-- Name: ml_models_modelinterface_associated_projects ml_models_modelinter_project_id_76a17855_fk_project_i; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_modelinterface_associated_projects
    ADD CONSTRAINT ml_models_modelinter_project_id_76a17855_fk_project_i FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5085 (class 2606 OID 26867)
-- Name: ml_models_modelinterface ml_models_modelinterface_created_by_id_8ba717c0_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_modelinterface
    ADD CONSTRAINT ml_models_modelinterface_created_by_id_8ba717c0_fk_htx_user_id FOREIGN KEY (created_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5090 (class 2606 OID 26912)
-- Name: ml_models_modelrun ml_models_modelrun_created_by_id_1a302218_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_modelrun
    ADD CONSTRAINT ml_models_modelrun_created_by_id_1a302218_fk_htx_user_id FOREIGN KEY (created_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5091 (class 2606 OID 26917)
-- Name: ml_models_modelrun ml_models_modelrun_model_version_id_e15572eb_fk_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_modelrun
    ADD CONSTRAINT ml_models_modelrun_model_version_id_e15572eb_fk_ml_models FOREIGN KEY (model_version_id) REFERENCES public.ml_models_thirdpartymodelversion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5092 (class 2606 OID 26922)
-- Name: ml_models_modelrun ml_models_modelrun_organization_id_1f7f8243_fk_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_modelrun
    ADD CONSTRAINT ml_models_modelrun_organization_id_1f7f8243_fk_organization_id FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5093 (class 2606 OID 26927)
-- Name: ml_models_modelrun ml_models_modelrun_project_id_1b76ea76_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_modelrun
    ADD CONSTRAINT ml_models_modelrun_project_id_1b76ea76_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5086 (class 2606 OID 26879)
-- Name: ml_models_thirdpartymodelversion ml_models_thirdparty_created_by_id_b1fb2c2f_fk_htx_user_; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_thirdpartymodelversion
    ADD CONSTRAINT ml_models_thirdparty_created_by_id_b1fb2c2f_fk_htx_user_ FOREIGN KEY (created_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5087 (class 2606 OID 27549)
-- Name: ml_models_thirdpartymodelversion ml_models_thirdparty_model_provider_conne_b98c173f_fk_ml_model_; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_thirdpartymodelversion
    ADD CONSTRAINT ml_models_thirdparty_model_provider_conne_b98c173f_fk_ml_model_ FOREIGN KEY (model_provider_connection_id) REFERENCES public.ml_model_providers_modelproviderconnection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5088 (class 2606 OID 26884)
-- Name: ml_models_thirdpartymodelversion ml_models_thirdparty_organization_id_a4a5df4d_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_thirdpartymodelversion
    ADD CONSTRAINT ml_models_thirdparty_organization_id_a4a5df4d_fk_organizat FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5089 (class 2606 OID 26889)
-- Name: ml_models_thirdpartymodelversion ml_models_thirdparty_parent_model_id_599e1869_fk_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.ml_models_thirdpartymodelversion
    ADD CONSTRAINT ml_models_thirdparty_parent_model_id_599e1869_fk_ml_models FOREIGN KEY (parent_model_id) REFERENCES public.ml_models_modelinterface(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5003 (class 2606 OID 24996)
-- Name: organization organization_created_by_id_35551e36_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_created_by_id_35551e36_fk_htx_user_id FOREIGN KEY (created_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5004 (class 2606 OID 25001)
-- Name: organizations_organizationmember organizations_organi_organization_id_f26cf71b_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.organizations_organizationmember
    ADD CONSTRAINT organizations_organi_organization_id_f26cf71b_fk_organizat FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5005 (class 2606 OID 25006)
-- Name: organizations_organizationmember organizations_organi_user_id_f3845ee5_fk_htx_user_; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.organizations_organizationmember
    ADD CONSTRAINT organizations_organi_user_id_f3845ee5_fk_htx_user_ FOREIGN KEY (user_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5103 (class 2606 OID 27100)
-- Name: prediction_meta prediction_meta_failed_prediction_id_082536d6_fk_tasks_fai; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.prediction_meta
    ADD CONSTRAINT prediction_meta_failed_prediction_id_082536d6_fk_tasks_fai FOREIGN KEY (failed_prediction_id) REFERENCES public.tasks_failedprediction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5104 (class 2606 OID 27105)
-- Name: prediction_meta prediction_meta_prediction_id_c33b5954_fk_prediction_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.prediction_meta
    ADD CONSTRAINT prediction_meta_prediction_id_c33b5954_fk_prediction_id FOREIGN KEY (prediction_id) REFERENCES public.prediction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5028 (class 2606 OID 27039)
-- Name: prediction prediction_model_id_f9d54ad0_fk_ml_mlbackend_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.prediction
    ADD CONSTRAINT prediction_model_id_f9d54ad0_fk_ml_mlbackend_id FOREIGN KEY (model_id) REFERENCES public.ml_mlbackend(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5029 (class 2606 OID 26963)
-- Name: prediction prediction_model_run_id_9d95621b_fk_ml_models_modelrun_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.prediction
    ADD CONSTRAINT prediction_model_run_id_9d95621b_fk_ml_models_modelrun_id FOREIGN KEY (model_run_id) REFERENCES public.ml_models_modelrun(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5030 (class 2606 OID 26828)
-- Name: prediction prediction_project_id_ec1ad819_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.prediction
    ADD CONSTRAINT prediction_project_id_ec1ad819_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5031 (class 2606 OID 25614)
-- Name: prediction prediction_task_id_4e4fb4d3_fk_task_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.prediction
    ADD CONSTRAINT prediction_task_id_4e4fb4d3_fk_task_id FOREIGN KEY (task_id) REFERENCES public.task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5006 (class 2606 OID 25300)
-- Name: project project_created_by_id_6cc13408_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_created_by_id_6cc13408_fk_htx_user_id FOREIGN KEY (created_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5007 (class 2606 OID 27555)
-- Name: project project_deleted_by_id_12e91153_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_deleted_by_id_12e91153_fk_htx_user_id FOREIGN KEY (deleted_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5008 (class 2606 OID 25283)
-- Name: project project_organization_id_3c9f74fb_fk_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_organization_id_3c9f74fb_fk_organization_id FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5015 (class 2606 OID 25378)
-- Name: projects_labelstreamhistory projects_labelstreamhistory_project_id_906c91dd_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_labelstreamhistory
    ADD CONSTRAINT projects_labelstreamhistory_project_id_906c91dd_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5016 (class creating INDEX "public.data_manager_view_project_id_59f5a002"
pg_dump: creating INDEX "public.data_manager_view_user_id_e71e14cd"
pg_dump: creating INDEX "public.django_admin_log_content_type_id_c4bce8eb"
pg_dump: creating INDEX "public.django_admin_log_user_id_c564eba6"
pg_dump: creating INDEX "public.django_session_expire_date_a5c62663"
pg_dump: creating INDEX "public.django_session_session_key_c0390e0f_like"
pg_dump: creating INDEX "public.fsm_annotationstate_annotation_id_a73ea2ec"
pg_dump: creating INDEX "public.fsm_annotationstate_completed_by_id_3f46eae0"
pg_dump: creating INDEX "public.fsm_annotationstate_organization_id_a5163275"
pg_dump: creating INDEX "public.fsm_annotationstate_project_id_bf5279de"
pg_dump: creating INDEX "public.fsm_annotationstate_state_84d28d51"
pg_dump: creating INDEX "public.fsm_annotationstate_state_84d28d51_like"
pg_dump: creating INDEX "public.fsm_annotationstate_task_id_e50e54d5"
pg_dump: creating INDEX "public.fsm_annotationstate_triggered_by_id_1e47eb15"
pg_dump: creating INDEX "public.fsm_projectstate_created_by_id_4d716749"
pg_dump: creating INDEX "public.fsm_projectstate_organization_id_3889ce76"
pg_dump: creating INDEX "public.fsm_projectstate_project_id_590cf19b"
pg_dump: creating INDEX "public.fsm_projectstate_state_4ee8839f"
pg_dump: creating INDEX "public.fsm_projectstate_state_4ee8839f_like"
pg_dump: creating INDEX "public.fsm_projectstate_triggered_by_id_345c19fc"
pg_dump: creating INDEX "public.fsm_taskstate_organization_id_192d4ce3"
pg_dump: creating INDEX "public.fsm_taskstate_project_id_4e135c45"
pg_dump: creating INDEX "public.fsm_taskstate_state_d158253a"
pg_dump: creating INDEX "public.fsm_taskstate_state_d158253a_like"
pg_dump: creating INDEX "public.fsm_taskstate_task_id_94042c41"
pg_dump: creating INDEX "public.fsm_taskstate_triggered_by_id_1f1dfd8f"
pg_dump: creating INDEX "public.htx_user_active_organization_id_2e1bb565"
pg_dump: creating INDEX "public.htx_user_date_jo_3bd95e_idx"
pg_dump: creating INDEX "public.htx_user_email_051c68_idx"
pg_dump: creating INDEX "public.htx_user_email_9375607c_like"
pg_dump: creating INDEX "public.htx_user_first_n_93c5de_idx"
pg_dump: creating INDEX "public.htx_user_groups_group_id_d0fee99a"
pg_dump: creating INDEX "public.htx_user_groups_user_id_620c9163"
pg_dump: creating INDEX "public.htx_user_last_na_2ace53_idx"
pg_dump: creating INDEX "public.htx_user_user_permissions_permission_id_edaf5db1"
pg_dump: creating INDEX "public.htx_user_user_permissions_user_id_a71f59ac"
pg_dump: creating INDEX "public.htx_user_usernam_a41619_idx"
pg_dump: creating INDEX "public.io_storages_azureblobexportstorage_project_id_43222df5"
pg_dump: creating INDEX "public.io_storages_azureblobexportstoragelink_annotation_id_6cc15c83"
pg_dump: creating INDEX "public.io_storages_azureblobexportstoragelink_storage_id_1b260b1e"
pg_dump: creating INDEX "public.io_storages_azureblobimportstorage_project_id_67a67313"
pg_dump: creating INDEX "public.io_storages_azureblobimportstoragelink_storage_id_a08c3173"
pg_dump: creating INDEX "public.io_storages_gcsexportstorage_project_id_c3141a14"
pg_dump: creating INDEX "public.io_storages_gcsexportstoragelink_annotation_id_2df715a6"
pg_dump: creating INDEX "public.io_storages_gcsexportstoragelink_storage_id_e940a32d"
pg_dump: creating INDEX "public.io_storages_gcsimportstorage_project_id_dfb68296"
pg_dump: creating INDEX "public.io_storages_gcsimportstoragelink_storage_id_f3037a96"
pg_dump: creating INDEX "public.io_storages_localfilesexportstorage_project_id_35dd9dc7"
pg_dump: creating INDEX "public.io_storages_localfilesexportstoragelink_annotation_id_fc4f9825"
pg_dump: creating INDEX "public.io_storages_localfilesexportstoragelink_storage_id_87392e7a"
pg_dump: creating INDEX "public.io_storages_localfilesimportstorage_project_id_9ae1d2c5"
pg_dump: creating INDEX "public.io_storages_localfilesimportstoragelink_storage_id_59a5663c"
pg_dump: creating INDEX "public.io_storages_redisexportstorage_project_id_12a2546c"
pg_dump: creating INDEX "public.io_storages_redisexportstoragelink_annotation_id_8547e508"
pg_dump: creating INDEX "public.io_storages_redisexportstoragelink_storage_id_807898d8"
pg_dump: creating INDEX "public.io_storages_redisimportstorage_project_id_c7b9adc0"
pg_dump: creating INDEX "public.io_storages_redisimportstoragelink_storage_id_17124de8"
pg_dump: creating INDEX "public.io_storages_s3exportstorage_project_id_5e76add6"
pg_dump: creating INDEX "public.io_storages_s3exportstoragelink_annotation_id_729994fe"
pg_dump: creating INDEX "public.io_storages_s3exportstoragelink_storage_id_a4563d13"
pg_dump: creating INDEX "public.io_storages_s3importstorage_project_id_dee63a8d"
pg_dump: creating INDEX "public.io_storages_s3importstoragelink_storage_id_50ca5bd8"
pg_dump: creating INDEX "public.labels_manager_label_approved_by_id_4b6a871f"
pg_dump: creating INDEX "public.labels_manager_label_created_by_id_e3b3e785"
pg_dump: creating INDEX "public.labels_manager_label_organization_id_5f714874"
pg_dump: creating INDEX "public.labels_manager_labellink_label_id_c8afbfa4"
pg_dump: creating INDEX "public.labels_manager_labellink_project_id_e3d33738"
pg_dump: creating INDEX "public.ml_mlbackend_project_id_ca08142d"
pg_dump: creating INDEX "public.ml_mlbackendpredictionjob_ml_backend_id_c1aea4f1"
pg_dump: creating INDEX "public.ml_mlbackendtrainjob_ml_backend_id_3d40686e"
pg_dump: creating INDEX "public.ml_model_providers_modelpr_created_by_id_2e24aab7"
pg_dump: creating INDEX "public.ml_model_providers_modelpr_organization_id_ef7f6136"
pg_dump: creating INDEX "public.ml_models_modelinterface_a_modelinterface_id_035df3df"
pg_dump: creating INDEX "public.ml_models_modelinterface_a_project_id_76a17855"
pg_dump: creating INDEX "public.ml_models_modelinterface_created_by_id_8ba717c0"
pg_dump: creating INDEX "public.ml_models_modelinterface_organization_id_d5688149"
pg_dump: creating INDEX "public.ml_models_modelrun_created_by_id_1a302218"
pg_dump: creating INDEX "public.ml_models_modelrun_model_version_id_e15572eb"
pg_dump: creating INDEX "public.ml_models_modelrun_organization_id_1f7f8243"
pg_dump: creating INDEX "public.ml_models_modelrun_project_id_1b76ea76"
pg_dump: creating INDEX "public.ml_models_thirdpartymodelv_model_provider_connection__b98c173f"
pg_dump: creating INDEX "public.ml_models_thirdpartymodelversion_created_by_id_b1fb2c2f"
pg_dump: creating INDEX "public.ml_models_thirdpartymodelversion_organization_id_a4a5df4d"
pg_dump: creating INDEX "public.ml_models_thirdpartymodelversion_parent_model_id_599e1869"
pg_dump: creating INDEX "public.organization_token_5bd2529a_like"
pg_dump: creating INDEX "public.organizations_organizationmember_deleted_at_af2d5523"
pg_dump: creating INDEX "public.organizations_organizationmember_organization_id_f26cf71b"
pg_dump: creating INDEX "public.organizations_organizationmember_user_id_f3845ee5"
pg_dump: creating INDEX "public.prediction_model_id_f9d54ad0"
pg_dump: creating INDEX "public.prediction_model_run_id_9d95621b"
pg_dump: creating INDEX "public.prediction_project_id_ec1ad819"
pg_dump: creating INDEX "public.prediction_task_id_4e4fb4d3"
pg_dump: creating INDEX "public.project_created_by_id_6cc13408"
pg_dump: creating INDEX "public.project_current_state_idx"
pg_dump: creating INDEX "public.project_deleted_at_idx"
pg_dump: creating INDEX "public.project_org_deleted_idx"
pg_dump: creating INDEX "public.project_org_reporting_idx"
pg_dump: creating INDEX "public.project_org_state_idx"
pg_dump: creating INDEX "public.project_organization_id_3c9f74fb"
pg_dump: creating INDEX "public.project_pinned__a39ccb_idx"
pg_dump: creating INDEX "public.project_purge_at_idx"
pg_dump: creating INDEX "public.project_search_vector_idx"
pg_dump: creating INDEX "public.projects_labelstreamhistory_project_id_906c91dd"
pg_dump: creating INDEX "public.projects_labelstreamhistory_user_id_1b571ab9"
pg_dump: creating INDEX "public.projects_projectimport_project_id_619e3461"
pg_dump: creating INDEX "public.projects_projectmember_project_id_e589ddea"
pg_dump: creating INDEX "public.projects_projectmember_user_id_a475bbd8"
pg_dump: creating INDEX "public.projects_projectonboarding_project_id_120e4f53"
pg_dump: creating INDEX "public.projects_projectonboarding_step_id_c232d94b"
pg_dump: creating INDEX "public.projects_projectreimport_project_id_6bcffbed"
pg_dump: creating INDEX "public.task_cancelled_annotations_60dfe3b9"
pg_dump: creating INDEX "public.task_comment_authors_task_id_80618a4a"
pg_dump: creating INDEX "public.task_comment_authors_user_id_ff0b1cf0"
pg_dump: creating INDEX "public.task_comment_count_049355cc"
pg_dump: creating INDEX "public.task_comple_created_f55e6f_idx"
pg_dump: creating INDEX "public.task_comple_ground__088a1b_idx"
pg_dump: creating INDEX "public.task_comple_id_653858_idx"
pg_dump: creating INDEX "public.task_comple_last_ac_777e69_idx"
pg_dump: creating INDEX "public.task_comple_project_0bc0be_idx"
pg_dump: creating INDEX "public.task_comple_project_2cbbfc_idx"
pg_dump: creating INDEX "public.task_comple_project_5c60f3_idx"
pg_dump: creating INDEX "public.task_comple_project_c7e507_idx"
pg_dump: creating INDEX "public.task_comple_task_id_8072c3_idx"
pg_dump: creating INDEX "public.task_comple_task_id_a6bdec_idx"
pg_dump: creating INDEX "public.task_comple_task_id_d49cd7_idx"
pg_dump: creating INDEX "public.task_comple_task_id_e82920_idx"
pg_dump: creating INDEX "public.task_comple_was_can_f87d4e_idx"
pg_dump: creating INDEX "public.task_completion_completed_by_id_3f3206b1"
pg_dump: creating INDEX "public.task_completion_id_updated_at_idx"
pg_dump: creating INDEX "public.task_completion_import_id_e434c5af"
pg_dump: creating INDEX "public.task_completion_last_created_by_id_a04457d1"
pg_dump: creating INDEX "public.task_completion_parent_annotation_id_58398c37"
pg_dump: creating INDEX "public.task_completion_parent_prediction_id_053d00d9"
pg_dump: creating INDEX "public.task_completion_project_id_94072c87"
pg_dump: creating INDEX "public.task_completion_task_id_b9049fbc"
pg_dump: creating INDEX "public.task_completion_updated_by_id_1164a739"
pg_dump: creating INDEX "public.task_current_state_idx"
pg_dump: creating INDEX "public.task_file_upload_id_549188ed"
pg_dump: creating INDEX "public.task_history_idx"
pg_dump: creating INDEX "public.task_id_7a9aca_idx"
pg_dump: creating INDEX "public.task_id_aef988_idx"
pg_dump: creating INDEX "public.task_last_comment_updated_at_d1bc3403"
pg_dump: creating INDEX "public.task_org_reporting_idx"
pg_dump: creating INDEX "public.task_overlap_455a13f0"
pg_dump: creating INDEX "public.task_overlap_6a196e_idx"
pg_dump: creating INDEX "public.task_proj_octlen_idx"
pg_dump: creating INDEX "public.task_project_499b59_idx"
pg_dump: creating INDEX "public.task_project_6acf5f_idx"
pg_dump: creating INDEX "public.task_project_7b1c80_idx"
pg_dump: creating INDEX "public.task_project_id_963d6354"
pg_dump: creating INDEX "public.task_project_state_idx"
pg_dump: creating INDEX "public.task_total_annotations_e77e347b"
pg_dump: creating INDEX "public.task_total_predictions_f1a6b218"
pg_dump: creating INDEX "public.task_unresolved_comment_count_8707d0c7"
pg_dump: creating INDEX "public.task_updated_at_brin_idx"
pg_dump: creating INDEX "public.task_updated_by_id_c9d9ddfb"
pg_dump: creating INDEX "public.tasks_annotationdraft_import_id_29542ca8"
pg_dump: creating INDEX "public.tasks_annotationdraft_was_postponed_6a1ee000"
pg_dump: creating INDEX "public.tasks_annotations_result_proj_gin"
pg_dump: creating INDEX "public.tasks_failedprediction_ml_backend_model_id_5813a377"
pg_dump: creating INDEX "public.tasks_failedprediction_model_run_id_eec73944"
pg_dump: creating INDEX "public.tasks_failedprediction_project_id_6b803bbe"
pg_dump: creating INDEX "public.tasks_failedprediction_task_id_ed2f3848"
pg_dump: creating INDEX "public.tasks_predictions_result_proj_gin"
pg_dump: creating INDEX "public.tasks_taskcompletiondraft_completion_id_dc5dea99"
pg_dump: creating INDEX "public.tasks_taskcompletiondraft_task_id_e575af88"
pg_dump: creating INDEX "public.tasks_taskcompletiondraft_user_id_b4b84cef"
pg_dump: creating INDEX "public.tasks_tasklock_task_id_6531a5ed"
pg_dump: creating INDEX "public.tasks_tasklock_user_id_748ae86f"
pg_dump: creating INDEX "public.token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_like"
pg_dump: creating INDEX "public.token_blacklist_outstandingtoken_user_id_83bc629a"
pg_dump: creating INDEX "public.users_userproducttour_user_id_64e8adfc"
pg_dump: creating INDEX "public.webhook_action_action_4398909e"
pg_dump: creating INDEX "public.webhook_action_action_4398909e_like"
pg_dump: creating INDEX "public.webhook_action_webhook_id_4eb6213f"
pg_dump: creating INDEX "public.webhook_created_at_b2a71ea5"
pg_dump: creating INDEX "public.webhook_organization_id_b5440e9a"
pg_dump: creating INDEX "public.webhook_project_id_e686d00c"
pg_dump: creating INDEX "public.webhook_updated_at_695b4e7f"
pg_dump: creating FK CONSTRAINT "public.auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm"
pg_dump: creating FK CONSTRAINT "public.auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id"
pg_dump: creating FK CONSTRAINT "public.auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co"
pg_dump: creating FK CONSTRAINT "public.authtoken_token authtoken_token_user_id_35299eff_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.core_asyncmigrationstatus core_asyncmigrationstatus_project_id_c78fbf75_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.data_export_convertedformat data_export_converte_created_by_id_a765f2cd_fk_htx_user_"
pg_dump: creating FK CONSTRAINT "public.data_export_convertedformat data_export_converte_export_id_3305f028_fk_data_expo"
pg_dump: creating FK CONSTRAINT "public.data_export_convertedformat data_export_converte_organization_id_d0e9d7c8_fk_organizat"
pg_dump: creating FK CONSTRAINT "public.data_export_convertedformat data_export_convertedformat_project_id_3cda1a1c_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.data_export_export data_export_export_created_by_id_ae0b7af3_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.data_export_export data_export_export_project_id_dc05487f_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.data_import_fileupload data_import_fileupload_project_id_1f511810_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.data_import_fileupload data_import_fileupload_user_id_a3e1f065_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.data_manager_filter data_manager_filter_parent_id_b5dd2a37_fk_data_mana"
pg_dump: creating FK CONSTRAINT "public.data_manager_filtergroup_filters data_manager_filterg_filter_id_954bc394_fk_data_mana"
pg_dump: creating FK CONSTRAINT "public.data_manager_filtergroup_filters data_manager_filterg_filtergroup_id_85d9bb16_fk_data_mana"
pg_dump: creating FK CONSTRAINT "public.data_manager_view data_manager_view_filter_group_id_39a9ec2b_fk_data_mana"
pg_dump: creating FK CONSTRAINT "public.data_manager_view data_manager_view_project_id_59f5a002_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.data_manager_view data_manager_view_user_id_e71e14cd_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co"
pg_dump: creating FK CONSTRAINT "public.django_admin_log django_admin_log_user_id_c564eba6_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.fsm_annotationstate fsm_annotationstate_annotation_id_a73ea2ec_fk_task_comp"
pg_dump: creating FK CONSTRAINT "public.fsm_annotationstate fsm_annotationstate_triggered_by_id_1e47eb15_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.fsm_projectstate fsm_projectstate_project_id_590cf19b_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.fsm_projectstate fsm_projectstate_triggered_by_id_345c19fc_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.fsm_taskstate fsm_taskstate_task_id_94042c41_fk_task_id"
pg_dump: creating FK CONSTRAINT "public.fsm_taskstate fsm_taskstate_triggered_by_id_1f1dfd8f_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.htx_user htx_user_active_organization_id_2e1bb565_fk_organization_id"
pg_dump: creating FK CONSTRAINT "public.htx_user_groups htx_user_groups_group_id_d0fee99a_fk_auth_group_id"
pg_dump: creating FK CONSTRAINT "public.htx_user_groups htx_user_groups_user_id_620c9163_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.htx_user_user_permissions htx_user_user_permis_permission_id_edaf5db1_fk_auth_perm"
pg_dump: creating FK CONSTRAINT "public.htx_user_user_permissions htx_user_user_permissions_user_id_a71f59ac_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.io_storages_azureblobexportstoragelink io_storages_azureblo_annotation_id_6cc15c83_fk_task_comp"
pg_dump: creating FK CONSTRAINT "public.io_storages_azureblobexportstorage io_storages_azureblo_azureblobstoragemixi_54a8d52d_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_azureblobimportstorage io_storages_azureblo_azureblobstoragemixi_e6234dd9_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_azureblobexportstorage io_storages_azureblo_project_id_43222df5_fk_project_i"
pg_dump: creating FK CONSTRAINT "public.io_storages_azureblobimportstorage io_storages_azureblo_project_id_67a67313_fk_project_i"
pg_dump: creating FK CONSTRAINT "public.io_storages_azureblobexportstoragelink io_storages_azureblo_storage_id_1b260b1e_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_azureblobimportstoragelink io_storages_azureblo_storage_id_a08c3173_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_azureblobimportstoragelink io_storages_azureblob_task_id_26c31809_fk_task_id"
pg_dump: creating FK CONSTRAINT "public.io_storages_gcsexportstoragelink io_storages_gcsexpor_annotation_id_2df715a6_fk_task_comp"
pg_dump: creating FK CONSTRAINT "public.io_storages_gcsexportstorage io_storages_gcsexpor_gcsstoragemixin_ptr__007e6803_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_gcsexportstoragelink io_storages_gcsexpor_storage_id_e940a32d_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_gcsexportstorage io_storages_gcsexportstorage_project_id_c3141a14_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.io_storages_gcsimportstorage io_storages_gcsimpor_gcsstoragemixin_ptr__10604ed3_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_gcsimportstoragelink io_storages_gcsimpor_storage_id_f3037a96_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_gcsimportstorage io_storages_gcsimportstorage_project_id_dfb68296_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.io_storages_gcsimportstoragelink io_storages_gcsimportstoragelink_task_id_3bedcb9b_fk_task_id"
pg_dump: creating FK CONSTRAINT "public.io_storages_localfilesexportstoragelink io_storages_localfil_annotation_id_fc4f9825_fk_task_comp"
pg_dump: creating FK CONSTRAINT "public.io_storages_localfilesexportstorage io_storages_localfil_localfilesmixin_ptr__f0b19499_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_localfilesimportstorage io_storages_localfil_localfilesmixin_ptr__fb0a0be4_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_localfilesexportstorage io_storages_localfil_project_id_35dd9dc7_fk_project_i"
pg_dump: creating FK CONSTRAINT "public.io_storages_localfilesimportstorage io_storages_localfil_project_id_9ae1d2c5_fk_project_i"
pg_dump: creating FK CONSTRAINT "public.io_storages_localfilesimportstoragelink io_storages_localfil_storage_id_59a5663c_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_localfilesexportstoragelink io_storages_localfil_storage_id_87392e7a_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_localfilesimportstoragelink io_storages_localfile_task_id_d0e8315f_fk_task_id"
pg_dump: creating FK CONSTRAINT "public.io_storages_redisexportstoragelink io_storages_redisexp_annotation_id_8547e508_fk_task_comp"
pg_dump: creating FK CONSTRAINT "public.io_storages_redisexportstorage io_storages_redisexp_project_id_12a2546c_fk_project_i"
pg_dump: creating FK CONSTRAINT "public.io_storages_redisexportstorage io_storages_redisexp_redisstoragemixin_pt_d1c2d337_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_redisexportstoragelink io_storages_redisexp_storage_id_807898d8_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_redisimportstorage io_storages_redisimp_project_id_c7b9adc0_fk_project_i"
pg_dump: creating FK CONSTRAINT "public.io_storages_redisimportstorage io_storages_redisimp_redisstoragemixin_pt_73982db6_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_redisimportstoragelink io_storages_redisimp_storage_id_17124de8_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_redisimportstoragelink io_storages_redisimportstoragelink_task_id_6730b8ad_fk_task_id"
pg_dump: creating FK CONSTRAINT "public.io_storages_s3exportstoragelink io_storages_s3export_annotation_id_729994fe_fk_task_comp"
pg_dump: creating FK CONSTRAINT "public.io_storages_s3exportstoragelink io_storages_s3export_storage_id_a4563d13_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_s3exportstorage io_storages_s3exportstorage_project_id_5e76add6_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.io_storages_s3importstoragelink io_storages_s3import_storage_id_50ca5bd8_fk_io_storag"
pg_dump: creating FK CONSTRAINT "public.io_storages_s3importstorage io_storages_s3importstorage_project_id_dee63a8d_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.io_storages_s3importstoragelink io_storages_s3importstoragelink_task_id_126f4f82_fk_task_id"
pg_dump: creating FK CONSTRAINT "public.jwt_auth_jwtsettings jwt_auth_jwtsettings_organization_id_1e76aa12_fk_organizat"
pg_dump: creating FK CONSTRAINT "public.labels_manager_label labels_manager_label_approved_by_id_4b6a871f_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.labels_manager_label labels_manager_label_created_by_id_e3b3e785_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.labels_manager_labellink labels_manager_label_label_id_c8afbfa4_fk_labels_ma"
pg_dump: creating FK CONSTRAINT "public.labels_manager_label labels_manager_label_organization_id_5f714874_fk_organizat"
pg_dump: creating FK CONSTRAINT "public.labels_manager_labellink labels_manager_labellink_project_id_e3d33738_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.ml_mlbackend ml_mlbackend_project_id_ca08142d_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.ml_mlbackendpredictionjob ml_mlbackendpredicti_ml_backend_id_c1aea4f1_fk_ml_mlback"
pg_dump: creating FK CONSTRAINT "public.ml_mlbackendtrainjob ml_mlbackendtrainjob_ml_backend_id_3d40686e_fk_ml_mlbackend_id"
pg_dump: creating FK CONSTRAINT "public.ml_model_providers_modelproviderconnection ml_model_providers_m_created_by_id_2e24aab7_fk_htx_user_"
pg_dump: creating FK CONSTRAINT "public.ml_model_providers_modelproviderconnection ml_model_providers_m_organization_id_ef7f6136_fk_organizat"
pg_dump: creating FK CONSTRAINT "public.ml_models_modelinterface_associated_projects ml_models_modelinter_modelinterface_id_035df3df_fk_ml_models"
pg_dump: creating FK CONSTRAINT "public.ml_models_modelinterface ml_models_modelinter_organization_id_d5688149_fk_organizat"
pg_dump: creating FK CONSTRAINT "public.ml_models_modelinterface_associated_projects ml_models_modelinter_project_id_76a17855_fk_project_i"
pg_dump: creating FK CONSTRAINT "public.ml_models_modelinterface ml_models_modelinterface_created_by_id_8ba717c0_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.ml_models_modelrun ml_models_modelrun_created_by_id_1a302218_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.ml_models_modelrun ml_models_modelrun_model_version_id_e15572eb_fk_ml_models"
pg_dump: creating FK CONSTRAINT "public.ml_models_modelrun ml_models_modelrun_organization_id_1f7f8243_fk_organization_id"
pg_dump: creating FK CONSTRAINT "public.ml_models_modelrun ml_models_modelrun_project_id_1b76ea76_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.ml_models_thirdpartymodelversion ml_models_thirdparty_created_by_id_b1fb2c2f_fk_htx_user_"
pg_dump: creating FK CONSTRAINT "public.ml_models_thirdpartymodelversion ml_models_thirdparty_model_provider_conne_b98c173f_fk_ml_model_"
pg_dump: creating FK CONSTRAINT "public.ml_models_thirdpartymodelversion ml_models_thirdparty_organization_id_a4a5df4d_fk_organizat"
pg_dump: creating FK CONSTRAINT "public.ml_models_thirdpartymodelversion ml_models_thirdparty_parent_model_id_599e1869_fk_ml_models"
pg_dump: creating FK CONSTRAINT "public.organization organization_created_by_id_35551e36_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.organizations_organizationmember organizations_organi_organization_id_f26cf71b_fk_organizat"
pg_dump: creating FK CONSTRAINT "public.organizations_organizationmember organizations_organi_user_id_f3845ee5_fk_htx_user_"
pg_dump: creating FK CONSTRAINT "public.prediction_meta prediction_meta_failed_prediction_id_082536d6_fk_tasks_fai"
pg_dump: creating FK CONSTRAINT "public.prediction_meta prediction_meta_prediction_id_c33b5954_fk_prediction_id"
pg_dump: creating FK CONSTRAINT "public.prediction prediction_model_id_f9d54ad0_fk_ml_mlbackend_id"
pg_dump: creating FK CONSTRAINT "public.prediction prediction_model_run_id_9d95621b_fk_ml_models_modelrun_id"
pg_dump: creating FK CONSTRAINT "public.prediction prediction_project_id_ec1ad819_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.prediction prediction_task_id_4e4fb4d3_fk_task_id"
pg_dump: creating FK CONSTRAINT "public.project project_created_by_id_6cc13408_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.project project_deleted_by_id_12e91153_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.project project_organization_id_3c9f74fb_fk_organization_id"
pg_dump: creating FK CONSTRAINT "public.projects_labelstreamhistory projects_labelstreamhistory_project_id_906c91dd_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.projects_labelstreamhistory projects_labelstreamhistory_user_id_1b571ab9_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.projects_projectimport projects_projectimport_project_id_619e3461_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.projects_projectmember projects_projectmember_project_id_e589ddea_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.projects_projectmember projects_projectmember_user_id_a475bbd8_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.projects_projectonboarding projects_projectonbo_step_id_c232d94b_fk_projects_"
pg_dump: creating FK CONSTRAINT "public.projects_projectonboarding projects_projectonboarding_project_id_120e4f53_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.projects_projectreimport projects_projectreimport_project_id_6bcffbed_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.projects_projectsummary projects_projectsummary_project_id_0d5aff36_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.session_policy_sessiontimeoutpolicy session_policy_sessi_organization_id_c2feae9a_fk_organizat"
pg_dump: creating FK CONSTRAINT "public.task_comment_authors task_comment_authors_task_id_80618a4a_fk_task_id"
pg_dump: creating FK CONSTRAINT "public.task_comment_authors task_comment_authors_user_id_ff0b1cf0_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.task_completion task_completion_completed_by_id_3f3206b1_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.task_completion task_completion_last_created_by_id_a04457d1_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.task_completion task_completion_parent_annotation_id_58398c37_fk_task_comp"
pg_dump: creating FK CONSTRAINT "public.task_completion task_completion_parent_prediction_id_053d00d9_fk_prediction_id"
pg_dump: creating FK CONSTRAINT "public.task_completion task_completion_project_id_94072c87_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.task_completion task_completion_task_id_b9049fbc_fk_task_id"
pg_dump: creating FK CONSTRAINT "public.task_completion task_completion_updated_by_id_1164a739_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.task task_file_upload_id_549188ed_fk_data_import_fileupload_id"
pg_dump: creating FK CONSTRAINT "public.task task_project_id_963d6354_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.task task_updated_by_id_c9d9ddfb_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.tasks_annotationdraft tasks_annotationdraf_annotation_id_86db74e5_fk_task_comp"
pg_dump: creating FK CONSTRAINT "public.tasks_failedprediction tasks_failedpredicti_ml_backend_model_id_5813a377_fk_ml_mlback"
pg_dump: creating FK CONSTRAINT "public.tasks_failedprediction tasks_failedpredicti_model_run_id_eec73944_fk_ml_models"
pg_dump: creating FK CONSTRAINT "public.tasks_failedprediction tasks_failedprediction_project_id_6b803bbe_fk_project_id"
pg_dump: creating FK CONSTRAINT "public.tasks_failedprediction tasks_failedprediction_task_id_ed2f3848_fk_task_id"
pg_dump: creating FK CONSTRAINT "public.tasks_annotationdraft tasks_taskcompletiondraft_task_id_e575af88_fk_task_id"
pg_dump: creating FK CONSTRAINT "public.tasks_annotationdraft tasks_taskcompletiondraft_user_id_b4b84cef_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.tasks_tasklock tasks_tasklock_task_id_6531a5ed_fk_task_id"
pg_dump: creating FK CONSTRAINT "public.tasks_tasklock tasks_tasklock_user_id_748ae86f_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.token_blacklist_blacklistedtoken token_blacklist_blacklistedtoken_token_id_3cc7fe56_fk"
pg_dump: creating FK CONSTRAINT "public.token_blacklist_outstandingtoken token_blacklist_outs_user_id_83bc629a_fk_htx_user_"
pg_dump: creating FK CONSTRAINT "public.users_userproducttour users_userproducttour_user_id_64e8adfc_fk_htx_user_id"
pg_dump: creating FK CONSTRAINT "public.webhook_action webhook_action_webhook_id_4eb6213f_fk_webhook_id"
pg_dump: creating FK CONSTRAINT "public.webhook webhook_organization_id_b5440e9a_fk_organization_id"
pg_dump: creating FK CONSTRAINT "public.webhook webhook_project_id_e686d00c_fk_project_id"
2606 OID 25383)
-- Name: projects_labelstreamhistory projects_labelstreamhistory_user_id_1b571ab9_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_labelstreamhistory
    ADD CONSTRAINT projects_labelstreamhistory_user_id_1b571ab9_fk_htx_user_id FOREIGN KEY (user_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5082 (class 2606 OID 26797)
-- Name: projects_projectimport projects_projectimport_project_id_619e3461_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_projectimport
    ADD CONSTRAINT projects_projectimport_project_id_619e3461_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5011 (class 2606 OID 25257)
-- Name: projects_projectmember projects_projectmember_project_id_e589ddea_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_projectmember
    ADD CONSTRAINT projects_projectmember_project_id_e589ddea_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5012 (class 2606 OID 25263)
-- Name: projects_projectmember projects_projectmember_user_id_a475bbd8_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_projectmember
    ADD CONSTRAINT projects_projectmember_user_id_a475bbd8_fk_htx_user_id FOREIGN KEY (user_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5009 (class 2606 OID 25311)
-- Name: projects_projectonboarding projects_projectonbo_step_id_c232d94b_fk_projects_; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_projectonboarding
    ADD CONSTRAINT projects_projectonbo_step_id_c232d94b_fk_projects_ FOREIGN KEY (step_id) REFERENCES public.projects_projectonboardingsteps(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5010 (class 2606 OID 25306)
-- Name: projects_projectonboarding projects_projectonboarding_project_id_120e4f53_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_projectonboarding
    ADD CONSTRAINT projects_projectonboarding_project_id_120e4f53_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5083 (class 2606 OID 26821)
-- Name: projects_projectreimport projects_projectreimport_project_id_6bcffbed_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_projectreimport
    ADD CONSTRAINT projects_projectreimport_project_id_6bcffbed_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5013 (class 2606 OID 25324)
-- Name: projects_projectsummary projects_projectsummary_project_id_0d5aff36_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.projects_projectsummary
    ADD CONSTRAINT projects_projectsummary_project_id_0d5aff36_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5127 (class 2606 OID 27573)
-- Name: session_policy_sessiontimeoutpolicy session_policy_sessi_organization_id_c2feae9a_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.session_policy_sessiontimeoutpolicy
    ADD CONSTRAINT session_policy_sessi_organization_id_c2feae9a_fk_organizat FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5080 (class 2606 OID 26301)
-- Name: task_comment_authors task_comment_authors_task_id_80618a4a_fk_task_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task_comment_authors
    ADD CONSTRAINT task_comment_authors_task_id_80618a4a_fk_task_id FOREIGN KEY (task_id) REFERENCES public.task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5081 (class 2606 OID 26306)
-- Name: task_comment_authors task_comment_authors_user_id_ff0b1cf0_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task_comment_authors
    ADD CONSTRAINT task_comment_authors_user_id_ff0b1cf0_fk_htx_user_id FOREIGN KEY (user_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5032 (class 2606 OID 25588)
-- Name: task_completion task_completion_completed_by_id_3f3206b1_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task_completion
    ADD CONSTRAINT task_completion_completed_by_id_3f3206b1_fk_htx_user_id FOREIGN KEY (completed_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5033 (class 2606 OID 26192)
-- Name: task_completion task_completion_last_created_by_id_a04457d1_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task_completion
    ADD CONSTRAINT task_completion_last_created_by_id_a04457d1_fk_htx_user_id FOREIGN KEY (last_created_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5034 (class 2606 OID 26165)
-- Name: task_completion task_completion_parent_annotation_id_58398c37_fk_task_comp; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task_completion
    ADD CONSTRAINT task_completion_parent_annotation_id_58398c37_fk_task_comp FOREIGN KEY (parent_annotation_id) REFERENCES public.task_completion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5035 (class 2606 OID 26160)
-- Name: task_completion task_completion_parent_prediction_id_053d00d9_fk_prediction_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task_completion
    ADD CONSTRAINT task_completion_parent_prediction_id_053d00d9_fk_prediction_id FOREIGN KEY (parent_prediction_id) REFERENCES public.prediction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5036 (class 2606 OID 26319)
-- Name: task_completion task_completion_project_id_94072c87_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task_completion
    ADD CONSTRAINT task_completion_project_id_94072c87_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5037 (class 2606 OID 25620)
-- Name: task_completion task_completion_task_id_b9049fbc_fk_task_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task_completion
    ADD CONSTRAINT task_completion_task_id_b9049fbc_fk_task_id FOREIGN KEY (task_id) REFERENCES public.task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5038 (class 2606 OID 26325)
-- Name: task_completion task_completion_updated_by_id_1164a739_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task_completion
    ADD CONSTRAINT task_completion_updated_by_id_1164a739_fk_htx_user_id FOREIGN KEY (updated_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5025 (class 2606 OID 25593)
-- Name: task task_file_upload_id_549188ed_fk_data_import_fileupload_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_file_upload_id_549188ed_fk_data_import_fileupload_id FOREIGN KEY (file_upload_id) REFERENCES public.data_import_fileupload(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5026 (class 2606 OID 25608)
-- Name: task task_project_id_963d6354_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_project_id_963d6354_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5027 (class 2606 OID 26172)
-- Name: task task_updated_by_id_c9d9ddfb_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_updated_by_id_c9d9ddfb_fk_htx_user_id FOREIGN KEY (updated_by_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5039 (class 2606 OID 26064)
-- Name: tasks_annotationdraft tasks_annotationdraf_annotation_id_86db74e5_fk_task_comp; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.tasks_annotationdraft
    ADD CONSTRAINT tasks_annotationdraf_annotation_id_86db74e5_fk_task_comp FOREIGN KEY (annotation_id) REFERENCES public.task_completion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5099 (class 2606 OID 27062)
-- Name: tasks_failedprediction tasks_failedpredicti_ml_backend_model_id_5813a377_fk_ml_mlback; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.tasks_failedprediction
    ADD CONSTRAINT tasks_failedpredicti_ml_backend_model_id_5813a377_fk_ml_mlback FOREIGN KEY (ml_backend_model_id) REFERENCES public.ml_mlbackend(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5100 (class 2606 OID 27067)
-- Name: tasks_failedprediction tasks_failedpredicti_model_run_id_eec73944_fk_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.tasks_failedprediction
    ADD CONSTRAINT tasks_failedpredicti_model_run_id_eec73944_fk_ml_models FOREIGN KEY (model_run_id) REFERENCES public.ml_models_modelrun(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5101 (class 2606 OID 27072)
-- Name: tasks_failedprediction tasks_failedprediction_project_id_6b803bbe_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.tasks_failedprediction
    ADD CONSTRAINT tasks_failedprediction_project_id_6b803bbe_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5102 (class 2606 OID 27077)
-- Name: tasks_failedprediction tasks_failedprediction_task_id_ed2f3848_fk_task_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.tasks_failedprediction
    ADD CONSTRAINT tasks_failedprediction_task_id_ed2f3848_fk_task_id FOREIGN KEY (task_id) REFERENCES public.task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5040 (class 2606 OID 25572)
-- Name: tasks_annotationdraft tasks_taskcompletiondraft_task_id_e575af88_fk_task_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.tasks_annotationdraft
    ADD CONSTRAINT tasks_taskcompletiondraft_task_id_e575af88_fk_task_id FOREIGN KEY (task_id) REFERENCES public.task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5041 (class 2606 OID 25578)
-- Name: tasks_annotationdraft tasks_taskcompletiondraft_user_id_b4b84cef_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.tasks_annotationdraft
    ADD CONSTRAINT tasks_taskcompletiondraft_user_id_b4b84cef_fk_htx_user_id FOREIGN KEY (user_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5042 (class 2606 OID 25638)
-- Name: tasks_tasklock tasks_tasklock_task_id_6531a5ed_fk_task_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.tasks_tasklock
    ADD CONSTRAINT tasks_tasklock_task_id_6531a5ed_fk_task_id FOREIGN KEY (task_id) REFERENCES public.task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5043 (class 2606 OID 25643)
-- Name: tasks_tasklock tasks_tasklock_user_id_748ae86f_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.tasks_tasklock
    ADD CONSTRAINT tasks_tasklock_user_id_748ae86f_fk_htx_user_id FOREIGN KEY (user_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5128 (class 2606 OID 27671)
-- Name: token_blacklist_blacklistedtoken token_blacklist_blacklistedtoken_token_id_3cc7fe56_fk; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.token_blacklist_blacklistedtoken
    ADD CONSTRAINT token_blacklist_blacklistedtoken_token_id_3cc7fe56_fk FOREIGN KEY (token_id) REFERENCES public.token_blacklist_outstandingtoken(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5129 (class 2606 OID 27634)
-- Name: token_blacklist_outstandingtoken token_blacklist_outs_user_id_83bc629a_fk_htx_user_; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.token_blacklist_outstandingtoken
    ADD CONSTRAINT token_blacklist_outs_user_id_83bc629a_fk_htx_user_ FOREIGN KEY (user_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5130 (class 2606 OID 27705)
-- Name: users_userproducttour users_userproducttour_user_id_64e8adfc_fk_htx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.users_userproducttour
    ADD CONSTRAINT users_userproducttour_user_id_64e8adfc_fk_htx_user_id FOREIGN KEY (user_id) REFERENCES public.htx_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5133 (class 2606 OID 27752)
-- Name: webhook_action webhook_action_webhook_id_4eb6213f_fk_webhook_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.webhook_action
    ADD CONSTRAINT webhook_action_webhook_id_4eb6213f_fk_webhook_id FOREIGN KEY (webhook_id) REFERENCES public.webhook(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5131 (class 2606 OID 27738)
-- Name: webhook webhook_organization_id_b5440e9a_fk_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.webhook
    ADD CONSTRAINT webhook_organization_id_b5440e9a_fk_organization_id FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 5132 (class 2606 OID 27743)
-- Name: webhook webhook_project_id_e686d00c_fk_project_id; Type: FK CONSTRAINT; Schema: public; Owner: wopr-labelstudio-db-user
--

ALTER TABLE ONLY public.webhook
    ADD CONSTRAINT webhook_project_id_e686d00c_fk_project_id FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


-- Completed on 2026-01-13 20:01:05 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict cbLmaJwmNesBagN0t0SGv2ak3rDqjOOM0ebMBVhNEIEFDPSzsoClaYaueoOhF6A

